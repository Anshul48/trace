"""Base interfaces and data structures for benchmark baseline retrievers."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class IndexedDocument:
    """Document representation passed to indexers."""
    doc_id: str
    text: str
    title: str = ""
    metadata: dict = field(default_factory=dict)


@dataclass
class RetrievalCandidate:
    """Individual candidate returned from retrieval search."""
    doc_id: str
    score: float
    text: str = ""
    metadata: dict = field(default_factory=dict)


@dataclass
class RetrievalResponse:
    """An explicit backend decision; an empty candidate list alone is not abstention."""
    candidates: list[RetrievalCandidate] = field(default_factory=list)
    abstained: bool = False
    receipt: dict = field(default_factory=dict)


class BaseRetriever(ABC):
    """Abstract interface for baseline and experimental retrieval engines."""

    @abstractmethod
    def name(self) -> str:
        """Name of the baseline engine (e.g. 'bm25', 'dense_minilm', 'hybrid_rrf', 'trace_tree')."""
        pass

    @abstractmethod
    def index(self, documents: list[IndexedDocument]) -> None:
        """Index the collection of documents."""
        pass

    @abstractmethod
    def retrieve(self, query: str, top_k: int = 10) -> list[RetrievalCandidate]:
        """Retrieve top_k candidates for the query."""
        pass

    def retrieve_with_outcome(self, query: str, top_k: int = 10) -> RetrievalResponse:
        return RetrievalResponse(candidates=self.retrieve(query, top_k))

    def preserved_document_ids(self) -> set[str] | None:
        """Return audited IDs after indexing, or None when preservation is not measured."""
        return None

    def organization_snapshot(self) -> dict | None:
        """Optional measured structure; see docs/RETRIEVER_CONTRACT.md."""
        return None

    def configuration(self) -> dict:
        """Public parameters only; never include API keys or credentials."""
        return {}

    def implementation_identity(self) -> dict:
        """Optional product version/revision evidence beyond the TB wrapper hash."""
        return {}

    def target_identity(self) -> dict | None:
        """Pre/post-run target snapshot for identity verification; None for non-target backends."""
        return None

    def native_pins(self) -> dict | None:
        """Native target pins (birth/epoch/seq) captured after indexing; None when unmeasured."""
        return None

    def cleanup(self) -> None:
        """Release resources created for this benchmark run."""
