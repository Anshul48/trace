"""TB-side integration with the actual tlsys implementation in trace-architecture.

No product code is patched. Each run uses a new temporary store and the product's
supported ingestion/index/query interfaces. This is the Narrow path only.
"""

import os
import sys
import tempfile
from pathlib import Path

from trace_bench.baselines.base import BaseRetriever, RetrievalCandidate, RetrievalResponse
from trace_bench.datasets.loader import compute_sha256, file_sha256

MINILM_REVISION = "1110a243fdf4706b3f48f1d95db1a4f5529b4d41"
ARCHITECTURE_ENV_VAR = "TRACE_ARCHITECTURE_DIR"


def discover_architecture_dir(explicit=None):
    """Locate the read-only product checkout: explicit config, env var, adjacent dirs.

    Returns ``(path, provenance)``. When nothing is found the first adjacent
    candidate is returned with an unusable-default note; ``index()`` then
    raises the actionable error.
    """
    if explicit:
        return Path(explicit).resolve(), "explicit architecture_dir config"
    env = os.environ.get(ARCHITECTURE_ENV_VAR)
    if env:
        return Path(env).resolve(), f"${ARCHITECTURE_ENV_VAR}"
    candidates = [Path.cwd() / "trace-architecture", Path.cwd().parent / "trace-architecture",
                  Path(__file__).resolve().parents[4] / "trace-architecture"]
    for candidate in candidates:
        if (candidate / "tl-sys" / "tlsys").is_dir():
            return candidate, "adjacent-directory discovery"
    return candidates[0], "adjacent-directory discovery (no checkout found)"


class TraceNarrowRetriever(BaseRetriever):
    def __init__(self, architecture_dir=None,
                 model_name="sentence-transformers/all-MiniLM-L6-v2",
                 revision=MINILM_REVISION, query_config=None, selected_name="trace_narrow"):
        self.architecture_dir, self.architecture_provenance = discover_architecture_dir(architecture_dir)
        self.model_name, self.revision = model_name, revision
        self.query_config = dict(query_config or {})
        self._selected_name = selected_name
        self._temporary = None
        self._store = self._index = self._model = None

    def name(self):
        return self._selected_name

    def configuration(self):
        return {"model_name": self.model_name, "revision": self.revision,
                "query_config": self.query_config, "selection_limit": "requested K including exclusions",
                "path": "S-04 Narrow", "chunking": "product defaults: 200 tokens, overlap 50",
                "architecture_provenance": self.architecture_provenance}

    def target_identity(self):
        """Pre/post-run TL snapshot. Pure file reads; never imports, never raises."""
        from trace_bench.target_identity import snapshot_target_identity
        return snapshot_target_identity(self.architecture_dir)

    def native_pins(self):
        """Native TL birth/epoch/seq from the live index triple; None before indexing."""
        triple = getattr(self._index, "triple", None)
        if triple is None:
            return None
        birth, epoch, seq = None, None, None
        try:
            raw_birth, raw_epoch, raw_seq = str(triple).rsplit(":", 2)
            birth, epoch, seq = raw_birth, int(raw_epoch), int(raw_seq)
        except (ValueError, TypeError):
            pass
        return {"tl_birth": birth, "tl_epoch": epoch, "tl_seq": seq, "tl_triple": str(triple)}

    def implementation_identity(self):
        files = []
        for directory in (self.architecture_dir / "tl-sys" / "tlsys",
                          self.architecture_dir / "tl-candidate-batch" / "candidate"):
            files.extend((str(path.relative_to(self.architecture_dir)), file_sha256(path))
                         for path in sorted(directory.glob("*.py")))
        import json
        import sys as _sys
        target = self.target_identity()
        resolved = None
        module_file = getattr(_sys.modules.get("tlsys"), "__file__", None)
        if module_file is not None:
            try:
                resolved = {"tlsys": {"imported": True, "init_sha256": file_sha256(module_file)}}
            except OSError:
                resolved = {"tlsys": {"imported": True, "init_sha256": None}}
        return {"candidate_revision": target.get("candidate_revision"),
                "product_sources_sha256": compute_sha256(json.dumps(files)),
                "target_role": "TL",
                "canonical_engine": "tl_narrow",
                "selected_name": self._selected_name,
                "target_identity": target,
                "resolved_modules": resolved}

    def index(self, documents):
        if os.name == "nt":
            raise RuntimeError("trace_narrow's candidate store requires POSIX locking. Run TB in WSL/Linux; use bm25 on Windows.")
        source = self.architecture_dir / "tl-sys"
        if not (source / "tlsys").is_dir():
            raise FileNotFoundError("Set architecture_dir in --config to the checkout containing tl-sys and tl-candidate-batch.")
        if "tlsys" in sys.modules and Path(sys.modules["tlsys"].__file__).resolve().parent != source / "tlsys":
            raise RuntimeError("A different tlsys checkout is already imported; start a fresh process.")
        sys.path.insert(0, str(source))
        from trace_bench.target_identity import no_target_bytecode
        with no_target_bytecode():
            # Never write bytecode caches into the read-only target checkout.
            from sentence_transformers import SentenceTransformer
            from tlsys.store_if import TLStore
            from tlsys.ingest import ingest_docs
            from tlsys.index import NarrowIndex
        self._model = SentenceTransformer(self.model_name, revision=self.revision)
        self._temporary = tempfile.TemporaryDirectory(prefix="tb_trace_narrow_")
        self._store = TLStore(str(Path(self._temporary.name) / "store"), create=True, lease_owner="trace-bench")
        embed = lambda texts: self._model.encode(texts, normalize_embeddings=True).tolist()
        ingest_docs(self._store, [(d.doc_id, f"{d.title}\n{d.text}".strip()) for d in documents], embed)
        self._index = NarrowIndex(self._store, self._store.pin())

    def retrieve_with_outcome(self, query, top_k=10):
        from trace_bench.target_identity import no_target_bytecode
        with no_target_bytecode():
            from tlsys.query import NarrowQuery
        cfg = {**self.query_config, "MAX_ENTRIES": top_k}
        embed = lambda text: self._model.encode(text, normalize_embeddings=True).tolist()
        dossier, receipt = NarrowQuery(self._store, self._index, embed, cfg=cfg).run(query)
        if receipt["execution"]["status"] != "complete":
            raise RuntimeError(f"Trace returned incomplete execution: {receipt['execution']}")
        receipt["storage_calls"] = self._store.trace.summary()
        entries = dossier["entries"]
        # Examined-no-support is an explicit decision; no-emission is merely empty.
        abstained = not entries and receipt["support_findings"] == "examined-no-support"
        return RetrievalResponse(candidates=[RetrievalCandidate(
            e["doc_id"], e["emitted_score"], e["text"], metadata={"atom_id": e["atom_id"],
                "span": e["span"], "generation": e["resolving_generation"]}) for e in entries],
            abstained=abstained, receipt=receipt)

    def retrieve(self, query, top_k=10):
        return self.retrieve_with_outcome(query, top_k).candidates

    def preserved_document_ids(self):
        return set(self._index.doc_atoms)

    def organization_snapshot(self):
        memberships = [h["members"] for h in self._index.holons.values()]
        return {"source_atom_ids": list(self._index.atoms),
                "indexed_atom_ids": [aid for group in memberships for aid in group],
                "memberships": memberships, "evidence": {
                    "generation": self._index.triple, "path": "committed per-document holons",
                    "storage_calls": self._store.trace.summary()}}

    def cleanup(self):
        if self._store is not None:
            self._store.close()
            self._store = None
        if self._temporary is not None:
            self._temporary.cleanup()
            self._temporary = None
