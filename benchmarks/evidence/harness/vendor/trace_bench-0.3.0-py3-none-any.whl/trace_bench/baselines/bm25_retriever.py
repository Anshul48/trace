"""Self-contained BM25 with compact postings and vectorized scoring."""

import math
import re
from array import array
from collections import Counter
import numpy as np
from trace_bench.baselines.base import BaseRetriever, IndexedDocument, RetrievalCandidate


def tokenize(text: str) -> list[str]:
    """Lowercase word tokenizer."""
    return re.findall(r"\b[a-zA-Z0-9_]+\b", text.lower())


class BM25Retriever(BaseRetriever):
    """
    Standard Okapi BM25 lexical retriever.
    Implements the same smoothed Okapi formula without rank_bm25 or a server.
    NumPy scoring retains query-token addition order and input-order tie breaks.
    """

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.documents: list[IndexedDocument] = []
        self.doc_len: list[int] = []
        self.avg_doc_len: float = 0.0
        self.doc_freqs: dict[str, int] = {}
        self.idf: dict[str, float] = {}
        self.num_docs: int = 0
        self.postings: dict[str, tuple[np.ndarray, np.ndarray]] = {}
        self.length_normalization = np.empty(0)

    def name(self) -> str:
        return "bm25"

    def configuration(self) -> dict:
        return {"k1": self.k1, "b": self.b, "tokenizer": "ascii_word_lower",
                "implementation": "trace_bench_numpy_bm25", "score_dtype": "float64",
                "tie_break": "corpus_input_order"}

    def preserved_document_ids(self) -> set[str]:
        return {d.doc_id for d in self.documents}

    def index(self, documents: list[IndexedDocument]) -> None:
        self.documents = list(documents)
        self.num_docs = len(self.documents)
        self.doc_len = []
        self.doc_freqs = Counter()
        self.postings = {}
        self.idf = {}
        self.avg_doc_len = 0.0
        self.length_normalization = np.empty(0)
        if self.num_docs == 0:
            return
        buffers = {}

        total_len = 0
        for position, doc in enumerate(self.documents):
            tokens = tokenize(doc.text + " " + doc.title)
            t_len = len(tokens)
            self.doc_len.append(t_len)
            total_len += t_len

            counts = Counter(tokens)
            for term, frequency in counts.items():
                self.doc_freqs[term] += 1
                if term not in buffers:
                    buffers[term] = (array("Q"), array("Q"))
                buffers[term][0].append(position)
                buffers[term][1].append(frequency)

        self.avg_doc_len = total_len / self.num_docs if self.num_docs > 0 else 0.0
        self.postings = {term: (np.frombuffer(ids, dtype=np.uint64), np.frombuffer(counts, dtype=np.uint64))
                         for term, (ids, counts) in buffers.items()}
        # Precompute using the original Python arithmetic order for exact parity.
        self.length_normalization = np.asarray([
            self.k1 * (1.0 - self.b + self.b * (length / self.avg_doc_len if self.avg_doc_len > 0 else 1.0))
            for length in self.doc_len], dtype=np.float64)

        # Compute Robertson-Spärck Jones IDF with smoothing
        self.idf = {}
        for term, df in self.doc_freqs.items():
            self.idf[term] = math.log(1.0 + (self.num_docs - df + 0.5) / (df + 0.5))

    def retrieve(self, query: str, top_k: int = 10) -> list[RetrievalCandidate]:
        if self.num_docs == 0 or top_k < 1:
            return []

        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        scores = np.zeros(self.num_docs, dtype=np.float64)
        for token in query_tokens:
            if token not in self.idf:
                continue
            indices, frequencies = self.postings[token]
            contribution = self.idf[token] * ((frequencies * (self.k1 + 1.0)) /
                                             (frequencies + self.length_normalization[indices]))
            # Each term's posting IDs are unique; repeated query tokens are added
            # separately, preserving the original scalar floating-point order.
            scores[indices] += contribution

        positive = np.flatnonzero(scores > 0)
        if len(positive) > top_k:
            cutoff = np.partition(scores[positive], len(positive)-top_k)[len(positive)-top_k]
            above = positive[scores[positive] > cutoff]
            tied = positive[scores[positive] == cutoff][:top_k-len(above)]
            positive = np.concatenate((above, tied))
        ranked_indices = sorted(positive.tolist(), key=lambda idx: (-scores[idx], idx))
        results: list[RetrievalCandidate] = []
        for idx in ranked_indices[:top_k]:
            if scores[idx] > 0.0:
                doc = self.documents[idx]
                results.append(
                    RetrievalCandidate(
                        doc_id=doc.doc_id,
                        score=float(scores[idx]),
                        text=doc.text,
                        metadata=doc.metadata,
                    )
                )
        return results
