"""Flat Dense Vector Baseline Retriever using SentenceTransformers."""

import numpy as np
from trace_bench.baselines.base import BaseRetriever, IndexedDocument, RetrievalCandidate


class DenseRetriever(BaseRetriever):
    """
    Flat dense nearest-neighbor retriever using sentence-transformers embeddings.
    Defaults to all-MiniLM-L6-v2, supports any SentenceTransformer model.
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2", revision: str | None = None):
        self.model_name = model_name
        self.revision = revision or ("1110a243fdf4706b3f48f1d95db1a4f5529b4d41" if model_name in (
            "all-MiniLM-L6-v2", "sentence-transformers/all-MiniLM-L6-v2") else None)
        self.documents: list[IndexedDocument] = []
        self.embeddings: np.ndarray | None = None
        self._model = None

    def _get_model(self):
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as e:
                raise RuntimeError('Dense retrieval requires: pip install "trace-bench[dense]"') from e
            self._model = SentenceTransformer(self.model_name, revision=self.revision)
        return self._model

    def name(self) -> str:
        clean_model = self.model_name.split("/")[-1].replace("-", "_")
        return f"dense_{clean_model}"

    def index(self, documents: list[IndexedDocument]) -> None:
        self.documents = list(documents)
        if not self.documents:
            self.embeddings = None
            return

        model = self._get_model()
        texts = [f"{d.title} {d.text}".strip() for d in self.documents]
        raw_embs = model.encode(texts, convert_to_numpy=True, normalize_embeddings=True)
        self.embeddings = np.ascontiguousarray(raw_embs, dtype=np.float32)

    def configuration(self) -> dict:
        return {"model_name": self.model_name, "revision": self.revision,
                "max_seq_length": getattr(self._model, "max_seq_length", None),
                "device": str(self._model.device) if self._model is not None else None,
                "normalization": "unit", "similarity": "cosine"}

    def preserved_document_ids(self) -> set[str]:
        return {d.doc_id for d in self.documents} if self.embeddings is not None else set()

    def retrieve(self, query: str, top_k: int = 10) -> list[RetrievalCandidate]:
        if self.embeddings is None or len(self.documents) == 0:
            return []

        model = self._get_model()
        q_emb = model.encode([query], convert_to_numpy=True, normalize_embeddings=True)[0]
        q_emb = np.ascontiguousarray(q_emb, dtype=np.float32)

        # Cosine similarity on unit vectors is simply dot product
        similarities = np.dot(self.embeddings, q_emb)
        top_indices = np.argsort(-similarities)[:top_k]

        results: list[RetrievalCandidate] = []
        for idx in top_indices:
            doc = self.documents[idx]
            results.append(
                RetrievalCandidate(
                    doc_id=doc.doc_id,
                    score=float(similarities[idx]),
                    text=doc.text,
                    metadata=doc.metadata,
                )
            )
        return results
