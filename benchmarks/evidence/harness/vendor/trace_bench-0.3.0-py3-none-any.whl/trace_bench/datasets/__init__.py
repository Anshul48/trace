"""Benchmark dataset definitions, schemas, and loader utilities."""

from trace_bench.datasets.schema import BenchmarkManifest, BenchmarkCase, QueryCategory
from trace_bench.datasets.loader import (
    load_manifest,
    compute_sha256,
    verify_corpus_integrity,
    DatasetIntegrityError,
)

__all__ = [
    "BenchmarkManifest",
    "BenchmarkCase",
    "QueryCategory",
    "load_manifest",
    "compute_sha256",
    "verify_corpus_integrity",
    "DatasetIntegrityError",
]
