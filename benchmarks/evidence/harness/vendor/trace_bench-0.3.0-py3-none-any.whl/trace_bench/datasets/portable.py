"""Portable dataset snapshots, discovery, and import of the existing D2B cache.

Only evaluation inputs are materialized. Raw snapshots and verification archives
stay at their original locations. Native document IDs and explicit splits survive.
"""

import csv
import json
import os
import sys
from dataclasses import asdict
from pathlib import Path

from trace_bench.baselines.base import IndexedDocument
from trace_bench.datasets.loader import (
    DatasetIntegrityError, compute_sha256, file_sha256, load_manifest,
    documents_from_manifest, validate_evaluation_inputs,
)
from trace_bench.datasets.schema import BenchmarkCase, BenchmarkManifest

BEIR_DATASETS = ("scifact", "nfcorpus", "fiqa", "arguana")
BRIGHT_TASKS = ("biology", "earth_science", "economics", "psychology", "robotics",
               "stackoverflow", "sustainable_living", "leetcode", "pony", "aops",
               "theoremqa_questions", "theoremqa_theorems")

CATALOG_VERSION = "tb-catalog-v1"


def load_catalog() -> dict:
    """Load the machine-readable dataset support matrix (never downloads)."""
    catalog = json.loads((Path(__file__).parent / "catalog.json").read_text(encoding="utf-8"))
    if catalog.get("version") != CATALOG_VERSION:
        raise ValueError(f"Unsupported catalog version: {catalog.get('version')}")
    return catalog


def _entry_datasets(entry: dict) -> list[tuple[str, str]]:
    """Map a catalog entry to (dataset, split) probes for live readiness."""
    catalog_id = entry["catalog_id"]
    if catalog_id in ("smoke", "curated"):
        return [(catalog_id, "test")]
    if catalog_id.startswith("beir-"):
        return [(catalog_id.removeprefix("beir-"), entry.get("split", "test"))]
    if catalog_id.startswith("bright-") and catalog_id != "bright-uncached":
        task = {"bright-theoremqa-questions": "theoremqa_questions",
                "bright-theoremqa-theorems": "theoremqa_theorems"}.get(catalog_id, catalog_id.removeprefix("bright-"))
        return [(f"bright-{task}", "test")]
    return []


def catalog_readiness(entry: dict, root=None) -> str:
    """Live readiness for one entry. Pure local checks; never downloads."""
    for name, split in _entry_datasets(entry):
        try:
            resolve_dataset(name, root, split)
            return "ready"
        except FileNotFoundError:
            return "run setup"
    catalog_id = entry["catalog_id"]
    if catalog_id.startswith("workload-") or catalog_id == "hv-demo-micro":
        from trace_bench.workloads import FIXTURE_DIR

        return "ready" if FIXTURE_DIR.is_dir() else "wheel data missing"
    if catalog_id == "hv-profile":
        return "stage package"
    if catalog_id == "bright-uncached":
        return "network fetch on setup"
    if catalog_id == "d2b-import":
        cache = data_root(root)
        return "importable" if (cache / "normalized").is_dir() else "no normalized cache"
    if catalog_id == "scale-synthetic":
        return "generator ready"
    if entry["tier"] == "unsupported":
        return "unsupported"
    return "manual"


def data_root(explicit: str | Path | None = None) -> Path:
    if explicit or os.environ.get("TRACE_BENCH_DATA"):
        return Path(explicit or os.environ["TRACE_BENCH_DATA"]).expanduser().resolve()
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "trace-bench-data"
    return Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "trace-bench-data"


def jsonl(path: Path):
    with path.open(encoding="utf-8") as source:
        for number, line in enumerate(source, 1):
            if line.strip():
                try:
                    yield json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"Invalid JSON at {path}:{number}") from exc


def resolve_dataset(name: str | Path, root: str | Path | None = None, split: str = "test") -> Path:
    path = Path(name)
    if path.exists():
        return path.resolve()
    aliases = {"smoke": "technical_docs_dev.json", "curated": "trace_engineering_curated.json"}
    if str(name) in aliases:
        return Path(__file__).parent / aliases[str(name)]
    cache = data_root(root)
    slug = str(name).removeprefix("beir-")
    candidates = [cache / "prepared" / str(name) / split / "manifest.json",
                  cache / "prepared" / f"beir-{slug}" / split / "manifest.json"]
    if slug in BEIR_DATASETS:
        candidates.extend([cache / f"beir-{slug}" / "raw" / slug,
                           cache / slug, cache / f"beir-{slug}"])
    candidates.extend(sorted((cache / "normalized").glob(f"*/{name}"), reverse=True))
    for candidate in candidates:
        if candidate.is_file() or (candidate.is_dir() and (
            (candidate / "qrels").exists() or (candidate / "judgment-evidence-maps.jsonl").exists()
        )):
            return candidate
    raise FileNotFoundError(f"Dataset '{name}' is not ready in {cache}. Run: trace-bench setup --dataset {name}")


def _beir(directory: Path, split: str):
    from trace_bench.adapters.beir_adapter import BeirAdapter
    adapter = BeirAdapter(directory.name.removeprefix("beir-"), directory.parent, split=split)
    adapter.dataset_dir = directory
    acquisition = directory.parent.parent / "source-record.json"
    record = json.loads(acquisition.read_text(encoding="utf-8")) if acquisition.exists() else {}
    return from_adapter(adapter, metadata={"suite": "BEIR", "split": split,
        "license": record.get("license", "not recorded; see upstream dataset license"),
        "source_version": record.get("version", "not recorded"),
        "acquisition_record_sha256": file_sha256(acquisition) if acquisition.exists() else None,
        "source_url": record.get("official_url", "https://github.com/beir-cellar/beir"),
        "citation": record.get("citation", "not recorded; see upstream dataset documentation"),
        "upstream_repository": record.get("upstream_repository"),
        "ignore_identical_query_document_ids": True, "protocol_status": "official_split"})


def from_adapter(adapter, metadata: dict | None = None):
    docs = [IndexedDocument(d.doc_id, d.text, d.title, d.metadata) for d in adapter.load_corpus()]
    cases = []
    for query in adapter.load_queries():
        category = query.category if query.category in BenchmarkCase.model_fields["category"].annotation.__args__ else "direct_lookup"
        cases.append(BenchmarkCase(id=query.query_id, native_query_id=query.query_id,
            category=category, query=query.text, gold_atom_ids=list(dict.fromkeys(query.gold_doc_ids)),
            native_gold_doc_ids=list(dict.fromkeys(query.gold_doc_ids)),
            relevance_scores=query.relevance_scores,
            excluded_doc_ids=query.metadata.get("excluded_ids", []),
            expected_abstention=query.metadata.get("expected_abstention", not query.gold_doc_ids),
            metadata=query.metadata))
    manifest = BenchmarkManifest(name=adapter.dataset_name(), corpus_sha256="",
        cases=cases, metadata={**(metadata or {}), "evaluation_unit": "document"})
    manifest.metadata.setdefault("license", "not recorded; see upstream dataset license")
    validate_evaluation_inputs(manifest, docs)
    # Canonical semantic identity for direct runs; prepared snapshots use file bytes.
    manifest.corpus_sha256 = compute_sha256("\n".join(
        json.dumps(asdict(d), sort_keys=True, ensure_ascii=False) for d in docs))
    return manifest, docs


def _normalized(directory: Path, split: str):
    """D2B snapshots are document-level, never fabricated atom-level judgments."""
    consumed = ["corpus.jsonl", "queries.jsonl", "judgment-evidence-maps.jsonl"]
    checksum_file = directory.parent / "checksums.json"
    if checksum_file.exists():
        hashes = json.loads(checksum_file.read_text(encoding="utf-8"))["files"]
        for filename in consumed:
            expected = hashes[f"{directory.name}/{filename}"]["sha256"]
            if file_sha256(directory / filename) != expected:
                raise DatasetIntegrityError(f"Normalized input changed: {filename}")
    docs, internal_to_native = [], {}
    for item in jsonl(directory / "corpus.jsonl"):
        native = str(item.get("source_key") or item["native_id"])
        internal_to_native[item["internal_id"]] = native
        docs.append(IndexedDocument(native, item["text"], item.get("title", "")))
    grades = {}
    for item in jsonl(directory / "judgment-evidence-maps.jsonl"):
        if item.get("split") != split:
            continue
        doc_id = internal_to_native[item["source_document_internal_id"]]
        qid = item["query_internal_id"]
        score = float(item["relevance"])
        grades.setdefault(qid, {})[doc_id] = max(score, grades.get(qid, {}).get(doc_id, 0))
    cases = []
    for item in jsonl(directory / "queries.jsonl"):
        if item.get("split") != split or item.get("evaluation_status") != "usable":
            continue
        qid = item["internal_id"]
        gold = [k for k, v in grades.get(qid, {}).items() if v > 0]
        # Unjudged queries are not automatically classified as unanswerable.
        if not gold:
            continue
        cases.append(BenchmarkCase(id=qid, native_query_id=str(item["native_query_id"]),
            category=item.get("category", "direct_lookup"), query=item["query"],
            gold_atom_ids=gold, native_gold_doc_ids=gold, relevance_scores=grades[qid],
            metadata={**item.get("metadata", {}), "split": split}))
    manifest = BenchmarkManifest(name=directory.name, version="d2b-import-v2",
        corpus_sha256=file_sha256(directory / "corpus.jsonl"), cases=cases,
        metadata={"suite": "D2B imported", "split": split, "evaluation_unit": "document",
                  "protocol_status": "diagnostic_import", "source_checksums_verified": checksum_file.exists(),
                  "claim_boundary": "Imported split; no official leaderboard equivalence assumed."})
    validate_evaluation_inputs(manifest, docs)
    return manifest, docs


def load_dataset(name: str | Path, root=None, split: str = "test", limit: int | None = None):
    path = resolve_dataset(name, root, split)
    if path.is_dir() and (path / "qrels").exists():
        manifest, docs = _beir(path, split)
    elif path.is_dir() and (path / "judgment-evidence-maps.jsonl").exists():
        manifest, docs = _normalized(path, split)
    else:
        if path.is_dir():
            path = path / "manifest.json"
        raw = json.loads(path.read_text(encoding="utf-8"))
        if raw.get("documents_file"):
            manifest = BenchmarkManifest.model_validate(raw)
            document_file = path.parent / manifest.documents_file
            if not manifest.documents_sha256 or file_sha256(document_file) != manifest.documents_sha256:
                raise DatasetIntegrityError(f"Document file checksum mismatch: {document_file}")
            if manifest.corpus_sha256 != manifest.documents_sha256:
                raise DatasetIntegrityError("Corpus identity disagrees with document file checksum")
            if manifest.metadata.get("cases_sha256") != compute_sha256(json.dumps(
                [c.model_dump() for c in manifest.cases], sort_keys=True, ensure_ascii=False, separators=(",", ":"))):
                raise DatasetIntegrityError("Query/judgment checksum mismatch")
            if manifest.metadata.get("split") != split:
                raise ValueError(f"Snapshot split is {manifest.metadata.get('split')}, requested {split}")
            docs = [IndexedDocument(**item) for item in jsonl(document_file)]
        else:
            manifest, corpus = load_manifest(path)
            docs = documents_from_manifest(manifest, corpus)
    validate_evaluation_inputs(manifest, docs)
    if limit is not None:
        if limit < 1:
            raise ValueError("--limit must be positive")
        manifest = manifest.model_copy(deep=True)
        manifest.cases = manifest.cases[:limit]
        manifest.release_authority = False
        manifest.metadata["query_limit"] = limit
        manifest.metadata["protocol_status"] = "diagnostic_subset"
    return manifest, docs


def write_snapshot(manifest: BenchmarkManifest, docs, directory: Path) -> Path:
    """Write a self-contained input set; never overwrite an existing snapshot."""
    from trace_bench.datasets.loader import case_fingerprint
    validate_evaluation_inputs(manifest, docs)
    if directory.exists():
        raise FileExistsError(f"Snapshot already exists: {directory}; choose a new output directory.")
    directory.mkdir(parents=True)
    corpus = directory / "corpus.jsonl"
    with corpus.open("w", encoding="utf-8", newline="\n") as output:
        for doc in docs:
            output.write(json.dumps(asdict(doc), ensure_ascii=False, sort_keys=True) + "\n")
    digest = file_sha256(corpus)
    portable = manifest.model_copy(deep=True)
    portable.corpus_text = portable.corpus_file = None
    portable.documents_file = "corpus.jsonl"
    portable.documents_sha256 = portable.corpus_sha256 = digest
    portable.source_mappings = []
    portable.release_authority = False
    portable.metadata["cases_sha256"] = case_fingerprint(portable)
    manifest_path = directory / "manifest.json"
    manifest_path.write_text(portable.model_dump_json(indent=2), encoding="utf-8")
    hashes = {name: file_sha256(directory / name) for name in ("manifest.json", "corpus.jsonl")}
    (directory / "checksums.json").write_text(json.dumps(hashes, indent=2), encoding="utf-8")
    return manifest_path


def export_beir(manifest: BenchmarkManifest, docs, directory: Path) -> None:
    """Interchange corpus/queries/qrels using native IDs, with no positive-only cropping."""
    directory.mkdir(parents=True, exist_ok=False)
    doc_ids = {d.doc_id: str(d.metadata.get("native_doc_id", d.doc_id)) for d in docs}
    with (directory / "corpus.jsonl").open("w", encoding="utf-8") as out:
        for doc in docs:
            out.write(json.dumps({"_id": doc_ids[doc.doc_id], "title": doc.title, "text": doc.text}, ensure_ascii=False) + "\n")
    with (directory / "queries.jsonl").open("w", encoding="utf-8") as out:
        for case in manifest.cases:
            out.write(json.dumps({"_id": case.native_query_id or case.id, "text": case.query}, ensure_ascii=False) + "\n")
    (directory / "qrels").mkdir()
    split = manifest.metadata.get("split", "test")
    with (directory / "qrels" / f"{split}.tsv").open("w", encoding="utf-8", newline="") as out:
        writer = csv.writer(out, delimiter="\t")
        writer.writerow(["query-id", "corpus-id", "score"])
        for case in manifest.cases:
            for doc_id, grade in (case.relevance_scores or {i: 1 for i in case.gold_atom_ids}).items():
                writer.writerow([case.native_query_id or case.id, doc_ids[doc_id], grade])
    (directory / "protocol.json").write_text(manifest.model_dump_json(indent=2), encoding="utf-8")
