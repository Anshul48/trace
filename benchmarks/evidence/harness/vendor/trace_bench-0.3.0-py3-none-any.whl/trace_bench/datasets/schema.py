"""Pydantic schemas and error models for benchmark manifests, cases, receipts, and identity."""

from datetime import datetime, timezone
from typing import Literal
from pydantic import BaseModel, Field


ExecutionMode = Literal["unit", "regression", "exploratory", "certification"]

QueryOutcome = Literal[
    "success",
    "explicit_abstention",
    "empty_result",
    "query_failed",
    "excluded",
]

StageName = Literal[
    "preflight",
    "acquisition",
    "index",
    "query",
    "metric",
    "validation",
    "manifest",
]

QueryCategory = Literal[
    "direct_lookup",
    "chronology",
    "contradiction",
    "cross_domain",
    "global_context",
    "multi_hop",
    "historical",
    "out_of_scope",
]


class ErrorReceipt(BaseModel):
    """Structured error receipt emitted whenever a stage or query fails."""
    error_code: str
    stage: StageName
    message: str
    manifest_id: str | None = None
    candidate_id: str | None = None
    fallback_forbidden: bool = True
    timestamp_utc: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    environment_fingerprint: dict = Field(default_factory=dict)
    exception_type: str | None = None
    details: dict = Field(default_factory=dict)


class TraceLiteArtifactIdentity(BaseModel):
    """Reproducible artifact and runtime identity for Trace / Trace-Lite under test."""
    package_name: str = "trace-lite"
    package_version: str = "0.1.0"
    commit_hash: str | None = None
    wheel_hash_sha256: str | None = None
    python_version: str = ""
    runtime_platform: str = ""
    dependency_fingerprint_sha256: str = ""
    config_hash_sha256: str = ""
    is_editable: bool = False
    is_pinned: bool = False
    is_certification_eligible: bool = False


class DatasetAdmission(BaseModel):
    """Official admission record for benchmark datasets (governed by DEC-P-001)."""
    dataset_name: str
    version: str = "1.0.0"
    license: str = "Apache-2.0"
    source_url: str = ""
    sha256_checksum: str = ""
    is_admitted: bool = False
    admission_decision: str = "DEC-P-001"
    evidence_type: str = "real_data"


class SourceMapping(BaseModel):
    """Reversible mapping between native dataset IDs and internal atom / segment IDs."""
    dataset_name: str
    native_id: str
    internal_id: str
    entity_type: Literal["document", "query", "atom", "segment"] = "document"
    source_hash: str = ""
    char_offset_start: int | None = None
    char_offset_end: int | None = None
    metadata: dict = Field(default_factory=dict)


class ModelProviderFingerprint(BaseModel):
    """Strict configuration fingerprint of the LLM or embedding provider."""
    provider: str
    model_name: str
    temperature: float = 0.0
    endpoint_url: str | None = None
    model_version_or_hash: str | None = None
    strict_tls: bool = True
    is_mock: bool = False
    is_certification_eligible: bool = False


class BenchmarkCase(BaseModel):
    """A single reviewed query evaluation case with ground-truth evidence."""
    id: str
    native_query_id: str | None = None
    category: QueryCategory
    query: str
    gold_atom_ids: list[str] = Field(default_factory=list)
    native_gold_doc_ids: list[str] = Field(default_factory=list)
    acceptable_alternative_ids: list[str] = Field(default_factory=list)
    expected_abstention: bool = False
    relevance_scores: dict[str, float] = Field(default_factory=dict)
    excluded_doc_ids: list[str] = Field(default_factory=list)
    difficulty: str = "medium"
    metadata: dict = Field(default_factory=dict)


class BenchmarkManifest(BaseModel):
    """Manifest representing a frozen benchmark corpus and query judgment set."""
    name: str
    version: str = "1.0.0"
    description: str = ""
    corpus_sha256: str
    corpus_text: str | None = None
    corpus_file: str | None = None
    documents_file: str | None = None
    documents_sha256: str | None = None
    release_authority: bool = False
    mode: ExecutionMode = "regression"
    admission: DatasetAdmission | None = None
    source_mappings: list[SourceMapping] = Field(default_factory=list)
    cases: list[BenchmarkCase] = Field(default_factory=list)
    metadata: dict = Field(default_factory=dict)


# --- Custom Benchmark Exception Hierarchy ---

class BenchmarkStageError(Exception):
    """Base exception for fail-closed benchmark execution stages."""
    def __init__(self, error_code: str, stage: StageName, message: str, details: dict | None = None):
        super().__init__(f"[{stage.upper()}] {error_code}: {message}")
        self.error_code = error_code
        self.stage = stage
        self.message = message
        self.details = details or {}

    def to_receipt(self, manifest_id: str | None = None, env_fingerprint: dict | None = None) -> ErrorReceipt:
        return ErrorReceipt(
            error_code=self.error_code,
            stage=self.stage,
            message=self.message,
            manifest_id=manifest_id,
            fallback_forbidden=True,
            environment_fingerprint=env_fingerprint or {},
            exception_type=self.__class__.__name__,
            details=self.details,
        )


class PreflightError(BenchmarkStageError):
    def __init__(self, error_code: str, message: str, details: dict | None = None):
        super().__init__(error_code=error_code, stage="preflight", message=message, details=details)


class AcquisitionError(BenchmarkStageError):
    def __init__(self, error_code: str, message: str, details: dict | None = None):
        super().__init__(error_code=error_code, stage="acquisition", message=message, details=details)


class IndexStageError(BenchmarkStageError):
    def __init__(self, error_code: str, message: str, details: dict | None = None):
        super().__init__(error_code=error_code, stage="index", message=message, details=details)


class QueryStageError(BenchmarkStageError):
    def __init__(self, error_code: str, message: str, details: dict | None = None):
        super().__init__(error_code=error_code, stage="query", message=message, details=details)


class MetricError(BenchmarkStageError):
    def __init__(self, error_code: str, message: str, details: dict | None = None):
        super().__init__(error_code=error_code, stage="metric", message=message, details=details)


class UnstableQueryPairingError(MetricError):
    def __init__(self, message: str, details: dict | None = None):
        super().__init__(error_code="ERR_UNSTABLE_QUERY_PAIRING", message=message, details=details)


# Standard Error Code Constants
ERR_MOCK_PROVIDER_FORBIDDEN = "ERR_MOCK_PROVIDER_FORBIDDEN"
ERR_INSECURE_TLS_FORBIDDEN = "ERR_INSECURE_TLS_FORBIDDEN"
ERR_CHECKSUM_MISMATCH = "ERR_CHECKSUM_MISMATCH"
ERR_DATASET_NOT_ADMITTED = "ERR_DATASET_NOT_ADMITTED"
ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN = "ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN"
ERR_MISSING_SOURCE_IDENTITY = "ERR_MISSING_SOURCE_IDENTITY"
ERR_EDITABLE_IMPORT_FORBIDDEN = "ERR_EDITABLE_IMPORT_FORBIDDEN"
ERR_UNAVAILABLE_PROVIDER = "ERR_UNAVAILABLE_PROVIDER"
ERR_INDEX_FAILED = "ERR_INDEX_FAILED"
ERR_QUERY_FAILED = "ERR_QUERY_FAILED"
ERR_QUERY_TIMEOUT = "ERR_QUERY_TIMEOUT"
ERR_UNSUPPORTED_BACKEND = "ERR_UNSUPPORTED_BACKEND"
ERR_FORCED_FALLBACK_FORBIDDEN = "ERR_FORCED_FALLBACK_FORBIDDEN"
ERR_MISSING_EVIDENCE_MAPPING = "ERR_MISSING_EVIDENCE_MAPPING"
ERR_UNSTABLE_QUERY_PAIRING = "ERR_UNSTABLE_QUERY_PAIRING"
ERR_FABRICATED_COVERAGE = "ERR_FABRICATED_COVERAGE"
ERR_UNHANDLED_STAGE_FAILURE = "ERR_UNHANDLED_STAGE_FAILURE"
ERR_TARGET_IDENTITY_DRIFT = "ERR_TARGET_IDENTITY_DRIFT"
