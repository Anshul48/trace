"""Dataset commands: discover, freeze, interchange, and share verified inputs."""

import importlib.metadata
import importlib.util
import gzip
import json
import os
import re
import tarfile
import tempfile
from pathlib import Path

import click

from trace_bench.datasets.loader import file_sha256
from trace_bench.datasets.schema import BenchmarkStageError
from trace_bench.datasets.portable import (
    BEIR_DATASETS, BRIGHT_TASKS, catalog_readiness, data_root, export_beir, from_adapter,
    load_catalog, load_dataset, resolve_dataset, write_snapshot,
)


def prepare_public(dataset: str, root=None, split: str = "test", output_dir=None) -> Path:
    cache = data_root(root)
    clean = dataset.removeprefix("beir-")
    if clean in BEIR_DATASETS:
        try:
            manifest, docs = load_dataset(clean, cache, split)
        except FileNotFoundError:
            from trace_bench.adapters.beir_adapter import BeirAdapter
            adapter = BeirAdapter(clean, cache / "downloads", split=split)
            adapter.download_or_prepare()
            manifest, docs = from_adapter(adapter, {"suite": "BEIR", "split": split,
                "source_url": "https://github.com/beir-cellar/beir",
                "protocol_status": "official_split", "ignore_identical_query_document_ids": True})
    elif dataset.startswith("bright-"):
        task = dataset.removeprefix("bright-")
        if task not in BRIGHT_TASKS:
            raise ValueError(f"Specify a BRIGHT task: {', '.join(BRIGHT_TASKS)}")
        if split != "test":
            raise ValueError("BRIGHT public examples use the test protocol in TB; choose --split test.")
        from trace_bench.adapters.bright_adapter import BrightAdapter
        adapter = BrightAdapter(task, cache)
        adapter.download_or_prepare()
        official = all((adapter.raw_dir / group / f"{task}-00000-of-00001.parquet").is_file()
                       for group in ("documents", "examples"))
        manifest, docs = from_adapter(adapter, {"suite": "BRIGHT", "split": split,
            "task": task, "context": "short" if official else "unspecified",
            "protocol_status": "official_task_inputs" if official else "manual_diagnostic_import",
            "source_url": "https://huggingface.co/datasets/xlangai/BRIGHT",
            "source_revision": adapter.revision,
            "license": "CC-BY-4.0" if official else "not recorded; verify source license"})
    else:
        raise ValueError("Automatic setup supports BEIR and bright-<task>. Import other existing snapshots with datasets import.")
    destination = Path(output_dir) if output_dir else cache / "prepared" / manifest.name / split
    if not output_dir and (destination / "manifest.json").exists():
        load_dataset(destination / "manifest.json", split=split)
        return destination / "manifest.json"
    return write_snapshot(manifest, docs, destination)


@click.group("datasets")
def datasets_command():
    """Find, prepare, import, export and share dataset inputs."""


@datasets_command.command("list")
@click.option("--data-dir", type=click.Path(path_type=Path))
def list_command(data_dir):
    cache = data_root(data_dir)
    click.echo(f"Dataset cache: {cache}")
    for name in ("smoke", "curated", *BEIR_DATASETS, *(f"bright-{t}" for t in BRIGHT_TASKS)):
        try:
            path = resolve_dataset(name, cache)
            click.echo(f"{name:28} ready  {path}")
        except FileNotFoundError:
            raw = cache / "bright" / "raw" / "documents" / f"{name.removeprefix('bright-')}-00000-of-00001.parquet"
            click.echo(f"{name:28} {'raw available; run setup' if raw.exists() else 'run setup'}")
    click.echo("D2B normalized snapshots: use datasets import --source PATH --split SPLIT.")
    click.echo("ANN vectors are operations inputs; LongMemEval answer accuracy requires its official evaluator.")


@datasets_command.command("catalog")
@click.option("--data-dir", type=click.Path(path_type=Path))
@click.option("--tier", default=None, help="Filter by support tier.")
@click.option("--format", "out_format", default="table", type=click.Choice(["table", "json"]))
def catalog_command(data_dir, tier, out_format):
    """Show the machine-readable dataset support matrix with live readiness (offline)."""
    catalog = load_catalog()
    entries = [e for e in catalog["entries"] if tier is None or e["tier"] == tier]
    if tier is not None and not entries:
        raise click.ClickException(f"Unknown tier '{tier}'. Tiers: {', '.join(catalog['tiers'])}")
    if out_format == "json":
        merged = [{**entry, "readiness": catalog_readiness(entry, data_dir)} for entry in entries]
        click.echo(json.dumps({"version": catalog["version"], "tiers": catalog["tiers"],
                               "entries": merged}, indent=2))
        return
    click.echo(f"{'catalog_id':28} {'tier':14} {'readiness':22} entry")
    for entry in entries:
        click.echo(f"{entry['catalog_id']:28} {entry['tier']:14} "
                   f"{catalog_readiness(entry, data_dir):22} {entry['entry']}")


@datasets_command.command("info")
@click.option("--dataset", required=True, help="Catalog ID or dataset name.")
@click.option("--data-dir", type=click.Path(path_type=Path))
@click.option("--remote/--no-remote", default=False,
              help="Probe upstream Content-Length (best effort; --no-remote stays offline).")
def info_command(dataset, data_dir, remote):
    """Show provenance, cache footprint, and download estimates when available."""
    from trace_bench.adapters.base import remote_size
    from trace_bench.adapters.beir_adapter import BeirAdapter

    catalog = load_catalog()
    entry = next((e for e in catalog["entries"]
                  if e["catalog_id"] == dataset or e["catalog_id"].endswith(f"-{dataset}")
                  or e["task"] == dataset), None)
    if entry is None:
        raise click.ClickException(f"Unknown dataset '{dataset}'. See: trace-bench datasets catalog")
    click.echo(f"{entry['catalog_id']} [{entry['tier']}] — {entry['limitations']}")
    click.echo(f"Entry: {entry['entry']}")
    click.echo(f"License: {entry['license']}")
    upstream = entry["upstream"]
    click.echo(f"Upstream: {upstream['source_url'] or 'unknown'} (revision: {upstream['revision'] or 'unknown'})")
    cache = data_root(data_dir)
    total = 0
    for probe in (cache / "prepared", cache / f"beir-{dataset}", cache / dataset,
                  cache / "bright" / "raw"):
        if probe.is_dir():
            total += sum(p.stat().st_size for p in probe.rglob("*") if p.is_file())
    click.echo(f"Cache footprint under {cache}: {total:,} bytes (prepared + raw probes)")
    if not remote:
        click.echo("Remote estimate: unknown (use --remote for a best-effort HEAD probe)")
        return
    urls: list[str] = []
    if entry["catalog_id"].startswith("beir-"):
        urls = [BeirAdapter.BEIR_BASE_URL.format(dataset=entry["task"])]
    elif entry["catalog_id"].startswith("bright-") and entry["catalog_id"] != "bright-uncached":
        task = entry["task"]
        urls = [f"https://huggingface.co/datasets/xlangai/BRIGHT/resolve/main/{g}/{task}-00000-of-00001.parquet"
                for g in ("documents", "examples")]
    if not urls:
        click.echo("Remote estimate: no direct download URL for this entry")
        return
    sizes = [(url, remote_size(url)) for url in urls]
    if all(size is None for _, size in sizes):
        click.echo("Remote estimate: unknown (HEAD probe failed or no Content-Length)")
    else:
        for url, size in sizes:
            click.echo(f"Remote estimate: {url} -> {f'{size:,} bytes' if size else 'unknown'}")
        click.echo("Expanded size after extraction: unknown (not advertised upstream)")


@datasets_command.command("import")
@click.option("--source", required=True, type=click.Path(exists=True, path_type=Path))
@click.option("--split", default="test")
@click.option("--output-dir", required=True, type=click.Path(path_type=Path))
def import_command(source, split, output_dir):
    """Freeze an existing BEIR, TB or D2B input set without changing the source."""
    try:
        manifest, docs = load_dataset(source, split=split)
        click.echo(write_snapshot(manifest, docs, output_dir))
    except (OSError, ValueError, RuntimeError, BenchmarkStageError) as exc:
        raise click.ClickException(str(exc)) from exc


@datasets_command.command("export")
@click.option("--dataset", required=True)
@click.option("--data-dir", type=click.Path(path_type=Path))
@click.option("--split", default="test")
@click.option("--output-dir", required=True, type=click.Path(path_type=Path))
def export_command(dataset, data_dir, split, output_dir):
    """Export native-ID corpus, queries and graded qrels for other suites."""
    try:
        manifest, docs = load_dataset(dataset, data_dir, split)
        export_beir(manifest, docs, output_dir)
        click.echo(output_dir)
    except (OSError, ValueError, BenchmarkStageError) as exc:
        raise click.ClickException(str(exc)) from exc


@datasets_command.command("pack")
@click.option("--dataset", required=True)
@click.option("--data-dir", type=click.Path(path_type=Path))
@click.option("--split", default="test")
@click.option("--output", required=True, type=click.Path(path_type=Path))
def pack_command(dataset, data_dir, split, output):
    """Bundle only corpus, queries, judgments and checksums; omit raw/replay archives."""
    try:
        if output.exists():
            raise FileExistsError(f"Bundle already exists: {output}")
        manifest, docs = load_dataset(dataset, data_dir, split)
        manifest.metadata.setdefault("split", split)
        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="tb_pack_") as temporary:
            snapshot = Path(temporary) / "snapshot"
            write_snapshot(manifest, docs, snapshot)
            # No local filename, clock time, owner or mode affects bundle bytes.
            with output.open("xb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as compressed, \
                    tarfile.open(fileobj=compressed, mode="w") as archive:
                for name in ("manifest.json", "corpus.jsonl", "checksums.json"):
                    info = archive.gettarinfo(str(snapshot / name), arcname=name)
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ""
                    info.mode = 0o644
                    with (snapshot / name).open("rb") as source:
                        archive.addfile(info, source)
        click.echo(f"Bundle: {output} ({output.stat().st_size:,} bytes)")
        click.echo(f"SHA-256: {file_sha256(output)}")
    except (OSError, ValueError, tarfile.TarError, BenchmarkStageError) as exc:
        raise click.ClickException(str(exc)) from exc


@datasets_command.command("unpack")
@click.option("--archive", "archive_path", required=True, type=click.Path(exists=True, path_type=Path))
@click.option("--data-dir", type=click.Path(path_type=Path))
def unpack_command(archive_path, data_dir):
    """Verify and install a portable bundle in the local cache, refusing overwrites."""
    cache = data_root(data_dir)
    cache.mkdir(parents=True, exist_ok=True)
    try:
        with tempfile.TemporaryDirectory(prefix="tb_unpack_", dir=cache) as temporary:
            staging = Path(temporary) / "snapshot"
            staging.mkdir()
            expected = {"manifest.json", "corpus.jsonl", "checksums.json"}
            seen = set()
            with tarfile.open(archive_path, "r:gz") as archive:
                for member in archive:
                    if member.name not in expected or member.name in seen or not member.isfile():
                        raise ValueError(f"Unexpected or unsafe archive member: {member.name}")
                    seen.add(member.name)
                    source = archive.extractfile(member)
                    with (staging / member.name).open("wb") as destination:
                        import shutil
                        shutil.copyfileobj(source, destination)
            if seen != expected:
                raise ValueError("Bundle is missing required inputs")
            checksums = json.loads((staging / "checksums.json").read_text(encoding="utf-8"))
            if set(checksums) != {"manifest.json", "corpus.jsonl"}:
                raise ValueError("Bundle checksum inventory is invalid")
            for filename, digest in checksums.items():
                if file_sha256(staging / filename) != digest:
                    raise ValueError(f"Bundle checksum mismatch: {filename}")
            raw = json.loads((staging / "manifest.json").read_text(encoding="utf-8"))
            name, split = raw["name"], raw["metadata"]["split"]
            if not all(isinstance(value, str) and re.fullmatch(r"[a-zA-Z0-9_.-]+", value)
                       and value not in (".", "..") for value in (name, split)):
                raise ValueError("Invalid dataset name or split in bundle")
            if raw.get("documents_file") != "corpus.jsonl":
                raise ValueError("Bundle must refer to its own corpus.jsonl")
            load_dataset(staging / "manifest.json", split=split)
            destination = cache / "prepared" / name / split
            if destination.exists():
                raise FileExistsError(f"Dataset already exists: {destination}")
            destination.parent.mkdir(parents=True, exist_ok=True)
            os.rename(staging, destination)
        click.echo(destination / "manifest.json")
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError, BenchmarkStageError) as exc:
        raise click.ClickException(str(exc)) from exc


@click.command("doctor")
@click.option("--data-dir", type=click.Path(path_type=Path))
def doctor_command(data_dir):
    """Inspect platform, packages, model/cache and product-checkout state.

    Filesystem and import probes only: no downloads or API calls.
    """
    click.echo(f"Platform: {platform_status()}")
    click.echo(f"Python: {sys_version()}")
    cache = data_root(data_dir)
    click.echo(f"Dataset cache: {cache} ({cache_state(cache)})")
    dense_hint = 'pip install "trace-bench[dense]"'
    torch_hint = ('pip install "trace-bench[dense]" (CPU-only: pip install torch '
                  '--index-url https://download.pytorch.org/whl/cpu alone first; see README)')
    click.echo(f"dense / trace backends: {module_state('sentence_transformers', dense_hint)}")
    click.echo(f"dense compute (torch): {module_state('torch', torch_hint)}")
    click.echo(f"MiniLM weights: {minilm_state()}")
    datasets_hint = 'pip install "trace-bench[datasets]"'
    trace_hint = 'pip install "trace-bench[trace]"'
    click.echo(f"BRIGHT parquet: {module_state('pyarrow', datasets_hint)}")
    click.echo(f"Trace atom identity: {module_state('blake3', trace_hint)}")
    click.echo(f"trace-architecture checkout: {architecture_state()}")
    click.echo("Offline starter: trace-bench quickstart")
    click.echo("Public retrieval: trace-bench setup --dataset scifact")


def platform_status() -> str:
    import platform
    import sys
    system = platform.system()
    if sys.platform.startswith("linux"):
        return f"{system} ({sys.platform}; qualified)"
    return f"{system} ({sys.platform}; NOT qualified — Linux-only acceptance)"


def module_state(module: str, install_hint: str) -> str:
    if importlib.util.find_spec(module) is None:
        return f"optional dependency absent ({install_hint})"
    try:
        version = importlib.metadata.version(module.replace("_", "-"))
    except Exception:
        version = "installed (version unknown)"
    else:
        version = f"installed ({version})"
    return version


def cache_state(cache: Path) -> str:
    prepared = cache / "prepared"
    if not prepared.is_dir():
        return "empty"
    manifests = sorted(prepared.glob("*/*/manifest.json"))
    if not manifests:
        return "empty (override with TRACE_BENCH_DATA or --data-dir)"
    return f"{len(manifests)} prepared snapshot(s): " + ", ".join(
        f"{path.parent.parent.name}/{path.parent.name}" for path in manifests[:8])


def minilm_state() -> str:
    from trace_bench.baselines.trace_narrow_retriever import MINILM_REVISION
    hub = Path(os.environ.get("HUGGINGFACE_HUB_CACHE",
               Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "hub"))
    model_dir = hub / "models--sentence-transformers--all-MiniLM-L6-v2"
    if not model_dir.is_dir():
        return "not cached (~90 MB download on first dense use; revision pinned, see trace_narrow_retriever.MINILM_REVISION)"
    refs = model_dir / "refs" / "main"
    blobs = model_dir / "blobs"
    blob_count = len(list(blobs.iterdir())) if blobs.is_dir() else 0
    if refs.is_file() and refs.read_text(encoding="utf-8").strip() == MINILM_REVISION and blob_count:
        return f"cached at pinned revision {MINILM_REVISION[:12]} ({blob_count} blobs)"
    return (f"partially cached ({blob_count} blobs; pinned revision {MINILM_REVISION[:12]} "
            "not confirmed — first dense use may download)")


def architecture_state() -> str:
    from trace_bench.baselines.trace_narrow_retriever import discover_architecture_dir
    path, provenance = discover_architecture_dir()
    tlsys = path / "tl-sys" / "tlsys"
    if not tlsys.is_dir():
        return (f"not found ({provenance}; tried {path}); set architecture_dir in --config "
                f"or $TRACE_ARCHITECTURE_DIR to the checkout containing tl-sys and tl-candidate-batch")
    init = (tlsys / "__init__.py").read_text(encoding="utf-8") if (tlsys / "__init__.py").is_file() else ""
    match = re.search(r"CANDIDATE_REV\s*=\s*\"([^\"]+)\"", init)
    rev = match.group(1) if match else "unknown"
    warning = "" if (path / "tl-candidate-batch" / "candidate").is_dir() else \
        "; WARNING tl-candidate-batch/candidate missing"
    return f"{path} via {provenance} (CANDIDATE_REV {rev}{warning})"


def sys_version():
    import platform
    return platform.python_version()
