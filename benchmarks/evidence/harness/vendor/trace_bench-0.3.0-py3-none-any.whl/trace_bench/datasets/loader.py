"""Dataset loading, validation, and SHA-256 integrity verification."""

import hashlib
import json
from pathlib import Path
from trace_bench.datasets.schema import (
    BenchmarkManifest,
    BenchmarkCase,
    AcquisitionError,
    PreflightError,
    ERR_CHECKSUM_MISMATCH,
    ERR_DATASET_NOT_ADMITTED,
)


class DatasetIntegrityError(AcquisitionError):
    """Raised when a benchmark dataset fails SHA-256 hash or schema validation."""
    def __init__(self, message: str, details: dict | None = None):
        super().__init__(error_code=ERR_CHECKSUM_MISMATCH, message=message, details=details)


def compute_sha256(text_or_bytes: str | bytes) -> str:
    """Compute SHA-256 hex digest, normalizing string line endings to \\n."""
    if isinstance(text_or_bytes, str):
        normalized = text_or_bytes.replace("\r\n", "\n")
        data = normalized.encode("utf-8")
    else:
        data = text_or_bytes
    return hashlib.sha256(data).hexdigest()


def file_sha256(path: Path | str) -> str:
    """Hash large dataset files without reading them into one bytes object."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def case_fingerprint(manifest: BenchmarkManifest) -> str:
    return compute_sha256(json.dumps(
        [case.model_dump() for case in manifest.cases], sort_keys=True,
        ensure_ascii=False, separators=(",", ":"),
    ))


def document_fingerprint(documents) -> str:
    """Identity over backend-visible document fields (tb-doc-id-v2).

    Covers id, title, text AND metadata: metadata reaches backends (native-id
    mapping, hierarchy, timestamps), so excluding it would let changed inputs
    evade comparability checks. Runs fingerprinted before this fix fail closed
    against newer runs with a clear corpus-identity mismatch.
    """
    digest = hashlib.sha256()
    digest.update(b"tb-doc-id-v2\n")
    for doc in documents:
        digest.update(json.dumps([doc.doc_id, doc.title, doc.text, doc.metadata or {}],
                                 ensure_ascii=False, sort_keys=True, default=str,
                                 separators=(",", ":")).encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()


def documents_from_manifest(manifest: BenchmarkManifest, corpus_text: str):
    """Respect adapter boundaries, including blank lines inside documents."""
    from trace_bench.baselines.base import IndexedDocument

    mappings = [m for m in manifest.source_mappings if m.entity_type == "document"]
    if not mappings:
        return [IndexedDocument(f"atom-{i}", text) for i, text in enumerate(
            p.strip() for p in corpus_text.split("\n\n") if p.strip()
        )]
    documents = []
    for mapping in mappings:
        start, end = mapping.char_offset_start, mapping.char_offset_end
        if start is None or end is None or not 0 <= start <= end <= len(corpus_text):
            raise DatasetIntegrityError(f"Invalid document boundary for {mapping.native_id}")
        text = corpus_text[start:end]
        if mapping.source_hash and compute_sha256(text) != mapping.source_hash:
            raise DatasetIntegrityError(f"Document hash mismatch for {mapping.native_id}")
        documents.append(IndexedDocument(mapping.internal_id, text, metadata={
            **mapping.metadata, "native_doc_id": mapping.native_id,
        }))
    return documents


def validate_evaluation_inputs(manifest: BenchmarkManifest, documents) -> None:
    """Reject ambiguous identity and lost judgments before scoring any engine."""
    ids = [doc.doc_id for doc in documents]
    if not ids or len(ids) != len(set(ids)) or any(not i for i in ids):
        raise PreflightError("ERR_INVALID_DOCUMENT_IDS", "Corpus IDs must be nonempty and unique.")
    case_ids = [case.id for case in manifest.cases]
    if not case_ids or len(case_ids) != len(set(case_ids)):
        raise PreflightError("ERR_INVALID_QUERY_IDS", "Query IDs must be nonempty and unique.")
    known = set(ids)
    for case in manifest.cases:
        gold = set(case.gold_atom_ids)
        if not case.id or not case.query.strip():
            raise PreflightError("ERR_INVALID_QUERY", f"Empty query or ID: {case.id}")
        if not case.expected_abstention and not gold:
            raise PreflightError("ERR_MISSING_EVIDENCE_MAPPING", f"Positive query {case.id} has no gold IDs.")
        if case.expected_abstention and gold:
            raise PreflightError("ERR_INVALID_JUDGMENTS", f"Abstention query {case.id} has positive gold.")
        if gold - known or set(case.excluded_doc_ids) - known:
            raise PreflightError("ERR_MISSING_EVIDENCE_MAPPING", f"Query {case.id} references missing documents.")
        if gold & set(case.excluded_doc_ids):
            raise PreflightError("ERR_INVALID_JUDGMENTS", f"Query {case.id} excludes relevant documents.")
        if case.relevance_scores:
            import math
            if any(not math.isfinite(v) or v < 0 for v in case.relevance_scores.values()):
                raise PreflightError("ERR_INVALID_JUDGMENTS", f"Invalid relevance grades: {case.id}")
            if {k for k, v in case.relevance_scores.items() if v > 0} != gold:
                raise PreflightError("ERR_INVALID_JUDGMENTS", f"Relevance grades disagree with gold: {case.id}")


def verify_corpus_integrity(manifest: BenchmarkManifest, base_dir: Path | None = None) -> str:
    """
    Verify the manifest corpus matches corpus_sha256.
    Returns the resolved corpus text.
    Raises DatasetIntegrityError / AcquisitionError on mismatch or missing corpus.
    """
    corpus_text = ""
    if manifest.corpus_text is not None:
        corpus_text = manifest.corpus_text
    elif manifest.corpus_file is not None:
        file_path = Path(manifest.corpus_file)
        if not file_path.is_absolute() and base_dir is not None:
            file_path = base_dir / file_path
        if not file_path.exists():
            raise DatasetIntegrityError(
                f"Corpus file does not exist: {file_path}",
                details={"file_path": str(file_path)},
            )
        corpus_text = file_path.read_text(encoding="utf-8")
    else:
        raise DatasetIntegrityError("Benchmark manifest must specify either corpus_text or corpus_file")

    computed = compute_sha256(corpus_text)
    if manifest.corpus_sha256 and manifest.corpus_sha256 != computed:
        raise DatasetIntegrityError(
            f"Corpus SHA-256 mismatch! Manifest expected '{manifest.corpus_sha256}', computed '{computed}'",
            details={
                "expected_sha256": manifest.corpus_sha256,
                "computed_sha256": computed,
            },
        )

    return corpus_text


def load_manifest(path: str | Path) -> tuple[BenchmarkManifest, str]:
    """
    Load a BenchmarkManifest from a JSON file and verify corpus integrity.
    Returns tuple of (manifest, resolved_corpus_text).
    """
    manifest_path = Path(path).resolve()
    if not manifest_path.exists():
        raise FileNotFoundError(f"Benchmark manifest not found: {manifest_path}")

    with open(manifest_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    try:
        manifest = BenchmarkManifest.model_validate(data)
    except Exception as e:
        raise PreflightError(
            error_code="ERR_MALFORMED_MANIFEST",
            message=f"Failed to validate manifest schema for {manifest_path}: {e}",
            details={"path": str(manifest_path), "error": str(e)},
        )

    corpus_text = verify_corpus_integrity(manifest, base_dir=manifest_path.parent)
    return manifest, corpus_text
