"""Streaming sharded-corpus reader, tier manifests, and verification (Stage B).

Implements the TB-only contracts C1/C2/C3/C4 from research report section 6.2
and brief section 6 (COORDINATOR_500M_TO_10B.md):

- C1 sharded reader: :func:`iter_shard_docs` yields one document at a time.
- C2 streaming verification: per-shard sha256 + row-vector digest over
  (doc_id, tok_v1, text_sha256) triples; corpus hash is a hash of shard
  hashes, computed without materializing text.
- C3 tier manifests: ``tb-tier-v1`` JSON (profile/shards/lanes/checksums);
  the loader resolves tier -> ordered shards and refuses mixed-tier pooling.
- C4 budgeted execution: per-shard checkpoint/resume with re-verification.

Memory contract: text buffering is bounded by a single document
(``max_doc_bytes``), never by corpus or shard size. The duplicate-ID registry
holds one small entry per document ID (no text); see :func:`iter_tier_docs`.

TOK-v1 counting matches the frozen ``tokv1_census.py`` reference:
counted text is ``(title + "\\n" + text).strip()`` and tokens are
``re.compile(r"[^\\W_]+", re.UNICODE).findall``. The row-vector digest here
is a *streaming* construction (``tb-census-v1-stream``) and therefore differs
by design from that script's whole-list ``json.dumps(rows)`` vector; the
brief explicitly requires replacing the unbounded mechanism.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

TOK_V1_PATTERN = re.compile(r"[^\W_]+", re.UNICODE)
TOK_V1_ID = "TOK-v1: re.compile(r'[^\\W_]+', re.UNICODE).findall(text)"
COUNTED_TEXT_RULE = "(title + '\\n' + text).strip()"

TIER_SCHEMA = "tb-tier-v1"
CHECKPOINT_SCHEMA = "tb-checkpoint-v1"
VECTOR_DOMAIN = b"tb-census-v1-stream\n"

DEFAULT_MAX_DOC_BYTES = 16 * 1024 * 1024  # 16 MiB single-doc ceiling


class ShardedCorpusError(Exception):
    """Base error for sharded-corpus contract violations."""


class ManifestError(ShardedCorpusError):
    """Tier manifest is missing, unparsable, or fails tb-tier-v1 validation."""


class MalformedDocError(ShardedCorpusError):
    """A shard line is not valid JSON or lacks required tbdoc fields."""


class OversizedDocError(ShardedCorpusError):
    """A single document exceeds max_doc_bytes. Never truncated; always raised."""


class DuplicateDocIdError(ShardedCorpusError):
    """The same document ID appears twice within the tier iteration scope."""


class ChecksumMismatchError(ShardedCorpusError):
    """A shard file sha256 does not match the manifest pin."""


class CensusMismatchError(ShardedCorpusError):
    """Shard census (docs/tokens/vector) disagrees with the manifest pin."""


class ResumeError(ShardedCorpusError):
    """A checkpoint is stale, foreign, or fails re-verification; rebuild."""


@dataclass(frozen=True)
class Doc:
    """One streamed corpus document (C1 per-doc record)."""

    tbdoc_id: str
    text: str
    title: str = ""
    metadata: dict = field(default_factory=dict, compare=False)
    text_sha256: str = ""
    tok_v1: int = 0


def counted_text(title: str, text: str) -> str:
    """Frozen TOK-v1 counted-text rule."""
    return (title + "\n" + text).strip()


def tok_v1_count(counted: str) -> int:
    """Frozen TOK-v1 lexical token count."""
    return len(TOK_V1_PATTERN.findall(counted))


def text_sha256(counted: str) -> str:
    """sha256 over the UTF-8 bytes of the TOK-v1 counted text."""
    return hashlib.sha256(counted.encode("utf-8")).hexdigest()


def _parse_doc_line(
    raw: bytes, lineno: int, shard_label: str, max_doc_bytes: int
) -> Doc | None:
    """Parse one raw JSONL line. Returns None for blank lines."""
    if len(raw) > max_doc_bytes and raw.strip():
        raise OversizedDocError(
            f"{shard_label} line {lineno}: document line is {len(raw)} bytes, "
            f"exceeds max_doc_bytes={max_doc_bytes}; refusing (no truncation)."
        )
    stripped = raw.strip()
    if not stripped:
        return None
    try:
        rec = json.loads(stripped.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise MalformedDocError(
            f"{shard_label} line {lineno}: bad JSON: {exc}"
        ) from exc
    if not isinstance(rec, dict):
        raise MalformedDocError(
            f"{shard_label} line {lineno}: record must be a JSON object."
        )
    doc_id = rec.get("tbdoc_id", rec.get("doc_id"))
    if not isinstance(doc_id, str) or not doc_id:
        raise MalformedDocError(
            f"{shard_label} line {lineno}: missing or empty 'tbdoc_id'."
        )
    text = rec.get("text", "")
    title = rec.get("title", "")
    if not isinstance(text, str) or not isinstance(title, str):
        raise MalformedDocError(
            f"{shard_label} line {lineno}: 'text'/'title' must be strings."
        )
    metadata = rec.get("metadata", {})
    if not isinstance(metadata, dict):
        raise MalformedDocError(
            f"{shard_label} line {lineno}: 'metadata' must be an object."
        )
    counted = counted_text(title, text)
    return Doc(
        tbdoc_id=doc_id,
        text=text,
        title=title,
        metadata=metadata,
        text_sha256=text_sha256(counted),
        tok_v1=tok_v1_count(counted),
    )


def iter_shard_docs(
    shard_path: str | Path,
    *,
    max_doc_bytes: int = DEFAULT_MAX_DOC_BYTES,
) -> Iterator[Doc]:
    """Yield documents from one tbdoc JSONL shard, one line at a time (C1).

    Memory is bounded by the largest single document line
    (``max_doc_bytes``), never by shard or corpus size. Blank lines are
    skipped. Oversized lines raise :class:`OversizedDocError`, malformed
    lines raise :class:`MalformedDocError`; nothing is silently truncated
    or skipped.
    """
    path = Path(shard_path)
    label = path.name
    with path.open("rb") as handle:
        for lineno, raw in enumerate(handle, 1):
            # raw retains the trailing newline; strip for size fairness is
            # handled inside _parse_doc_line.
            doc = _parse_doc_line(raw.rstrip(b"\r\n"), lineno, label, max_doc_bytes)
            if doc is not None:
                yield doc


@dataclass(frozen=True)
class ShardCensus:
    """Streaming census result for one shard (C2)."""

    shard_id: str
    docs: int
    tok_v1_total: int
    vector_sha256: str
    file_sha256: str


def _row_bytes(doc_id: str, tok: int, sha: str) -> bytes:
    return (
        json.dumps(
            {"doc_id": doc_id, "tok_v1": tok, "text_sha256": sha},
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        ).encode("ascii")
        + b"\n"
    )


def census_shard(
    shard_path: str | Path,
    shard_id: str,
    *,
    max_doc_bytes: int = DEFAULT_MAX_DOC_BYTES,
) -> ShardCensus:
    """Stream one shard once, returning counts + digests (C2, bounded memory).

    The row-vector digest is ``sha256("tb-census-v1-stream\\n" + rows...)``
    where each row is the canonical JSON of a (doc_id, tok_v1, text_sha256)
    triple. It is computed incrementally and never materializes the row list.
    """
    file_digest = hashlib.sha256()
    vector_digest = hashlib.sha256()
    vector_digest.update(VECTOR_DOMAIN)
    docs = 0
    tokens = 0
    path = Path(shard_path)
    with path.open("rb") as handle:
        for lineno, raw in enumerate(handle, 1):
            file_digest.update(raw)
            doc = _parse_doc_line(
                raw.rstrip(b"\r\n"), lineno, path.name, max_doc_bytes
            )
            if doc is None:
                continue
            vector_digest.update(_row_bytes(doc.tbdoc_id, doc.tok_v1, doc.text_sha256))
            docs += 1
            tokens += doc.tok_v1
    return ShardCensus(
        shard_id=shard_id,
        docs=docs,
        tok_v1_total=tokens,
        vector_sha256=vector_digest.hexdigest(),
        file_sha256=file_digest.hexdigest(),
    )


@dataclass(frozen=True)
class ShardSpec:
    """One pinned shard entry inside a tier manifest."""

    shard_id: str
    path: str
    sha256: str
    docs: int
    tok_v1: int
    vector_sha256: str


@dataclass(frozen=True)
class TierManifest:
    """Loaded ``tb-tier-v1`` tier manifest (C3)."""

    profile: str
    shards: tuple[ShardSpec, ...]
    lanes: tuple[dict, ...]
    corpus_sha256: str
    source_path: str = ""


def corpus_hash_of_shards(shard_hex_digests: list[str]) -> str:
    """Full-corpus hash = sha256 over ordered per-shard hex digests (C2)."""
    digest = hashlib.sha256()
    digest.update(b"tb-corpus-v1\n")
    for hex_digest in shard_hex_digests:
        digest.update(hex_digest.encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def load_tier_manifest(manifest_path: str | Path) -> TierManifest:
    """Load and validate a ``tb-tier-v1`` JSON manifest (C3).

    Required top-level keys: ``schema`` (== ``tb-tier-v1``), ``profile``,
    ``shards`` (ordered, nonempty, unique ids), ``lanes``, ``checksums``
    with ``corpus_sha256``. Shard order is significant and preserved.
    """
    path = Path(manifest_path)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ManifestError(f"Cannot load tier manifest {path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise ManifestError(f"Tier manifest {path} must be a JSON object.")
    if raw.get("schema") != TIER_SCHEMA:
        raise ManifestError(
            f"Tier manifest {path}: schema must be {TIER_SCHEMA!r}, "
            f"got {raw.get('schema')!r}."
        )
    profile = raw.get("profile")
    if not isinstance(profile, str) or not profile:
        raise ManifestError(f"Tier manifest {path}: 'profile' must be nonempty.")
    entries = raw.get("shards")
    if not isinstance(entries, list) or not entries:
        raise ManifestError(
            f"Tier manifest {path}: 'shards' must be a nonempty ordered list."
        )
    shards: list[ShardSpec] = []
    seen: set[str] = set()
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict):
            raise ManifestError(f"Tier manifest {path}: shard[{index}] not an object.")
        sid = entry.get("shard_id")
        if not isinstance(sid, str) or not sid:
            raise ManifestError(
                f"Tier manifest {path}: shard[{index}] missing 'shard_id'."
            )
        if sid in seen:
            raise ManifestError(
                f"Tier manifest {path}: duplicate shard_id {sid!r}."
            )
        seen.add(sid)
        for key in ("path", "sha256", "vector_sha256"):
            if not isinstance(entry.get(key), str) or not entry[key]:
                raise ManifestError(
                    f"Tier manifest {path}: shard {sid!r} missing {key!r}."
                )
        for key in ("docs", "tok_v1"):
            value = entry.get(key)
            if not isinstance(value, int) or value < 0:
                raise ManifestError(
                    f"Tier manifest {path}: shard {sid!r} {key!r} must be >= 0 int."
                )
        shards.append(
            ShardSpec(
                shard_id=sid,
                path=entry["path"],
                sha256=entry["sha256"],
                docs=entry["docs"],
                tok_v1=entry["tok_v1"],
                vector_sha256=entry["vector_sha256"],
            )
        )
    lanes = raw.get("lanes", [])
    if not isinstance(lanes, list):
        raise ManifestError(f"Tier manifest {path}: 'lanes' must be a list.")
    checksums = raw.get("checksums")
    if not isinstance(checksums, dict) or not checksums.get("corpus_sha256"):
        raise ManifestError(
            f"Tier manifest {path}: 'checksums.corpus_sha256' is required."
        )
    return TierManifest(
        profile=profile,
        shards=tuple(shards),
        lanes=tuple(lanes),
        corpus_sha256=checksums["corpus_sha256"],
        source_path=str(path),
    )


def resolve_shard_path(
    manifest: TierManifest, spec: ShardSpec, base_dir: str | Path | None = None
) -> Path:
    """Resolve a shard path relative to the manifest or an explicit base dir."""
    candidate = Path(spec.path)
    if candidate.is_absolute():
        return candidate
    root = Path(base_dir) if base_dir is not None else Path(manifest.source_path).parent
    return root / spec.path


def verify_shard(
    shard_path: str | Path,
    spec: ShardSpec,
    *,
    max_doc_bytes: int = DEFAULT_MAX_DOC_BYTES,
) -> ShardCensus:
    """Stream-verify one shard against its manifest pin (C2).

    Single streaming pass: file sha256 first, then docs/tokens/vector census.
    Raises :class:`ChecksumMismatchError` / :class:`CensusMismatchError`;
    never labels a failed shard successful.
    """
    census = census_shard(shard_path, spec.shard_id, max_doc_bytes=max_doc_bytes)
    if census.file_sha256 != spec.sha256:
        raise ChecksumMismatchError(
            f"Shard {spec.shard_id}: file sha256 {census.file_sha256} != "
            f"manifest pin {spec.sha256}."
        )
    if census.docs != spec.docs or census.tok_v1_total != spec.tok_v1:
        raise CensusMismatchError(
            f"Shard {spec.shard_id}: census docs={census.docs} tok_v1="
            f"{census.tok_v1_total} != manifest docs={spec.docs} "
            f"tok_v1={spec.tok_v1}."
        )
    if census.vector_sha256 != spec.vector_sha256:
        raise CensusMismatchError(
            f"Shard {spec.shard_id}: vector {census.vector_sha256} != "
            f"manifest pin {spec.vector_sha256} (row drift)."
        )
    return census


@dataclass(frozen=True)
class TierCensus:
    """Verified whole-tier census: shards sum to tier totals (C2)."""

    profile: str
    docs: int
    tok_v1_total: int
    corpus_sha256: str
    shards: tuple[ShardCensus, ...]


def verify_tier(
    manifest: TierManifest,
    base_dir: str | Path | None = None,
    *,
    max_doc_bytes: int = DEFAULT_MAX_DOC_BYTES,
) -> TierCensus:
    """Stream-verify every shard in manifest order, then the corpus hash (C2).

    Tier census is the exact sum of shard censuses; the corpus hash is
    recomputed from the verified shard file hashes. Any mismatch raises.
    """
    censuses: list[ShardCensus] = []
    for spec in manifest.shards:
        censuses.append(
            verify_shard(
                resolve_shard_path(manifest, spec, base_dir),
                spec,
                max_doc_bytes=max_doc_bytes,
            )
        )
    corpus = corpus_hash_of_shards([c.file_sha256 for c in censuses])
    if corpus != manifest.corpus_sha256:
        raise CensusMismatchError(
            f"Tier {manifest.profile}: corpus hash {corpus} != manifest pin "
            f"{manifest.corpus_sha256}."
        )
    return TierCensus(
        profile=manifest.profile,
        docs=sum(c.docs for c in censuses),
        tok_v1_total=sum(c.tok_v1_total for c in censuses),
        corpus_sha256=corpus,
        shards=tuple(censuses),
    )


def iter_tier_docs(
    manifest: TierManifest,
    base_dir: str | Path | None = None,
    *,
    max_doc_bytes: int = DEFAULT_MAX_DOC_BYTES,
    check_duplicates: bool = True,
) -> Iterator[Doc]:
    """Yield every document of a tier in manifest shard order (C1+C3).

    Documents stream one at a time; text memory stays bounded by
    ``max_doc_bytes``. When ``check_duplicates`` is true (default), any
    repeated ``tbdoc_id`` raises :class:`DuplicateDocIdError`. The registry
    holds one entry per ID (no text): O(#docs) small-constant entries, never
    O(corpus bytes). Tiers never silently pool: iteration is scoped to exactly
    the shards pinned in this manifest.
    """
    seen: set[str] | None = set() if check_duplicates else None
    for spec in manifest.shards:
        for doc in iter_shard_docs(
            resolve_shard_path(manifest, spec, base_dir),
            max_doc_bytes=max_doc_bytes,
        ):
            if seen is not None:
                if doc.tbdoc_id in seen:
                    raise DuplicateDocIdError(
                        f"Tier {manifest.profile}: duplicate tbdoc_id "
                        f"{doc.tbdoc_id!r} (in shard {spec.shard_id})."
                    )
                seen.add(doc.tbdoc_id)
            yield doc


@dataclass(frozen=True)
class Checkpoint:
    """Qualified resume position for tier iteration (C4).

    ``docs_consumed_in_current`` counts non-blank documents already yielded
    from ``current_shard_id``. Shards in ``completed_shard_ids`` are
    re-verified by checksum on resume but never re-yielded.
    """

    profile: str
    corpus_sha256: str
    completed_shard_ids: tuple[str, ...]
    current_shard_id: str | None
    docs_consumed_in_current: int

    def to_dict(self) -> dict:
        return {
            "schema": CHECKPOINT_SCHEMA,
            "profile": self.profile,
            "corpus_sha256": self.corpus_sha256,
            "completed_shard_ids": list(self.completed_shard_ids),
            "current_shard_id": self.current_shard_id,
            "docs_consumed_in_current": self.docs_consumed_in_current,
        }

    def save(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

    @staticmethod
    def load(path: str | Path) -> "Checkpoint":
        try:
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ResumeError(f"Cannot load checkpoint {path}: {exc}") from exc
        if not isinstance(raw, dict) or raw.get("schema") != CHECKPOINT_SCHEMA:
            raise ResumeError(
                f"Checkpoint {path}: schema must be {CHECKPOINT_SCHEMA!r}."
            )
        try:
            return Checkpoint(
                profile=raw["profile"],
                corpus_sha256=raw["corpus_sha256"],
                completed_shard_ids=tuple(raw["completed_shard_ids"]),
                current_shard_id=raw["current_shard_id"],
                docs_consumed_in_current=int(raw["docs_consumed_in_current"]),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ResumeError(f"Checkpoint {path} is malformed: {exc}") from exc


def make_checkpoint(
    manifest: TierManifest,
    completed_shard_ids: list[str],
    current_shard_id: str | None,
    docs_consumed_in_current: int,
) -> Checkpoint:
    """Build a checkpoint bound to this exact manifest (profile + corpus hash)."""
    return Checkpoint(
        profile=manifest.profile,
        corpus_sha256=manifest.corpus_sha256,
        completed_shard_ids=tuple(completed_shard_ids),
        current_shard_id=current_shard_id,
        docs_consumed_in_current=docs_consumed_in_current,
    )


def resume_tier_docs(
    manifest: TierManifest,
    checkpoint: Checkpoint,
    base_dir: str | Path | None = None,
    *,
    max_doc_bytes: int = DEFAULT_MAX_DOC_BYTES,
    check_duplicates: bool = True,
) -> Iterator[Doc]:
    """Resume tier iteration from a qualified checkpoint (C4).

    Contract: the checkpoint must belong to this exact manifest (profile and
    corpus hash must match). Every completed shard is re-verified by checksum
    before being skipped; the current shard is re-verified, then fast-forwarded
    past already-consumed documents. Any drift raises :class:`ResumeError`
    (checksum drift surfaces as :class:`ChecksumMismatchError`, which is a
    resume refusal: rebuild the affected unit, do not skip it).
    """
    if checkpoint.profile != manifest.profile:
        raise ResumeError(
            f"Checkpoint profile {checkpoint.profile!r} != tier "
            f"{manifest.profile!r}; refusing cross-tier resume."
        )
    if checkpoint.corpus_sha256 != manifest.corpus_sha256:
        raise ResumeError(
            "Checkpoint corpus hash does not match this manifest; refusing "
            "resume (rebuild the affected unit)."
        )
    by_id = {spec.shard_id: spec for spec in manifest.shards}
    unknown = [sid for sid in checkpoint.completed_shard_ids if sid not in by_id]
    if unknown:
        raise ResumeError(f"Checkpoint names unknown shards: {unknown}.")
    if (
        checkpoint.current_shard_id is not None
        and checkpoint.current_shard_id not in by_id
    ):
        raise ResumeError(
            f"Checkpoint current shard {checkpoint.current_shard_id!r} unknown."
        )
    if checkpoint.docs_consumed_in_current < 0:
        raise ResumeError("Checkpoint doc offset is negative.")

    # Re-verify completed shards (checksum gate) without re-yielding.
    for sid in checkpoint.completed_shard_ids:
        spec = by_id[sid]
        verify_shard(
            resolve_shard_path(manifest, spec, base_dir),
            spec,
            max_doc_bytes=max_doc_bytes,
        )

    seen: set[str] | None = set() if check_duplicates else None
    if seen is not None:
        # Rebuild the ID registry from completed shards so duplicates
        # spanning the resume boundary are still refused. IDs only, no text.
        for sid in checkpoint.completed_shard_ids:
            spec = by_id[sid]
            for doc in iter_shard_docs(
                resolve_shard_path(manifest, spec, base_dir),
                max_doc_bytes=max_doc_bytes,
            ):
                if doc.tbdoc_id in seen:
                    raise DuplicateDocIdError(
                        f"Tier {manifest.profile}: duplicate tbdoc_id "
                        f"{doc.tbdoc_id!r} (in shard {sid})."
                    )
                seen.add(doc.tbdoc_id)

    started = checkpoint.current_shard_id is None
    for spec in manifest.shards:
        if spec.shard_id in checkpoint.completed_shard_ids:
            continue
        if not started:
            if spec.shard_id != checkpoint.current_shard_id:
                continue
            started = True
            # Gate the current shard before fast-forwarding into it.
            verify_shard(
                resolve_shard_path(manifest, spec, base_dir),
                spec,
                max_doc_bytes=max_doc_bytes,
            )
            skip = checkpoint.docs_consumed_in_current
            index = 0
            for doc in iter_shard_docs(
                resolve_shard_path(manifest, spec, base_dir),
                max_doc_bytes=max_doc_bytes,
            ):
                if index < skip:
                    if seen is not None:
                        if doc.tbdoc_id in seen:
                            raise DuplicateDocIdError(
                                f"Tier {manifest.profile}: duplicate tbdoc_id "
                                f"{doc.tbdoc_id!r} (in shard {spec.shard_id})."
                            )
                        seen.add(doc.tbdoc_id)
                    index += 1
                    continue
                if seen is not None:
                    if doc.tbdoc_id in seen:
                        raise DuplicateDocIdError(
                            f"Tier {manifest.profile}: duplicate tbdoc_id "
                            f"{doc.tbdoc_id!r} (in shard {spec.shard_id})."
                        )
                    seen.add(doc.tbdoc_id)
                yield doc
            if index < skip:
                raise ResumeError(
                    f"Shard {spec.shard_id} now holds fewer docs than the "
                    "checkpoint consumed; refusing resume."
                )
        else:
            for doc in iter_shard_docs(
                resolve_shard_path(manifest, spec, base_dir),
                max_doc_bytes=max_doc_bytes,
            ):
                if seen is not None:
                    if doc.tbdoc_id in seen:
                        raise DuplicateDocIdError(
                            f"Tier {manifest.profile}: duplicate tbdoc_id "
                            f"{doc.tbdoc_id!r} (in shard {spec.shard_id})."
                        )
                    seen.add(doc.tbdoc_id)
                yield doc
