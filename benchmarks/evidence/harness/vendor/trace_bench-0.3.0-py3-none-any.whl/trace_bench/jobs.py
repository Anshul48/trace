"""Persistent jobs: attempt records, cancellation, deadlines, resumable execution.

A job is a directory owning a recipe expansion. Each unit (dataset x backend x
repeat) runs independently; verified successful units are resumed, everything
else is rebuilt or replayed. Failed attempts are never discarded: every attempt
appends a new record.
"""

from __future__ import annotations

import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from trace_bench.recipes import Recipe, expand_recipe, recipe_sha256

JOB_VERSION = "tb-job-v1"

# Unit/attempt outcomes. "unsupported" and "cancelled" are terminal for the
# attempt but the unit may be retried by a later attempt (e.g. after installs).
TERMINAL = {"success", "failed", "cancelled", "unsupported", "incomplete"}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_write_json(path: Path, payload: dict) -> None:
    """Write JSON atomically so interrupted jobs never leave partial files."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp_", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def create_job(recipe: Recipe, job_dir: str | Path, isolate: bool = False) -> Path:
    """Create a job directory. Refuses to overwrite an existing job."""
    directory = Path(job_dir)
    if (directory / "job.json").exists():
        raise FileExistsError(f"Job already exists: {directory}")
    directory.mkdir(parents=True, exist_ok=True)
    atomic_write_json(directory / "job.json", {
        "version": JOB_VERSION,
        "job_id": directory.name,
        "recipe": recipe.model_dump(),
        "recipe_sha256": recipe_sha256(recipe),
        "units": [u["unit_id"] for u in expand_recipe(recipe)],
        "isolate": isolate,
        "created_utc": _utcnow(),
        "status": "pending",
    })
    return directory


def load_job(job_dir: str | Path) -> dict:
    raw = json.loads((Path(job_dir) / "job.json").read_text(encoding="utf-8"))
    if raw.get("version") != JOB_VERSION:
        raise ValueError(f"Unsupported job version: {raw.get('version')}")
    return raw


def _require_consistent_recipe(job: dict, recipe: Recipe) -> None:
    """Refuse to execute a job whose recipe definition drifted from its recorded digest.

    A job's recipe is immutable after creation: reusing or executing under a
    silently mutated definition would bless stale evidence. The explicit
    revision policy is a new job; the drifted job is preserved unchanged.
    """
    if recipe_sha256(recipe) != job["recipe_sha256"]:
        raise ValueError(
            "job recipe definition does not match its recorded digest "
            "(recipe changed after job creation?). Create a new job for the revised "
            "recipe; this job is preserved unchanged.")


def _backend_identity(backend_name: str, backend_config: dict | None) -> dict:
    """Current execution identity for a backend selection. No instantiation.

    Class + defining-source hash + effective-constructor-config hash. Registry
    defaults are part of execution identity, even when absent from the recipe.
    Resolving the class
    imports its module (as execution would) but never constructs it, so
    verification cannot trigger model loads. Resolution mirrors
    ``runner.instantiate_baseline``; any change fails closed to re-execution
    while old attempts are preserved.
    """
    import importlib
    import inspect

    from trace_bench.datasets.loader import compute_sha256, file_sha256

    effective_config = dict(backend_config or {})
    if backend_name in ("trace_narrow", "tl_narrow"):
        from trace_bench.baselines.trace_narrow_retriever import TraceNarrowRetriever
        cls = TraceNarrowRetriever
    elif backend_name.startswith("python:"):
        module_name, class_name = backend_name.removeprefix("python:").rsplit(":", 1)
        cls = getattr(importlib.import_module(module_name), class_name)
    else:
        from trace_bench.runner import AVAILABLE_BASELINES
        spec = AVAILABLE_BASELINES[backend_name]
        cls = spec[0] if isinstance(spec, tuple) else spec
        if isinstance(spec, tuple):
            effective_config = {**spec[1], **effective_config}
            from trace_bench.baselines.trace_retriever import TraceLiteRetriever
            if issubclass(cls, TraceLiteRetriever):
                # Job execution uses instantiate_baseline's default mock_llm=False,
                # overriding both registry and recipe values for tuple entries.
                effective_config["mock_llm"] = False
    try:
        source = inspect.getsourcefile(cls)
    except (OSError, TypeError):
        source = None
    try:
        source_sha = file_sha256(source) if source else None
    except OSError:
        source_sha = None
    if backend_name in ("trace_narrow", "tl_narrow"):
        from trace_bench.baselines.trace_narrow_retriever import discover_architecture_dir
        from trace_bench.target_identity import target_identity_sha256
        arch_dir, _ = discover_architecture_dir(effective_config.get("architecture_dir"))
        target_digest: str | None = target_identity_sha256(arch_dir)
    else:
        target_digest = None
    return {"name": backend_name,
            "class": f"{cls.__module__}:{cls.__qualname__}",
            "source_sha256": source_sha,
            "config_sha256": compute_sha256(json.dumps(effective_config, sort_keys=True)),
            "target_identity_sha256": target_digest}


def request_cancel(job_dir: str | Path) -> None:
    (Path(job_dir) / "cancel.requested").write_text(_utcnow() + "\n", encoding="utf-8")


def clear_cancel(job_dir: str | Path) -> bool:
    """Clear a sticky cancellation so a later resume may proceed. Returns True if one existed."""
    marker = Path(job_dir) / "cancel.requested"
    if marker.exists():
        marker.unlink()
        return True
    return False


def _attempts(unit_dir: Path) -> list[Path]:
    return sorted(unit_dir.glob("attempt_*.json")) if unit_dir.is_dir() else []


def _read_attempt(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"status": "incomplete", "note": "unreadable attempt record (preserved)"}


def verify_unit(job_dir: Path, unit_id: str) -> tuple[bool, str]:
    """Check whether a unit's success is still valid.

    Read + hash compare, plus a backend-identity check that may import the
    backend's module but never instantiates it (no model loads).
    """
    from trace_bench.datasets.loader import case_fingerprint, document_fingerprint
    from trace_bench.datasets.portable import load_dataset

    unit_dir = job_dir / "units" / unit_id
    result_path = unit_dir / "result.json"
    attempts = _attempts(unit_dir)
    if not attempts or not result_path.exists():
        return False, "no completed attempt"
    latest = _read_attempt(attempts[-1])
    if latest.get("status") != "success":
        return False, f"latest attempt is {latest.get('status')}"
    try:
        result_bytes = result_path.read_bytes()
        stored = json.loads(result_bytes.decode("utf-8"))
    except (OSError, ValueError):
        return False, "result.json is unreadable"
    expected_digest = latest.get("result_sha256")
    if not expected_digest:
        return False, "recorded success predates result-payload digests"
    if hashlib.sha256(result_bytes).hexdigest() != expected_digest:
        return False, "result.json payload changed since the recorded attempt"
    job = load_job(job_dir)
    recipe = Recipe.model_validate(job["recipe"])
    if recipe_sha256(recipe) != job["recipe_sha256"]:
        return False, "job recipe definition does not match its recorded digest"
    unit = next(u for u in expand_recipe(recipe) if u["unit_id"] == unit_id)
    frozen = latest.get("backend_identity")
    if not frozen:
        return False, "recorded success predates backend-identity digests"
    try:
        current = _backend_identity(unit["backend"]["name"], unit["backend"].get("config"))
    except Exception as exc:
        return False, f"backend implementation unavailable for identity check: {exc}"
    if frozen != current:
        return False, "backend implementation or configuration changed since the recorded attempt"
    try:
        manifest, docs = load_dataset(
            unit["dataset"]["name"], unit["dataset"].get("data_dir"),
            unit["dataset"].get("split", "test"), unit["dataset"].get("limit"))
    except Exception as exc:  # inputs changed or unavailable: rebuild, don't trust
        return False, f"input reload failed: {exc}"
    if stored.get("cases_sha256") != case_fingerprint(manifest):
        return False, "queries/judgments changed since the recorded attempt"
    if stored.get("indexed_documents_sha256") != document_fingerprint(docs):
        return False, "indexed documents changed since the recorded attempt"
    if stored.get("recipe", {}).get("recipe_sha256") != job["recipe_sha256"]:
        return False, "recipe changed since the recorded attempt"
    return True, "verified"


def job_status(job_dir: str | Path) -> dict[str, Any]:
    """Summarize a job without executing anything."""
    directory = Path(job_dir)
    job = load_job(directory)
    units: dict[str, str] = {}
    for unit_id in job["units"]:
        ok, reason = verify_unit(directory, unit_id)
        if ok:
            units[unit_id] = "success"
            continue
        attempts = _attempts(directory / "units" / unit_id)
        if not attempts:
            units[unit_id] = "pending"
            continue
        latest = _read_attempt(attempts[-1])
        status = latest.get("status", "incomplete")
        if status == "running":
            units[unit_id] = "incomplete"  # left behind by an interruption; preserved
        elif status == "success":
            units[unit_id] = f"incomplete (recorded success no longer verifies: {reason})"
        else:
            units[unit_id] = status if status in TERMINAL else "incomplete"
    return {"job_id": job["job_id"], "recipe": job["recipe"].get("name"),
            "recipe_sha256": job["recipe_sha256"], "units": units,
            "cancel_requested": (directory / "cancel.requested").exists()}


def _execute_unit_in_process(job_dir: Path, unit: dict, control_cancel: threading.Event,
                             deadline_remaining: float | None = None) -> dict:
    """Run one unit in this process. Returns the attempt record (never raises)."""
    from trace_bench.datasets.portable import load_dataset
    from trace_bench.runner import JobControl, JobControlCancelled, execute_benchmark

    job = load_job(job_dir)
    recipe = Recipe.model_validate(job["recipe"])
    protocol = recipe.protocol
    unit_dir = job_dir / "units" / unit["unit_id"]
    attempt_no = len(_attempts(unit_dir)) + 1
    attempt_path = unit_dir / f"attempt_{attempt_no:03d}.json"
    unit_started = time.monotonic()

    def heartbeat() -> None:
        if (job_dir / "cancel.requested").exists():
            raise JobControlCancelled("cancel requested", kind="cancelled")
        if deadline_remaining is not None and (time.monotonic() - unit_started) >= deadline_remaining:
            raise JobControlCancelled("job deadline exceeded", kind="incomplete")

    control = JobControl(cancel_event=control_cancel,
                         per_query_timeout_s=protocol.per_query_timeout_s,
                         heartbeat=heartbeat)
    record: dict[str, Any] = {"attempt": attempt_no, "unit_id": unit["unit_id"],
                              "status": "running", "started_utc": _utcnow()}
    atomic_write_json(attempt_path, record)
    started = time.monotonic()
    try:
        manifest, docs = load_dataset(unit["dataset"]["name"],
                                      unit["dataset"].get("data_dir"),
                                      unit["dataset"].get("split", "test"),
                                      unit["dataset"].get("limit"))
        result = execute_benchmark(
            manifest=manifest, corpus_text="", documents=docs,
            baseline_config={unit["backend"]["name"]: unit["backend"]["config"]},
            warmup_queries=protocol.warmup, baseline_names=[unit["backend"]["name"]],
            mode="regression", top_k=protocol.top_k, concurrency=protocol.concurrency,
            control=control,
        )
        result.recipe = {"recipe_name": recipe.name, "recipe_sha256": recipe_sha256(recipe),
                         "unit_id": unit["unit_id"], "repeat": unit["repeat"],
                         "seed": unit["seed"]}
        atomic_write_json(unit_dir / "result.json", result.to_dict())
        result_digest = hashlib.sha256((unit_dir / "result.json").read_bytes()).hexdigest()
        baseline = result.baselines[unit["backend"]["name"]]
        record.update(status="success" if baseline.status == "success" else baseline.status,
                      status_detail=baseline.status_detail,
                      finished_utc=_utcnow(), elapsed_s=round(time.monotonic() - started, 3),
                      failed_queries=baseline.failed_cases_count,
                      result_sha256=result_digest,
                      backend_identity=_backend_identity(
                          unit["backend"]["name"], unit["backend"].get("config")))
    except JobControlCancelled as exc:
        record.update(status=exc.kind, finished_utc=_utcnow(),
                      elapsed_s=round(time.monotonic() - started, 3), note=str(exc))
    except Exception as exc:  # harness-level failure; per-query failures stay in result.json
        record.update(status="failed", finished_utc=_utcnow(),
                      elapsed_s=round(time.monotonic() - started, 3),
                      error=f"{type(exc).__name__}: {exc}")
    atomic_write_json(attempt_path, record)
    return record


def _execute_unit_isolated(job_dir: Path, unit: dict, timeout_s: float | None) -> dict:
    """Run one unit in a subprocess for fair per-backend resource measurement.

    The child (`run-unit`) owns the attempt record; the parent only annotates it
    with isolated RSS samples. Cancel and deadline terminate the child; the unit
    is then rebuilt on resume.
    """
    import psutil

    unit_dir = job_dir / "units" / unit["unit_id"]
    before = set(_attempts(unit_dir))
    cmd = [sys.executable, "-m", "trace_bench", "run-unit",
           "--job-dir", str(job_dir), "--unit-id", unit["unit_id"]]
    started = time.monotonic()
    peak_mb = 0.0
    sampled = False
    outcome = "success"
    note = ""
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, cwd=str(Path(__file__).resolve().parents[2]))
        try:
            root = psutil.Process(proc.pid)
        except psutil.Error:
            root = None
        while proc.poll() is None:
            if (job_dir / "cancel.requested").exists():
                proc.terminate()
                outcome, note = "cancelled", "cancel requested; child terminated"
                break
            if timeout_s is not None and (time.monotonic() - started) >= timeout_s:
                proc.kill()
                outcome, note = "incomplete", "unit deadline exceeded; child killed"
                break
            if root is not None:
                try:
                    total = root.memory_info().rss + sum(
                        c.memory_info().rss for c in root.children(recursive=True))
                    peak_mb = max(peak_mb, total / (1024 * 1024))
                    sampled = True
                except psutil.Error:
                    pass
            time.sleep(0.05)
        out, _ = proc.communicate()
        tail = "\n".join((out or "").splitlines()[-20:])
        if outcome == "success" and proc.returncode != 0:
            outcome, note = "incomplete", f"subprocess exited with code {proc.returncode}"
    except Exception as exc:  # pragma: no cover - defensive
        outcome, note, tail = "incomplete", f"{type(exc).__name__}: {exc}", ""
    fresh = sorted(set(_attempts(unit_dir)) - before)
    if fresh:
        record = _read_attempt(fresh[-1])
        if outcome != "success":
            record.update(status=outcome, finished_utc=_utcnow(),
                          elapsed_s=round(time.monotonic() - started, 3), note=note)
        record["isolated"] = True
        record["isolated_peak_rss_mb"] = round(peak_mb, 2) if sampled else None
        record["isolated_rss_note"] = (
            "Peak RSS sampled from the isolated backend process tree; client-observed, "
            "not remote-service memory." if sampled else
            "Child RSS unavailable; no isolated memory measurement.")
        record["subprocess_output_tail"] = tail
        atomic_write_json(fresh[-1], record)
        return record
    record = {"attempt": len(_attempts(unit_dir)) + 1, "unit_id": unit["unit_id"],
              "status": outcome if outcome != "success" else "incomplete",
              "started_utc": _utcnow(), "finished_utc": _utcnow(),
              "elapsed_s": round(time.monotonic() - started, 3), "note": note or
              "child produced no attempt record", "isolated": True,
              "isolated_peak_rss_mb": round(peak_mb, 2) if sampled else None,
              "subprocess_output_tail": tail}
    atomic_write_json(unit_dir / f"attempt_{record['attempt']:03d}.json", record)
    return record


def run_unit(job_dir: str | Path, unit_id: str) -> dict:
    """Entry point for `trace-bench run-unit`: execute exactly one unit in-process."""
    directory = Path(job_dir)
    job = load_job(directory)
    recipe = Recipe.model_validate(job["recipe"])
    _require_consistent_recipe(job, recipe)
    unit = next(u for u in expand_recipe(recipe) if u["unit_id"] == unit_id)
    return _execute_unit_in_process(directory, unit, threading.Event())


def _watcher_for_interrupt(cancel_event: threading.Event):
    """Install a SIGINT/SIGTERM handler that requests cancellation, once."""
    previous = {}

    def handler(signum, frame):
        cancel_event.set()
        previous["fired"] = True

    try:
        previous["int"] = signal.signal(signal.SIGINT, handler)
        previous["term"] = signal.signal(signal.SIGTERM, handler)
    except (OSError, ValueError, RuntimeError):
        return None
    return previous


def _restore_signals(previous) -> None:
    if not previous:
        return
    try:
        signal.signal(signal.SIGINT, previous["int"])
        signal.signal(signal.SIGTERM, previous["term"])
    except (OSError, ValueError, RuntimeError):
        pass


def run_job(job_dir: str | Path, resume: bool = True) -> dict[str, Any]:
    """Execute all unfinished units. Safe to re-run: verified successes are kept."""
    directory = Path(job_dir)
    job = load_job(directory)
    recipe = Recipe.model_validate(job["recipe"])
    _require_consistent_recipe(job, recipe)
    deadline = recipe.protocol.job_deadline_s
    job_started = time.monotonic()
    cancel_event = threading.Event()
    previous = _watcher_for_interrupt(cancel_event)
    summary: dict[str, Any] = {"job_id": job["job_id"], "units": {}}
    try:
        for unit in expand_recipe(recipe):
            if (directory / "cancel.requested").exists() or cancel_event.is_set():
                summary["units"][unit["unit_id"]] = "cancelled"
                continue
            if deadline is not None and (time.monotonic() - job_started) >= deadline:
                summary["units"][unit["unit_id"]] = "incomplete (job deadline exceeded)"
                continue
            if resume:
                ok, reason = verify_unit(directory, unit["unit_id"])
                if ok:
                    summary["units"][unit["unit_id"]] = "success (resumed, verified)"
                    continue
            remaining = (deadline - (time.monotonic() - job_started)
                         if deadline is not None else None)
            record = (_execute_unit_isolated(directory, unit, remaining) if job.get("isolate")
                      else _execute_unit_in_process(directory, unit, cancel_event, remaining))
            status, note = record["status"], record.get("note")
            summary["units"][unit["unit_id"]] = (
                f"{status} ({note})" if status == "incomplete" and note else status)
            if cancel_event.is_set() and not (directory / "cancel.requested").exists():
                request_cancel(directory)
    finally:
        _restore_signals(previous)
    final = job_status(directory)
    job["status"] = ("success" if set(final["units"].values()) == {"success"}
                     else "incomplete")
    atomic_write_json(directory / "job.json", job)
    summary["job_status"] = job["status"]
    return summary
