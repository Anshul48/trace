"""Portable result capsules: deterministic bundles of run artifacts plus inputs.

A capsule is a deterministic gzip-compressed tar archive (``tb-capsule-v1``)
containing the run artifact (``run.json``), an integrity manifest
(``capsule.json``), and optional rankings, attempt records, and frozen inputs.
Capsules are data only: members are JSON or TREC text, never imported as code,
and packing/unpacking performs no network access and reads no credentials.
"""

from __future__ import annotations

import gzip
import hashlib
import html
import io
import json
import re
import tarfile
from datetime import datetime, timezone
from pathlib import Path

from trace_bench.datasets.loader import file_sha256
from trace_bench.metrics.aggregator import (
    BenchmarkRunResult,
    generate_comparison_markdown,
)
from trace_bench.reporter import generate_html_report

CAPSULE_VERSION = "tb-capsule-v1"

_SAFE_NAME = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.\-]*")
_POSIX_ABSOLUTE = re.compile(r"/")
_WINDOWS_ABSOLUTE = re.compile(r"(^[A-Za-z]:[\\/])|(^\\\\)")

# Leaf field names explicitly permitted to hold absolute local paths inside the
# scanned scopes (per-engine configuration/implementation_identity and run
# hardware_info). The allowlist is intentionally empty: run artifacts must be
# portable, so any absolute path found in those scopes refuses packing.
ABSOLUTE_PATH_ALLOWLIST: frozenset[str] = frozenset()

# Scopes of the run dict scanned for absolute local paths.
_SCANNED_SCOPES = ("configuration", "implementation_identity", "hardware_info")


def _producer_version() -> str:
    try:
        import importlib.metadata

        return importlib.metadata.version("trace-bench")
    except Exception:
        try:
            from trace_bench import __version__

            return __version__
        except Exception:
            return "unknown"


def _is_absolute_path(value: str) -> bool:
    text = value.strip()
    if not text:
        return False
    if text.startswith("/"):
        return True
    return bool(_WINDOWS_ABSOLUTE.match(text))


def _scan_absolute_paths(node, location: str, hits: list[str]) -> None:
    if isinstance(node, dict):
        for key, value in node.items():
            _scan_absolute_paths(value, f"{location}.{key}", hits)
            _leaf = str(key)
    elif isinstance(node, list):
        for index, value in enumerate(node):
            _scan_absolute_paths(value, f"{location}[{index}]", hits)
    elif isinstance(node, str):
        leaf = location.rsplit(".", 1)[-1].rstrip("]")
        if leaf not in ABSOLUTE_PATH_ALLOWLIST and _is_absolute_path(node):
            hits.append(f"{location} = {node!r}")


def assert_no_absolute_paths(run_dict: dict) -> None:
    """Refuse run artifacts that embed absolute local paths outside the allowlist."""
    hits: list[str] = []
    for engine, baseline in (run_dict.get("baselines") or {}).items():
        if not isinstance(baseline, dict):
            continue
        for scope in ("configuration", "implementation_identity"):
            if scope in baseline:
                _scan_absolute_paths(baseline[scope], f"baselines.{engine}.{scope}", hits)
    if "hardware_info" in run_dict:
        _scan_absolute_paths(run_dict["hardware_info"], "hardware_info", hits)
    if hits:
        detail = "; ".join(hits[:5])
        raise ValueError(
            "run.json embeds absolute local path(s) outside the portability allowlist "
            f"({detail}); capsules must not reference machine-local paths."
        )


def _normalized_tarinfo(archive: tarfile.TarFile, arcname: str, size: int) -> tarfile.TarInfo:
    info = tarfile.TarInfo(arcname)
    info.size = size
    info.uid = info.gid = info.mtime = 0
    info.uname = info.gname = ""
    info.mode = 0o644
    info.type = tarfile.REGTYPE
    return info


def _write_members(output: Path, members: dict[str, bytes]) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("xb") as raw, gzip.GzipFile(
        fileobj=raw, mode="wb", filename="", mtime=0
    ) as compressed, tarfile.open(fileobj=compressed, mode="w") as archive:
        for arcname in sorted(members):
            payload = members[arcname]
            info = _normalized_tarinfo(archive, arcname, len(payload))
            archive.addfile(info, io.BytesIO(payload))


def _check_safe_name(name: str, kind: str) -> None:
    if not _SAFE_NAME.fullmatch(name) or name in (".", ".."):
        raise ValueError(f"Unsafe {kind} name for capsule member: {name!r}")


def _collect_trec_members(trec_dir: Path) -> dict[str, bytes]:
    members: dict[str, bytes] = {}
    for path in sorted(trec_dir.iterdir()):
        if not path.is_file() or path.suffix != ".trec":
            continue
        _check_safe_name(path.name, "trec")
        members[f"rankings/{path.name}"] = path.read_bytes()
    return members


def _collect_attempt_members(job_dir: Path) -> dict[str, bytes]:
    members: dict[str, bytes] = {}
    job_json = job_dir / "job.json"
    if not job_json.is_file():
        raise FileNotFoundError(f"job_dir has no job.json: {job_dir}")
    members["attempts/job.json"] = job_json.read_bytes()
    units_dir = job_dir / "units"
    if units_dir.is_dir():
        for unit_dir in sorted(p for p in units_dir.iterdir() if p.is_dir()):
            _check_safe_name(unit_dir.name, "unit")
            for path in sorted(unit_dir.iterdir()):
                if not path.is_file():
                    continue
                if path.name == "result.json" or (
                    path.name.startswith("attempt_") and path.suffix == ".json"
                ):
                    _check_safe_name(path.name, "attempt")
                    members[f"attempts/units/{unit_dir.name}/{path.name}"] = path.read_bytes()
    return members


def _collect_input_members(snapshot_dir: Path) -> dict[str, bytes]:
    expected = ("manifest.json", "corpus.jsonl", "checksums.json")
    for name in expected:
        if not (snapshot_dir / name).is_file():
            raise FileNotFoundError(f"Input snapshot is missing {name}: {snapshot_dir}")
    checksums = json.loads((snapshot_dir / "checksums.json").read_text(encoding="utf-8"))
    if set(checksums) != {"manifest.json", "corpus.jsonl"}:
        raise ValueError("Input snapshot checksum inventory is invalid")
    for filename, digest in checksums.items():
        if file_sha256(snapshot_dir / filename) != digest:
            raise ValueError(f"Input snapshot checksum mismatch: {filename}")
    return {f"inputs/{name}": (snapshot_dir / name).read_bytes() for name in expected}


def pack(
    run_json_path: str | Path,
    output_path: str | Path,
    trec_dir: str | Path | None = None,
    job_dir: str | Path | None = None,
    include_inputs_from: str | Path | None = None,
) -> Path:
    """Create a deterministic ``tb-capsule-v1`` archive from a run artifact."""
    run_json_path = Path(run_json_path)
    output = Path(output_path)
    if output.exists():
        raise FileExistsError(f"Capsule already exists: {output}")
    run_dict = json.loads(run_json_path.read_text(encoding="utf-8"))
    BenchmarkRunResult.from_dict(run_dict)  # schema validation before packing
    assert_no_absolute_paths(run_dict)

    members: dict[str, bytes] = {}
    run_bytes = (json.dumps(run_dict, indent=2, sort_keys=True) + "\n").encode("utf-8")
    members["run.json"] = run_bytes
    if trec_dir is not None:
        members.update(_collect_trec_members(Path(trec_dir)))
    if job_dir is not None:
        members.update(_collect_attempt_members(Path(job_dir)))
    if include_inputs_from is not None:
        members.update(_collect_input_members(Path(include_inputs_from)))

    sha256_map = {
        name: hashlib.sha256(payload).hexdigest() for name, payload in members.items()
    }
    capsule_id = f"capsule_{hashlib.sha256(run_bytes).hexdigest()[:16]}"
    capsule_doc = {
        "version": CAPSULE_VERSION,
        "capsule_id": capsule_id,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "producer": {"name": "trace-bench", "version": _producer_version()},
        "run_id": run_dict.get("run_id"),
        "sha256": sha256_map,
    }
    members["capsule.json"] = (json.dumps(capsule_doc, indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )
    _write_members(output, members)
    print(f"Capsule: {output} ({output.stat().st_size:,} bytes)")
    print(f"SHA-256: {file_sha256(output)}")
    return output


def _member_allowed(name: str) -> bool:
    if name in ("capsule.json", "run.json"):
        return True
    if name.startswith("rankings/"):
        rest = name[len("rankings/") :]
        return "/" not in rest and bool(_SAFE_NAME.fullmatch(rest))
    if name.startswith("attempts/"):
        rest = name[len("attempts/") :]
        parts = rest.split("/")
        return bool(rest) and all(_SAFE_NAME.fullmatch(p) for p in parts)
    if name.startswith("inputs/"):
        rest = name[len("inputs/") :]
        return "/" not in rest and bool(_SAFE_NAME.fullmatch(rest))
    return False


def _reject_unsafe_member(member: tarfile.TarInfo) -> None:
    name = member.name
    if not name or name.startswith("/") or _WINDOWS_ABSOLUTE.match(name):
        raise ValueError(f"Unsafe archive member: {name!r}")
    if ".." in Path(name).parts:
        raise ValueError(f"Unsafe archive member: {name!r}")
    if member.issym() or member.islnk() or not member.isfile():
        raise ValueError(f"Archive member is not a regular file: {name!r}")
    if not _member_allowed(name):
        raise ValueError(f"Unexpected archive member: {name!r}")


def _verify_staged(staged: dict[str, bytes]) -> list[str]:
    findings: list[str] = []
    if "capsule.json" not in staged or "run.json" not in staged:
        findings.append("Capsule is missing required members (capsule.json and run.json).")
        return findings
    try:
        capsule_doc = json.loads(staged["capsule.json"].decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        return [f"capsule.json is not valid JSON: {exc}"]
    if capsule_doc.get("version") != CAPSULE_VERSION:
        findings.append(
            f"Unsupported capsule version: {capsule_doc.get('version')!r} "
            f"(expected {CAPSULE_VERSION!r})."
        )
    recorded = capsule_doc.get("sha256")
    if not isinstance(recorded, dict):
        findings.append("capsule.json has no sha256 member inventory.")
        return findings
    for name, payload in staged.items():
        if name == "capsule.json":
            continue
        digest = hashlib.sha256(payload).hexdigest()
        if recorded.get(name) != digest:
            findings.append(f"Checksum mismatch for capsule member: {name}")
    for name in recorded:
        if name != "capsule.json" and name not in staged:
            findings.append(f"Capsule member listed in capsule.json is missing: {name}")
    try:
        run_dict = json.loads(staged["run.json"].decode("utf-8"))
        BenchmarkRunResult.from_dict(run_dict)
    except (ValueError, UnicodeDecodeError, TypeError, KeyError) as exc:
        findings.append(f"run.json failed schema validation: {exc}")
    return findings


def unpack(archive: str | Path, dest_dir: str | Path) -> Path:
    """Unpack and verify a capsule archive into a new directory."""
    archive = Path(archive)
    dest = Path(dest_dir)
    if dest.exists():
        raise FileExistsError(f"Capsule destination already exists: {dest}")
    staged: dict[str, bytes] = {}
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar:
            _reject_unsafe_member(member)
            if member.name in staged:
                raise ValueError(f"Duplicate archive member: {member.name!r}")
            handle = tar.extractfile(member)
            if handle is None:
                raise ValueError(f"Cannot read archive member: {member.name!r}")
            staged[member.name] = handle.read()
    findings = _verify_staged(staged)
    if findings:
        raise ValueError("; ".join(findings))
    for name in sorted(staged):
        target = dest / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(staged[name])
    return dest


def verify(path_or_dir: str | Path) -> list[str]:
    """Validate an unpacked capsule directory or a capsule archive.

    Returns a list of findings; an empty list means the capsule is valid.
    """
    import shutil
    import tempfile

    target = Path(path_or_dir)
    if target.is_dir():
        staged: dict[str, bytes] = {}
        for path in sorted(target.rglob("*")):
            if path.is_symlink():
                return [f"Capsule directory contains a symlink: {path.name}"]
            if path.is_file():
                staged[path.relative_to(target).as_posix()] = path.read_bytes()
        for name in staged:
            if not _member_allowed(name):
                return [f"Unexpected capsule member: {name!r}"]
        return _verify_staged(staged)
    if target.is_file():
        tmp_root = Path(tempfile.mkdtemp(prefix="tb_capsule_verify_"))
        try:
            staged_archive: dict[str, bytes] = {}
            try:
                with tarfile.open(target, "r:gz") as tar:
                    for member in tar:
                        _reject_unsafe_member(member)
                        if member.name in staged_archive:
                            return [f"Duplicate archive member: {member.name!r}"]
                        handle = tar.extractfile(member)
                        if handle is None:
                            return [f"Cannot read archive member: {member.name!r}"]
                        staged_archive[member.name] = handle.read()
            except tarfile.TarError as exc:
                return [f"Archive is not a readable gzip tar: {exc}"]
            except ValueError as exc:
                return [str(exc)]
            return _verify_staged(staged_archive)
        finally:
            shutil.rmtree(tmp_root, ignore_errors=True)
    return [f"No such capsule archive or directory: {target}"]


def report(
    capsule_dir: str | Path,
    output_html: str | Path,
    baseline_capsule_dir: str | Path | None = None,
) -> Path:
    """Regenerate the authoritative HTML report from an unpacked capsule."""
    capsule_dir = Path(capsule_dir)
    output = Path(output_html)
    current = BenchmarkRunResult.from_dict(
        json.loads((capsule_dir / "run.json").read_text(encoding="utf-8"))
    )
    comparison_block = ""
    if baseline_capsule_dir is not None:
        baseline = BenchmarkRunResult.from_dict(
            json.loads((Path(baseline_capsule_dir) / "run.json").read_text(encoding="utf-8"))
        )
        try:
            markdown = generate_comparison_markdown(current, baseline)
            document = generate_html_report(current, baseline)
            comparison_block = (
                '<div class="card full-width"><h2>Run comparison '
                f"({html.escape(current.run_id)} vs {html.escape(baseline.run_id)})</h2>"
                f"<pre>{html.escape(markdown)}</pre></div>"
            )
        except (ValueError, TypeError) as exc:
            document = generate_html_report(current)
            comparison_block = (
                '<div class="card full-width"><h2>Run comparison refused</h2>'
                f"<p>Baseline {html.escape(baseline.run_id)} is not comparable: "
                f"{html.escape(str(exc))}</p></div>"
            )
    else:
        document = generate_html_report(current)
    if comparison_block:
        document = document.replace("</body>", comparison_block + "\n</body>")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(document, encoding="utf-8")
    return output
