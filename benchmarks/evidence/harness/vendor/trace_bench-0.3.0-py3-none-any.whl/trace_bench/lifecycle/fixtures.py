"""Frozen deterministic lifecycle fixtures (format ``tb-lifecycle-v1``).

Three tiny workloads (<=12 docs, <=20 events each). Query terms are unique
to their target docs under token-overlap scoring so the reference backend
ranks each gold doc first.
"""

import copy

from trace_bench.lifecycle.runner import FORMAT_VERSION

BASIC_CHRONOLOGY: dict = {
    "format": FORMAT_VERSION,
    "name": "basic_chronology",
    "description": "insert/query/update/retire/query/snapshot with pinned query",
    "policy": "partition",
    "halt_on_error": False,
    "events": [
        {"seq": 1, "op": "insert",
         "params": {"doc_id": "d1", "text": "apple orchard harvest cider",
                    "title": "Orchard"}},
        {"seq": 2, "op": "insert",
         "params": {"doc_id": "d2", "text": "banana grove harvest tropics",
                    "title": "Grove"}},
        {"seq": 3, "op": "query",
         "params": {"text": "apple orchard", "top_k": 5},
         "expect": {"gold": ["d1"], "probe_id": "basic-apple"}},
        {"seq": 4, "op": "insert",
         "params": {"doc_id": "d3", "text": "cherry meadow river stone",
                    "title": "Meadow"}},
        {"seq": 5, "op": "update",
         "params": {"doc_id": "d2",
                    "text": "banana grove harvest tropics apricot",
                    "title": "Grove"}},
        {"seq": 6, "op": "query",
         "params": {"text": "apricot", "top_k": 5},
         "expect": {"gold": ["d2"], "probe_id": "basic-apricot"}},
        {"seq": 7, "op": "retire", "params": {"doc_id": "d1"}},
        {"seq": 8, "op": "query",
         "params": {"text": "apple orchard", "top_k": 5},
         "expect": {"gold": [], "probe_id": "basic-retired"}},
        {"seq": 9, "op": "snapshot", "params": {"pin": "final"},
         "expect": {"doc_ids": ["d2", "d3"]}},
        {"seq": 10, "op": "query",
         "params": {"text": "banana grove", "top_k": 5, "generation": 5},
         "expect": {"gold": ["d2"], "probe_id": "basic-pinned"}},
    ],
}

MAINTENANCE_REGRESSION: dict = {
    "format": FORMAT_VERSION,
    "name": "maintenance_regression",
    "description": "probe queries before/after maintain with min-recall floors",
    "policy": "overlapping",
    "halt_on_error": False,
    "events": [
        {"seq": 1, "op": "insert",
         "params": {"doc_id": "m1", "text": "redwood forest canopy moss",
                    "title": "Forest"}},
        {"seq": 2, "op": "insert",
         "params": {"doc_id": "m2", "text": "cobalt ocean tide coral",
                    "title": "Ocean"}},
        {"seq": 3, "op": "insert",
         "params": {"doc_id": "m3", "text": "quartz canyon echo mesa",
                    "title": "Canyon"}},
        {"seq": 4, "op": "insert",
         "params": {"doc_id": "m4", "text": "ember prairie bison grass",
                    "title": "Prairie"}},
        {"seq": 5, "op": "query",
         "params": {"text": "redwood canopy", "top_k": 5},
         "expect": {"gold": ["m1"], "probe_id": "probe-forest",
                    "min_recall": 1.0}},
        {"seq": 6, "op": "query",
         "params": {"text": "cobalt tide", "top_k": 5},
         "expect": {"gold": ["m2"], "probe_id": "probe-ocean",
                    "min_recall": 1.0}},
        {"seq": 7, "op": "maintain", "params": {}},
        {"seq": 8, "op": "query",
         "params": {"text": "redwood canopy", "top_k": 5},
         "expect": {"gold": ["m1"], "probe_id": "probe-forest",
                    "min_recall": 1.0}},
        {"seq": 9, "op": "query",
         "params": {"text": "cobalt tide", "top_k": 5},
         "expect": {"gold": ["m2"], "probe_id": "probe-ocean",
                    "min_recall": 1.0}},
        {"seq": 10, "op": "snapshot", "params": {"pin": "post-maintain"},
         "expect": {"doc_ids": ["m1", "m2", "m3", "m4"]}},
    ],
}

PERSISTENCE_MEMBERSHIP: dict = {
    "format": FORMAT_VERSION,
    "name": "persistence_membership",
    "description": "partition policy with reopen mid-stream and snapshot pins",
    "policy": "partition",
    "halt_on_error": False,
    "events": [
        {"seq": 1, "op": "insert",
         "params": {"doc_id": "k1", "text": "walnut library archive paper",
                    "title": "Library"}},
        {"seq": 2, "op": "insert",
         "params": {"doc_id": "k2", "text": "saffron kitchen spice mortar",
                    "title": "Kitchen"}},
        {"seq": 3, "op": "insert",
         "params": {"doc_id": "k3", "text": "granite quarry cliff hammer",
                    "title": "Quarry"}},
        {"seq": 4, "op": "snapshot", "params": {"pin": "pre-reopen"},
         "expect": {"doc_ids": ["k1", "k2", "k3"]}},
        {"seq": 5, "op": "reopen", "params": {}},
        {"seq": 6, "op": "snapshot", "params": {"pin": "post-reopen"},
         "expect": {"doc_ids": ["k1", "k2", "k3"]}},
        {"seq": 7, "op": "insert",
         "params": {"doc_id": "k4", "text": "lantern harbor beacon fog",
                    "title": "Harbor"}},
        {"seq": 8, "op": "retire", "params": {"doc_id": "k2"}},
        {"seq": 9, "op": "snapshot", "params": {"pin": "final"},
         "expect": {"doc_ids": ["k1", "k3", "k4"]}},
        {"seq": 10, "op": "query",
         "params": {"text": "saffron spice", "top_k": 5},
         "expect": {"gold": [], "probe_id": "persist-retired"}},
        {"seq": 11, "op": "query",
         "params": {"text": "lantern beacon", "top_k": 5},
         "expect": {"gold": ["k4"], "probe_id": "persist-live"}},
    ],
}

FIXTURES: dict[str, dict] = {
    "basic_chronology": BASIC_CHRONOLOGY,
    "maintenance_regression": MAINTENANCE_REGRESSION,
    "persistence_membership": PERSISTENCE_MEMBERSHIP,
}


def list_fixtures() -> list[str]:
    """Names of the frozen fixtures."""
    return sorted(FIXTURES)


def get_fixture(name: str) -> dict:
    """Return a deep copy of a frozen fixture (safe to mutate)."""
    if name not in FIXTURES:
        raise KeyError(f"unknown lifecycle fixture: {name}")
    return copy.deepcopy(FIXTURES[name])
