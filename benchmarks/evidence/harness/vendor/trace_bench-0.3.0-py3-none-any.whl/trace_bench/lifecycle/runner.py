"""Deterministic event-workload runner for lifecycle evaluation.

Executes fixture events in order against a :class:`LifecycleBackend`, tracks
an expected live-set model, and computes eight named checks. Deterministic:
no wall-clock assertions, no randomness. Per-op latency is measured and
reported but never asserted.
"""

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

from trace_bench.lifecycle.contract import (
    ERR_LIFECYCLE_BACKEND_ERROR,
    ERR_LIFECYCLE_UNKNOWN_OP,
    ERR_LIFECYCLE_UNSUPPORTED,
    OPERATIONS,
    LifecycleBackend,
    LifecycleNotSupported,
)
from trace_bench.metrics.organization import (
    duplicate_membership_count,
    orphan_count,
    source_atom_coverage,
)
from trace_bench.metrics.retrieval import recall_at_k

FORMAT_VERSION = "tb-lifecycle-v1"
MUTATION_OPS = ("insert", "update", "retire", "maintain")

CHECK_NAMES: tuple[str, ...] = (
    "chronology",
    "snapshot_correctness",
    "no_stale_leakage",
    "preservation",
    "membership",
    "retrieval_before_after_maintenance",
    "persistence",
    "failure_receipts",
)


@dataclass
class LifecycleCheck:
    """One named check verdict with evidence."""
    name: str
    passed: bool
    expected: object = None
    observed: object = None
    evidence: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "passed": self.passed,
            "expected": self.expected,
            "observed": self.observed,
            "evidence": self.evidence,
        }


@dataclass
class LifecycleResult:
    """Outcome of one fixture run."""
    fixture_name: str
    backend_name: str
    checks: list[LifecycleCheck] = field(default_factory=list)
    receipts: list[dict] = field(default_factory=list)
    error_receipts: list[dict] = field(default_factory=list)
    summary: dict = field(default_factory=dict)
    final_snapshot: dict | None = None
    final_live_ids: list[str] = field(default_factory=list)

    def check(self, name: str) -> LifecycleCheck:
        for item in self.checks:
            if item.name == name:
                return item
        raise KeyError(f"unknown check: {name}")

    @property
    def all_passed(self) -> bool:
        return all(item.passed for item in self.checks)

    def to_dict(self) -> dict:
        return {
            "fixture_name": self.fixture_name,
            "backend_name": self.backend_name,
            "summary": self.summary,
            "checks": [item.to_dict() for item in self.checks],
            "receipts": self.receipts,
            "error_receipts": self.error_receipts,
            "final_snapshot": self.final_snapshot,
            "final_live_ids": self.final_live_ids,
        }

    def save_json(self, path: str | Path) -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True),
                          encoding="utf-8")
        return target


def normalize_hits(raw: object) -> list[dict]:
    """Normalize query output: ``(doc_id, score)`` pairs or dicts."""
    hits: list[dict] = []
    if raw is None:
        return hits
    if not isinstance(raw, (list, tuple)):
        raise ValueError(f"query must return a list, got {type(raw).__name__}")
    for item in raw:
        if isinstance(item, dict):
            hits.append({
                "doc_id": item["doc_id"],
                "score": float(item.get("score", 0.0)),
                "text": item.get("text"),
            })
        elif isinstance(item, (list, tuple)) and len(item) >= 2:
            hits.append({
                "doc_id": item[0],
                "score": float(item[1]),
                "text": item[2] if len(item) > 2 else None,
            })
        else:
            raise ValueError(f"unrecognized query hit shape: {item!r}")
    return hits


def _safe_name(value: str) -> str:
    return "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in value)


def run_lifecycle(fixture: dict, backend: LifecycleBackend,
                  output_dir: str | Path) -> LifecycleResult:
    """Run fixture events against backend; write result JSON into output_dir."""
    if fixture.get("format") != FORMAT_VERSION:
        raise ValueError(
            f"unsupported fixture format: {fixture.get('format')!r} "
            f"(expected {FORMAT_VERSION!r})")
    events = list(fixture.get("events", []))
    halt_on_error = bool(fixture.get("halt_on_error", False))
    policy = fixture.get("policy", "partition")
    capabilities = dict(backend.capabilities() or {})

    result = LifecycleResult(
        fixture_name=str(fixture.get("name", "unnamed")),
        backend_name=backend.name(),
    )

    model: dict[str, dict] = {}  # doc_id -> {"text":..., "title":...}
    retired: set[str] = set()
    generations: list[dict] = []  # {seq, op, generation} for ok mutations
    snapshots: list[dict] = []  # {seq, pin, snapshot, live_ids}
    queries: list[dict] = []  # {seq, hits, gold, top_k, pin, live_ids, recall}
    reopens: list[dict] = []  # {seq, digest_before, digest_after}
    mutation_count = 0
    halted = False

    for event in events:
        seq = event.get("seq")
        op = event.get("op")
        params = dict(event.get("params") or {})
        expect = dict(event.get("expect") or {})
        entry: dict = {"seq": seq, "op": op, "params": params}
        live_before = sorted(model)

        if op not in OPERATIONS:
            entry.update({"status": "error", "latency_ms": 0.0,
                          "error_code": ERR_LIFECYCLE_UNKNOWN_OP,
                          "message": f"unknown op: {op!r}"})
            result.receipts.append(entry)
            result.error_receipts.append(_error_receipt(
                seq, op, ERR_LIFECYCLE_UNKNOWN_OP, f"unknown op: {op!r}",
                "ValueError"))
            if halt_on_error:
                halted = True
                break
            continue

        if not capabilities.get(op, False):
            entry.update({"status": "unsupported", "latency_ms": 0.0,
                          "error_code": ERR_LIFECYCLE_UNSUPPORTED,
                          "message": f"backend does not support {op}"})
            result.receipts.append(entry)
            result.error_receipts.append(_error_receipt(
                seq, op, ERR_LIFECYCLE_UNSUPPORTED,
                f"backend does not support {op}", "LifecycleNotSupported"))
            if halt_on_error:
                halted = True
                break
            continue

        started = time.perf_counter()
        try:
            if op == "insert":
                receipt = backend.insert(params["doc_id"], params["text"],
                                         params.get("title", ""),
                                         params.get("metadata"))
                entry["receipt"] = receipt
                if receipt.get("ok"):
                    model[params["doc_id"]] = {"text": params["text"],
                                               "title": params.get("title", "")}
                    retired.discard(params["doc_id"])
                    mutation_count += 1
                    generations.append({"seq": seq, "op": op,
                                        "generation": receipt.get("generation")})
            elif op == "update":
                receipt = backend.update(params["doc_id"], params["text"],
                                         params.get("title", ""),
                                         params.get("metadata"))
                entry["receipt"] = receipt
                if receipt.get("ok"):
                    model[params["doc_id"]] = {"text": params["text"],
                                               "title": params.get("title", "")}
                    mutation_count += 1
                    generations.append({"seq": seq, "op": op,
                                        "generation": receipt.get("generation")})
            elif op == "retire":
                receipt = backend.retire(params["doc_id"])
                entry["receipt"] = receipt
                if receipt.get("ok"):
                    model.pop(params["doc_id"], None)
                    retired.add(params["doc_id"])
                    mutation_count += 1
                    generations.append({"seq": seq, "op": op,
                                        "generation": receipt.get("generation")})
            elif op == "maintain":
                receipt = backend.maintain()
                entry["receipt"] = receipt
                if receipt.get("ok"):
                    mutation_count += 1
                    generations.append({"seq": seq, "op": op,
                                        "generation": receipt.get("generation")})
            elif op == "query":
                raw = backend.query(params.get("text", ""),
                                    params.get("top_k", 10),
                                    params.get("generation"))
                hits = normalize_hits(raw)
                top_k = params.get("top_k", 10)
                gold = list(expect.get("gold") or expect.get("doc_ids") or [])
                entry["hits"] = hits
                entry["receipt"] = {"op": "query", "ok": True,
                                    "returned": len(hits)}
                queries.append({"seq": seq, "hits": hits, "gold": gold,
                                "top_k": top_k,
                                "pin": params.get("generation"),
                                "probe_id": expect.get("probe_id"),
                                "min_recall": expect.get("min_recall"),
                                "live_ids": live_before,
                                "live_texts": {d: v["text"]
                                               for d, v in model.items()},
                                "recall": recall_at_k(
                                    [h["doc_id"] for h in hits], gold, top_k)
                                if gold else None})
            elif op == "snapshot":
                snap = backend.snapshot()
                entry["snapshot"] = snap
                entry["receipt"] = {"op": "snapshot", "ok": True,
                                    "generation": snap.get("generation"),
                                    "digest": snap.get("digest")}
                snapshots.append({"seq": seq, "pin": params.get("pin"),
                                  "snapshot": snap, "live_ids": live_before,
                                  "expected_ids": expect.get("doc_ids"),
                                  "mutations": mutation_count})
            elif op == "reopen":
                digest_before = _try_snapshot_digest(backend, capabilities)
                receipt = backend.reopen()
                digest_after = _try_snapshot_digest(backend, capabilities)
                entry["receipt"] = receipt
                reopens.append({"seq": seq, "digest_before": digest_before,
                                "digest_after": digest_after,
                                "ok": bool(receipt.get("ok"))})
            entry["status"] = "ok"
        except LifecycleNotSupported as exc:
            entry.update({"status": "unsupported",
                          "error_code": ERR_LIFECYCLE_UNSUPPORTED,
                          "message": str(exc)})
            result.error_receipts.append(_error_receipt(
                seq, op, ERR_LIFECYCLE_UNSUPPORTED, str(exc,
                                                       "LifecycleNotSupported")))
        except Exception as exc:  # noqa: BLE001 - every failure becomes a receipt
            entry.update({"status": "error",
                          "error_code": ERR_LIFECYCLE_BACKEND_ERROR,
                          "message": f"{type(exc).__name__}: {exc}"})
            result.error_receipts.append(_error_receipt(
                seq, op, ERR_LIFECYCLE_BACKEND_ERROR, str(exc),
                type(exc).__name__))
        finally:
            entry["latency_ms"] = round(
                (time.perf_counter() - started) * 1000.0, 3)
        result.receipts.append(entry)
        if entry["status"] == "error" and halt_on_error:
            halted = True
            break

    final_live_ids = sorted(model)
    final_snapshot: dict | None = None
    if capabilities.get("snapshot", False):
        try:
            final_snapshot = backend.snapshot()
        except Exception as exc:  # noqa: BLE001 - recorded, checks fail closed
            result.error_receipts.append(_error_receipt(
                None, "snapshot", ERR_LIFECYCLE_BACKEND_ERROR,
                f"final snapshot failed: {exc}", type(exc).__name__))
    result.final_snapshot = final_snapshot
    result.final_live_ids = final_live_ids

    snapshot_supported = capabilities.get("snapshot", False)
    result.checks = [
        _check_chronology(generations),
        _check_snapshot_correctness(snapshots, snapshot_supported),
        _check_no_stale_leakage(queries),
        _check_preservation(final_snapshot, final_live_ids,
                            snapshot_supported),
        _check_membership(final_snapshot, final_live_ids, policy,
                          snapshot_supported),
        _check_retrieval_before_after(queries, result.receipts,
                                      capabilities.get("maintain", False)),
        _check_persistence(reopens, snapshot_supported),
        _check_failure_receipts(result.receipts, result.error_receipts,
                                len(events), halt_on_error, halted),
    ]

    ok = sum(1 for r in result.receipts if r["status"] == "ok")
    errors = sum(1 for r in result.receipts if r["status"] == "error")
    unsupported = sum(1 for r in result.receipts
                      if r["status"] == "unsupported")
    result.summary = {
        "total_events": len(events),
        "executed_events": len(result.receipts),
        "ok": ok,
        "errors": errors,
        "unsupported": unsupported,
        "checks_passed": sum(1 for c in result.checks if c.passed),
        "checks_failed": sum(1 for c in result.checks if not c.passed),
        "halted": halted,
        "policy": policy,
    }

    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    filename = f"{_safe_name(result.fixture_name)}__{_safe_name(result.backend_name)}__lifecycle.json"
    result.save_json(outdir / filename)
    return result


def _error_receipt(seq, op, code: str, message: str,
                   exception_type: str) -> dict:
    return {
        "seq": seq,
        "op": op,
        "error_code": code,
        "message": message,
        "exception_type": exception_type,
        "fallback_forbidden": True,
    }


def _try_snapshot_digest(backend: LifecycleBackend,
                         capabilities: dict) -> str | None:
    if not capabilities.get("snapshot", False):
        return None
    try:
        return backend.snapshot().get("digest")
    except Exception:  # noqa: BLE001 - absence is recorded as None
        return None


# -- checks ---------------------------------------------------------------


def _check_chronology(generations: list[dict]) -> LifecycleCheck:
    values = [g["generation"] for g in generations]
    increasing = all(b > a for a, b in zip(values, values[1:]))
    return LifecycleCheck(
        name="chronology",
        passed=bool(increasing),
        expected="mutation-op generations strictly increase in seq order",
        observed=values,
        evidence={"mutation_receipts": generations,
                  "reason": "ok" if increasing
                  else "generation did not strictly increase"},
    )


def _check_snapshot_correctness(snapshots: list[dict],
                                snapshot_supported: bool) -> LifecycleCheck:
    if not snapshot_supported:
        return LifecycleCheck(
            name="snapshot_correctness", passed=False,
            expected="snapshot doc_ids match the live set",
            observed=None,
            evidence={"reason": "unsupported: snapshot not supported"})
    mismatches = []
    for item in snapshots:
        snap = item["snapshot"]
        observed = sorted(snap.get("doc_ids", []))
        expected = sorted(item["expected_ids"]
                          if item["expected_ids"] is not None
                          else item["live_ids"])
        if set(observed) != set(expected):
            mismatches.append({"seq": item["seq"], "pin": item["pin"],
                               "expected": expected, "observed": observed})
    stability_violations = []
    for prev, curr in zip(snapshots, snapshots[1:]):
        if (curr["mutations"] == prev["mutations"]
                and curr["snapshot"].get("digest") != prev["snapshot"].get("digest")):
            stability_violations.append(
                {"seqs": [prev["seq"], curr["seq"]],
                 "reason": "digest changed with no intervening mutation"})
    passed = not mismatches and not stability_violations
    return LifecycleCheck(
        name="snapshot_correctness",
        passed=passed,
        expected="each snapshot lists exactly the live set; digests stable",
        observed={"snapshots": len(snapshots),
                  "mismatches": len(mismatches),
                  "stability_violations": len(stability_violations)},
        evidence={"mismatches": mismatches,
                  "stability_violations": stability_violations,
                  "digests": [s["snapshot"].get("digest") for s in snapshots],
                  "reason": "ok" if passed else "snapshot/live-set mismatch"},
    )


def _check_no_stale_leakage(queries: list[dict]) -> LifecycleCheck:
    violations = []
    for item in queries:
        live = set(item["live_ids"])
        returned_ids = [h["doc_id"] for h in item["hits"]]
        for doc_id in returned_ids:
            if doc_id not in live:
                violations.append({"seq": item["seq"], "kind": "retired_hit",
                                   "doc_id": doc_id,
                                   "live_ids": sorted(live)})
    violations.extend(_check_no_stale_leakage_text(queries))
    passed = not violations
    return LifecycleCheck(
        name="no_stale_leakage",
        passed=passed,
        expected="queries return only live docs with current text",
        observed={"queries": len(queries),
                  "violations": len(violations)},
        evidence={"violations": violations,
                  "reason": "ok" if passed else "stale content returned"},
    )


def _check_no_stale_leakage_text(queries: list[dict]) -> list[dict]:
    # Text expectations are attached to query records by run_lifecycle via
    # the "live_texts" key when present; records without it skip the sub-check.
    violations = []
    for item in queries:
        live_texts = item.get("live_texts")
        if not live_texts:
            continue
        for hit in item["hits"]:
            if hit.get("text") is None:
                continue
            current = live_texts.get(hit["doc_id"])
            if current is not None and hit["text"] != current:
                violations.append({"seq": item["seq"], "kind": "stale_text",
                                   "doc_id": hit["doc_id"],
                                   "expected_text": current,
                                   "observed_text": hit["text"]})
    return violations


def _check_preservation(final_snapshot: dict | None,
                        final_live_ids: list[str],
                        snapshot_supported: bool) -> LifecycleCheck:
    if not snapshot_supported or final_snapshot is None:
        return LifecycleCheck(
            name="preservation", passed=False,
            expected="snapshot reports every live doc",
            observed=None,
            evidence={"reason": "unsupported: snapshot not supported"})
    reported = set(final_snapshot.get("doc_ids", []))
    expected = set(final_live_ids)
    coverage = source_atom_coverage(reported, expected) if expected else 1.0
    missing = sorted(expected - reported)
    passed = coverage == 1.0
    return LifecycleCheck(
        name="preservation",
        passed=passed,
        expected={"coverage": 1.0},
        observed={"coverage": coverage, "missing": missing,
                  "live": len(expected), "reported": len(reported)},
        evidence={"missing_doc_ids": missing,
                  "reason": "ok" if passed
                  else f"{len(missing)} live doc(s) missing from snapshot"},
    )


def _check_membership(final_snapshot: dict | None,
                      final_live_ids: list[str], policy: str,
                      snapshot_supported: bool) -> LifecycleCheck:
    if not snapshot_supported or final_snapshot is None:
        return LifecycleCheck(
            name="membership", passed=False,
            expected=f"membership verdict under policy {policy!r}",
            observed=None,
            evidence={"reason": "unsupported: snapshot not supported"})
    membership = final_snapshot.get("membership")
    if membership is None:
        passed = policy == "overlapping"
        return LifecycleCheck(
            name="membership", passed=passed,
            expected=f"membership present for policy {policy!r}",
            observed={"membership": None},
            evidence={"reason": "ok (no membership declared)"
                      if passed else "no membership declared"})
    duplicates = duplicate_membership_count(
        [list(part) for part in membership])
    indexed: set[str] = set()
    for part in membership:
        indexed.update(part)
    orphans = orphan_count(set(final_live_ids), indexed)
    if policy == "partition":
        passed = duplicates == 0
        reason = "ok" if passed else (
            f"{duplicates} duplicate membership(s) under partition policy")
    else:
        passed = True
        reason = (f"ok (overlapping policy tolerates {duplicates} "
                  f"duplicate(s))")
    return LifecycleCheck(
        name="membership",
        passed=passed,
        expected={"policy": policy,
                  "max_duplicates": 0 if policy == "partition" else None},
        observed={"policy": policy, "duplicates": duplicates,
                  "orphans": orphans},
        evidence={"duplicates": duplicates, "orphans": orphans,
                  "partitions": len(membership), "reason": reason},
    )


def _check_retrieval_before_after(queries: list[dict], receipts: list[dict],
                                  maintain_supported: bool) -> LifecycleCheck:
    maintain_seqs = [r["seq"] for r in receipts
                     if r["op"] == "maintain" and r["status"] == "ok"]
    probes: dict[str, list[dict]] = {}
    for item in queries:
        if item.get("probe_id") and item.get("recall") is not None:
            probes.setdefault(item["probe_id"], []).append(item)
    if not maintain_supported:
        return LifecycleCheck(
            name="retrieval_before_after_maintenance", passed=False,
            expected="post-maintain recall >= pre-maintain recall",
            observed=None,
            evidence={"reason": "unsupported: maintain not supported"})
    if not maintain_seqs or not probes:
        return LifecycleCheck(
            name="retrieval_before_after_maintenance", passed=True,
            expected="post-maintain recall >= pre-maintain recall",
            observed={"maintains": len(maintain_seqs),
                      "probes": sorted(probes)},
            evidence={"reason": "vacuous: no maintain event or no probes"})
    boundary = maintain_seqs[0]
    regressions = []
    min_recall_violations = []
    observed: dict[str, dict] = {}
    for probe_id, items in sorted(probes.items()):
        pre = [i["recall"] for i in items if i["seq"] < boundary]
        post = [i["recall"] for i in items if i["seq"] > boundary]
        observed[probe_id] = {"pre": pre, "post": post}
        for item in items:
            floor = item.get("min_recall")
            if floor is not None and item["recall"] < floor:
                min_recall_violations.append(
                    {"seq": item["seq"], "probe_id": probe_id,
                     "recall": item["recall"], "min_recall": floor})
        if pre and post and min(post) < min(pre):
            regressions.append({"probe_id": probe_id,
                                "pre": min(pre), "post": min(post)})
    passed = not regressions and not min_recall_violations
    return LifecycleCheck(
        name="retrieval_before_after_maintenance",
        passed=passed,
        expected="post-maintain recall >= pre-maintain recall",
        observed=observed,
        evidence={"regressions": regressions,
                  "min_recall_violations": min_recall_violations,
                  "reason": "ok" if passed else "recall regressed"},
    )


def _check_persistence(reopens: list[dict],
                       snapshot_supported: bool) -> LifecycleCheck:
    if not reopens:
        return LifecycleCheck(
            name="persistence", passed=True,
            expected="post-reopen digest equals pre-close digest",
            observed={"reopens": 0},
            evidence={"reason": "vacuous: no reopen events"})
    if not snapshot_supported:
        return LifecycleCheck(
            name="persistence", passed=False,
            expected="post-reopen digest equals pre-close digest",
            observed=None,
            evidence={"reason": "unsupported: snapshot not supported"})
    mismatches = [r for r in reopens
                  if r["ok"] and r["digest_before"] != r["digest_after"]]
    passed = not mismatches
    return LifecycleCheck(
        name="persistence",
        passed=passed,
        expected="post-reopen digest equals pre-close digest",
        observed={"reopens": len(reopens),
                  "mismatches": len(mismatches)},
        evidence={"reopens": reopens,
                  "reason": "ok" if passed else "state changed across reopen"},
    )


def _check_failure_receipts(receipts: list[dict], error_receipts: list[dict],
                            total_events: int, halt_on_error: bool,
                            halted: bool) -> LifecycleCheck:
    keyed = {(r.get("seq"), r.get("op")) for r in error_receipts}
    missing = [{"seq": r["seq"], "op": r["op"]}
               for r in receipts if r["status"] != "ok"
               and (r["seq"], r["op"]) not in keyed]
    malformed = [r for r in error_receipts
                 if r.get("op") is None or "seq" not in r
                 or not r.get("error_code")]
    halt_ok = True
    if halt_on_error:
        halt_ok = halted == any(r["status"] == "error" for r in receipts)
    else:
        halt_ok = len(receipts) == total_events
    passed = not missing and not malformed and halt_ok
    return LifecycleCheck(
        name="failure_receipts",
        passed=passed,
        expected="every failure has a structured receipt; halt policy obeyed",
        observed={"failures": sum(1 for r in receipts if r["status"] != "ok"),
                  "receipts": len(error_receipts),
                  "halted": halted},
        evidence={"missing_receipts": missing,
                  "malformed_receipts": len(malformed),
                  "halt_ok": halt_ok,
                  "reason": "ok" if passed else "receipt/halt violation"},
    )
