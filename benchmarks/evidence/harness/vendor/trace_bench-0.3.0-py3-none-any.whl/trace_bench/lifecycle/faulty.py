"""Deliberately faulty lifecycle backends (negative controls).

Each variant subclasses the reference backend and breaks EXACTLY one
property, so a green reference run plus red faulty runs proves each check
actually detects its target failure:

- :class:`StaleLeakBackend` -> ``no_stale_leakage`` (retired docs returned)
- :class:`PreUpdateLeakBackend` -> ``no_stale_leakage`` (pre-update text)
- :class:`GenerationRegressionBackend` -> ``chronology``
- :class:`MembershipLiarBackend` -> ``membership`` (under partition policy)
- :class:`ReopenAmnesiaBackend` -> ``persistence``
"""

from trace_bench.lifecycle.reference import ReferenceLifecycleBackend


class StaleLeakBackend(ReferenceLifecycleBackend):
    """Query searches retired docs too. Fails ``no_stale_leakage``."""

    def query(self, text: str, top_k: int = 10,
              generation: int | None = None) -> list[dict]:
        from trace_bench.lifecycle.reference import tokenize
        query_tokens = tokenize(text)
        scored = []
        for doc_id in self._store:
            record = self._store[doc_id]
            if generation is not None and record["generation_updated"] > generation:
                continue
            overlap = len(query_tokens & tokenize(record["text"]))
            if query_tokens and overlap > 0:
                scored.append((doc_id, overlap))
        scored.sort(key=lambda item: (-item[1], item[0]))
        return [{"doc_id": d, "score": float(s),
                 "text": self._store[d]["text"]}
                for d, s in scored[: max(top_k, 0)]]


class PreUpdateLeakBackend(ReferenceLifecycleBackend):
    """Query returns live ids but pre-update text. Fails ``no_stale_leakage``."""

    def __init__(self) -> None:
        super().__init__()
        self._stale_text: dict[str, str] = {}

    def update(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        existing = self._store.get(doc_id)
        if existing is not None and existing["alive"]:
            self._stale_text.setdefault(doc_id, existing["text"])
        return super().update(doc_id, text, title, metadata)

    def query(self, text: str, top_k: int = 10,
              generation: int | None = None) -> list[dict]:
        hits = super().query(text, top_k, generation)
        for hit in hits:
            if hit["doc_id"] in self._stale_text:
                hit["text"] = self._stale_text[hit["doc_id"]]
        return hits


class GenerationRegressionBackend(ReferenceLifecycleBackend):
    """``maintain()`` moves the generation backwards. Fails ``chronology``."""

    def maintain(self) -> dict:
        receipt = super().maintain()
        self._generation -= 1
        receipt["generation"] = self._generation
        return receipt


class MembershipLiarBackend(ReferenceLifecycleBackend):
    """Snapshot duplicates one doc across partitions. Fails ``membership``
    under the partition policy; tolerated under the overlapping policy."""

    def snapshot(self) -> dict:
        snap = super().snapshot()
        live = snap["doc_ids"]
        if live:
            snap["membership"] = [list(live), [live[0]]]
        return snap


class ReopenAmnesiaBackend(ReferenceLifecycleBackend):
    """``reopen()`` loses the most recent insert/update. Fails ``persistence``
    (later snapshot/preservation checks cascade, by design)."""

    def __init__(self) -> None:
        super().__init__()
        self._last_mutated: str | None = None

    def insert(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        receipt = super().insert(doc_id, text, title, metadata)
        if receipt.get("ok"):
            self._last_mutated = doc_id
        return receipt

    def update(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        receipt = super().update(doc_id, text, title, metadata)
        if receipt.get("ok"):
            self._last_mutated = doc_id
        return receipt

    def reopen(self) -> dict:
        receipt = super().reopen()
        if self._last_mutated is not None:
            forgotten = self._store.pop(self._last_mutated, None)
            if forgotten is not None:
                self._rebuild_index()
                receipt["forgotten_doc_id"] = self._last_mutated
            self._last_mutated = None
        return receipt


FAULTY_BACKENDS: dict[str, type[ReferenceLifecycleBackend]] = {
    "stale_leak": StaleLeakBackend,
    "pre_update_leak": PreUpdateLeakBackend,
    "generation_regression": GenerationRegressionBackend,
    "membership_liar": MembershipLiarBackend,
    "reopen_amnesia": ReopenAmnesiaBackend,
}
