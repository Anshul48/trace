"""Lifecycle evaluation contracts (Deliverable 4).

No Trace product lifecycle adapter exists yet: the registry exposes only the
deterministic reference backend and the faulty negative controls. Product
adapters are out of scope for this deliverable.
"""

from trace_bench.lifecycle.contract import (
    OPERATIONS,
    LifecycleBackend,
    LifecycleNotSupported,
)
from trace_bench.lifecycle.faulty import (
    FAULTY_BACKENDS,
    GenerationRegressionBackend,
    MembershipLiarBackend,
    PreUpdateLeakBackend,
    ReopenAmnesiaBackend,
    StaleLeakBackend,
)
from trace_bench.lifecycle.fixtures import (
    FIXTURES,
    get_fixture,
    list_fixtures,
)
from trace_bench.lifecycle.reference import ReferenceLifecycleBackend
from trace_bench.lifecycle.runner import (
    CHECK_NAMES,
    LifecycleCheck,
    LifecycleResult,
    normalize_hits,
    run_lifecycle,
)

BACKEND_REGISTRY: dict[str, type[LifecycleBackend]] = {
    "reference": ReferenceLifecycleBackend,
    **FAULTY_BACKENDS,
}

__all__ = [
    "OPERATIONS",
    "CHECK_NAMES",
    "BACKEND_REGISTRY",
    "FAULTY_BACKENDS",
    "FIXTURES",
    "LifecycleBackend",
    "LifecycleNotSupported",
    "LifecycleCheck",
    "LifecycleResult",
    "ReferenceLifecycleBackend",
    "StaleLeakBackend",
    "PreUpdateLeakBackend",
    "GenerationRegressionBackend",
    "MembershipLiarBackend",
    "ReopenAmnesiaBackend",
    "get_fixture",
    "list_fixtures",
    "normalize_hits",
    "run_lifecycle",
]
