"""Deterministic in-memory reference lifecycle backend.

Implements the full :class:`LifecycleBackend` contract honestly with simple,
deterministic mechanics: a dict store, a generation counter bumped per
mutation, a token-overlap query index rebuilt incrementally on mutation and
fully on ``maintain()``, and real JSON persistence round-tripped through a
backend-owned temp dir on ``reopen()``.

The reference exists to validate harness mechanics, not Trace capability:
a green run proves the fixture/runner/checks work, nothing about retrieval
quality of any product.
"""

import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path

from trace_bench.lifecycle.contract import (
    ERR_LIFECYCLE_DUPLICATE,
    ERR_LIFECYCLE_NOT_FOUND,
    ERR_LIFECYCLE_RETIRED,
    OPERATIONS,
    LifecycleBackend,
)

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def tokenize(text: str) -> set[str]:
    """Lowercase alphanumeric tokenization (deterministic, offline)."""
    return set(_TOKEN_RE.findall(text.lower()))


def content_digest(items: list[dict]) -> str:
    """sha256 over canonical JSON of sorted live items (content identity)."""
    canonical = json.dumps(items, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class ReferenceLifecycleBackend(LifecycleBackend):
    """Full-contract in-memory backend with real reopen persistence."""

    def __init__(self) -> None:
        self._store: dict[str, dict] = {}
        self._index: dict[str, set[str]] = {}
        self._generation = 0
        self._tmpdir = Path(tempfile.mkdtemp(prefix="tb-lifecycle-ref-"))
        self._state_file = self._tmpdir / "state.json"
        self._closed = False

    # -- capabilities ----------------------------------------------------
    def capabilities(self) -> dict[str, bool]:
        return {op: True for op in OPERATIONS}

    # -- mutations --------------------------------------------------------
    def insert(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        existing = self._store.get(doc_id)
        if existing is not None and existing["alive"]:
            return self._receipt("insert", ok=False,
                                 error=ERR_LIFECYCLE_DUPLICATE, doc_id=doc_id)
        self._generation += 1
        self._store[doc_id] = {
            "text": text,
            "title": title,
            "metadata": dict(metadata or {}),
            "alive": True,
            "generation_updated": self._generation,
        }
        self._index_doc(doc_id)
        self._persist()
        return self._receipt("insert", ok=True, doc_id=doc_id)

    def update(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        existing = self._store.get(doc_id)
        if existing is None or not existing["alive"]:
            code = ERR_LIFECYCLE_NOT_FOUND if existing is None else ERR_LIFECYCLE_RETIRED
            return self._receipt("update", ok=False, error=code, doc_id=doc_id)
        self._generation += 1
        self._unindex_doc(doc_id)
        existing["text"] = text
        existing["title"] = title
        if metadata is not None:
            existing["metadata"] = dict(metadata)
        existing["generation_updated"] = self._generation
        self._index_doc(doc_id)
        self._persist()
        return self._receipt("update", ok=True, doc_id=doc_id)

    def retire(self, doc_id: str) -> dict:
        existing = self._store.get(doc_id)
        if existing is None or not existing["alive"]:
            code = ERR_LIFECYCLE_NOT_FOUND if existing is None else ERR_LIFECYCLE_RETIRED
            return self._receipt("retire", ok=False, error=code, doc_id=doc_id)
        self._generation += 1
        existing["alive"] = False
        self._unindex_doc(doc_id)
        self._persist()
        return self._receipt("retire", ok=True, doc_id=doc_id)

    def maintain(self) -> dict:
        """Full deterministic index rebuild; bumps the generation."""
        self._generation += 1
        self._rebuild_index()
        self._persist()
        return self._receipt("maintain", ok=True)

    # -- reads -------------------------------------------------------------
    def query(self, text: str, top_k: int = 10,
              generation: int | None = None) -> list[dict]:
        """Token-overlap search over live docs; ties break by doc_id order."""
        scored = self._score_live_docs(text, generation)
        scored.sort(key=lambda item: (-item[1], item[0]))
        return [
            {"doc_id": doc_id, "score": float(score),
             "text": self._store[doc_id]["text"]}
            for doc_id, score in scored[: max(top_k, 0)]
        ]

    def snapshot(self) -> dict:
        live_ids = sorted(d for d, v in self._store.items() if v["alive"])
        items = [
            {"doc_id": d, "text": self._store[d]["text"],
             "title": self._store[d]["title"],
             "metadata": self._store[d]["metadata"]}
            for d in live_ids
        ]
        return {
            "generation": self._generation,
            "doc_ids": live_ids,
            "membership": [list(live_ids)],
            "digest": content_digest(items),
        }

    # -- persistence ---------------------------------------------------------
    def reopen(self) -> dict:
        """Persist, wipe in-memory state, reload from disk (real round-trip)."""
        self._persist()
        saved_generation = self._generation
        self._store = {}
        self._index = {}
        self._load()
        assert self._generation == saved_generation
        return self._receipt("reopen", ok=True)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            shutil.rmtree(self._tmpdir, ignore_errors=True)

    # -- internals ------------------------------------------------------------
    def _receipt(self, op: str, ok: bool, error: str | None = None,
                 **extra) -> dict:
        receipt: dict = {"op": op, "generation": self._generation, "ok": ok}
        if error is not None:
            receipt["error"] = error
        receipt.update(extra)
        return receipt

    def _score_live_docs(self, text: str,
                         generation: int | None) -> list[tuple[str, int]]:
        query_tokens = tokenize(text)
        if not query_tokens:
            return []
        candidate_ids: set[str] = set()
        for token in query_tokens:
            candidate_ids |= self._index.get(token, set())
        scored = []
        for doc_id in candidate_ids:
            record = self._store.get(doc_id)
            if record is None or not record["alive"]:
                continue
            if generation is not None and record["generation_updated"] > generation:
                continue
            overlap = len(query_tokens & tokenize(record["text"]))
            if overlap > 0:
                scored.append((doc_id, overlap))
        return scored

    def _index_doc(self, doc_id: str) -> None:
        for token in tokenize(self._store[doc_id]["text"]):
            self._index.setdefault(token, set()).add(doc_id)

    def _unindex_doc(self, doc_id: str) -> None:
        for token in tokenize(self._store[doc_id]["text"]):
            posting = self._index.get(token)
            if posting is not None:
                posting.discard(doc_id)
                if not posting:
                    del self._index[token]

    def _rebuild_index(self) -> None:
        self._index = {}
        for doc_id in sorted(self._store):
            if self._store[doc_id]["alive"]:
                self._index_doc(doc_id)

    def _persist(self) -> None:
        payload = {"generation": self._generation, "store": self._store}
        self._state_file.write_text(
            json.dumps(payload, sort_keys=True), encoding="utf-8")

    def _load(self) -> None:
        payload = json.loads(self._state_file.read_text(encoding="utf-8"))
        self._generation = payload["generation"]
        self._store = payload["store"]
        self._rebuild_index()
