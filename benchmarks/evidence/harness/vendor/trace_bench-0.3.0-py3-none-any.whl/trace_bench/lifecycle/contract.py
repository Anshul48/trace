"""Lifecycle evaluation backend contract (Deliverable 4).

Small, optional, TB-facing protocol for backends that support a mutable
document lifecycle: insert / update / retire / maintain / query / snapshot /
reopen. All operations are optional via capability flags; backends raise
:class:`LifecycleNotSupported` for operations they do not implement and the
runner records ``unsupported`` (never success, never a silent zero).

Receipts are plain dicts: ``{"op": str, "generation": int, "ok": bool,
"error": str | None, ...}``. Query results are ``(doc_id, score)`` pairs or
dicts with ``doc_id``/``score`` and an optional ``text`` field; the runner
normalizes both shapes.
"""

from abc import ABC

OPERATIONS: tuple[str, ...] = (
    "insert",
    "update",
    "retire",
    "maintain",
    "query",
    "snapshot",
    "reopen",
)

PARTITION_POLICIES: tuple[str, ...] = ("partition", "overlapping")

ERR_LIFECYCLE_UNSUPPORTED = "ERR_LIFECYCLE_UNSUPPORTED"
ERR_LIFECYCLE_UNKNOWN_OP = "ERR_LIFECYCLE_UNKNOWN_OP"
ERR_LIFECYCLE_DUPLICATE = "ERR_LIFECYCLE_DUPLICATE"
ERR_LIFECYCLE_NOT_FOUND = "ERR_LIFECYCLE_NOT_FOUND"
ERR_LIFECYCLE_RETIRED = "ERR_LIFECYCLE_RETIRED"
ERR_LIFECYCLE_BACKEND_ERROR = "ERR_LIFECYCLE_BACKEND_ERROR"


class LifecycleNotSupported(Exception):
    """Raised by backends for operations outside their capability set."""

    def __init__(self, operation: str, message: str | None = None):
        super().__init__(message or f"operation not supported: {operation}")
        self.operation = operation


class LifecycleBackend(ABC):
    """Abstract lifecycle backend. Override supported ops; leave the rest."""

    def name(self) -> str:
        """Backend name used in result artifacts."""
        return self.__class__.__name__

    def capabilities(self) -> dict[str, bool]:
        """Capability flags for every op in :data:`OPERATIONS`.

        Missing keys are treated as ``False`` (fail closed) by the runner.
        """
        return {op: False for op in OPERATIONS}

    def insert(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        """Insert a new live document."""
        raise LifecycleNotSupported("insert")

    def update(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        """Replace the text of a live document."""
        raise LifecycleNotSupported("update")

    def retire(self, doc_id: str) -> dict:
        """Retire a document: it must stop appearing in queries/snapshots."""
        raise LifecycleNotSupported("retire")

    def maintain(self) -> dict:
        """Run an organization/index-maintenance pass."""
        raise LifecycleNotSupported("maintain")

    def query(self, text: str, top_k: int = 10,
              generation: int | None = None) -> list:
        """Return top-k hits over live docs as ``(doc_id, score)`` pairs or
        ``{"doc_id", "score", "text"?}`` dicts. When ``generation`` is pinned,
        only content committed at or before that generation is visible."""
        raise LifecycleNotSupported("query")

    def snapshot(self) -> dict:
        """Return ``{generation, doc_ids, membership, digest}``.

        ``membership`` is a list of partitions (each a list of doc ids);
        ``digest`` is an opaque content identity string.
        """
        raise LifecycleNotSupported("snapshot")

    def reopen(self) -> dict:
        """Close and reopen persistent state; state must be preserved."""
        raise LifecycleNotSupported("reopen")

    def close(self) -> None:
        """Release resources (temp dirs, handles). Idempotent."""
