"""Terminal inspection for workload + HV envelopes (read-only rendering)."""

from __future__ import annotations

import json
from pathlib import Path


def load_envelope(path: str | Path) -> dict:
    doc = json.loads(Path(path).read_text(encoding="utf-8"))
    if doc.get("format") not in ("tb-workload-result-v1", "tb-hv-result-v1"):
        raise ValueError(f"not a workload/HV envelope: {path}")
    return doc


def render_envelope(doc: dict) -> str:
    if doc["format"] == "tb-hv-result-v1":
        return _render_hv(doc)
    return _render_workload(doc)


def _render_workload(doc: dict) -> str:
    lines = [
        f"workload {doc['workload']} [{doc['format']}] verdict={doc['verdict']}",
        f"tb_version={doc.get('tb_version')} seed={doc.get('seed')} "
        f"budgets={json.dumps(doc.get('budgets'), sort_keys=True)}",
        f"fixtures: {', '.join(f['stem'] + '@' + (f['sha256'] or '')[:12] for f in doc.get('fixtures', []))}",
        f"costs: {json.dumps(doc.get('costs_total'), sort_keys=True)}",
        "",
        f"{'arm':44} {'backend':18} {'verdict':13} {'delta':>8} {'met':>4}",
    ]
    for arm in doc.get("arms", []):
        observed = arm.get("observed", {})
        delta = observed.get("coverage_delta", observed.get("coverage_deltas", "-"))
        if isinstance(delta, list):
            delta = ",".join(f"{d:.3f}" for d in delta)
        elif isinstance(delta, float):
            delta = f"{delta:+.4f}"
        lines.append(f"{arm['arm_id']:44} {arm['backend']:18} "
                     f"{str(observed.get('verdict')):13} {str(delta):>8} "
                     f"{'yes' if arm.get('expectation_met') else 'NO':>4}")
        if not arm.get("expectation_met"):
            lines.append(f"    expectation: {arm.get('expectation_detail')}")
        if arm.get("oracle"):
            lines.append(f"    oracle {arm['oracle'].get('oracle')}: "
                         f"passed={arm['oracle'].get('passed')}")
    lines.append("")
    for note in doc.get("notes", []):
        lines.append(f"note: {note}")
    if doc.get("stopped"):
        lines.append(f"stopped: {doc['stopped']}")
        lines.append(f"pending: {', '.join(doc.get('arms_pending', []))}")
    return "\n".join(lines) + "\n"


def _render_hv(doc: dict) -> str:
    denom = doc.get("denominators", {})
    lines = [
        f"hv task={doc['task']} cohort={doc['cohort']} profile={doc.get('profile')}",
        f"tb_version={doc.get('tb_version')} top_k={doc.get('top_k')}",
        f"docs encountered={denom.get('docs_encountered')} "
        f"indexed={denom.get('docs_indexed')} "
        f"withheld={denom.get('docs_withheld')}",
        f"TOK-v1 encountered={denom.get('tok_v1_encountered')} "
        f"indexed={denom.get('tok_v1_indexed')}",
        f"queries scored={len(doc.get('queries', {}).get('scored', []))} "
        f"unscored={len(doc.get('queries', {}).get('unscored', []))} "
        f"unjudged_hits_at_k={doc.get('unjudged_hits_at_k')}",
        f"cohort_sha256={denom.get('cohort_sha256')}",
        f"costs: {json.dumps(doc.get('costs'), sort_keys=True)}",
    ]
    for entry in doc.get("queries", {}).get("unscored", []):
        lines.append(f"unscored {entry['query_native_id']}: {entry['reason']} "
                     f"{json.dumps(entry.get('classes'), sort_keys=True)}")
    for row in doc.get("withheld", [])[:10]:
        lines.append(f"withheld {row['tbdoc_id']}: {row.get('acquisition')}")
    if doc.get("withheld_truncated"):
        lines.append("withheld list truncated at 1000 (count above is exact)")
    lines.append(f"claim: {doc.get('claim_boundary')}")
    lines.append(f"run.json: {doc.get('run_json')}")
    return "\n".join(lines) + "\n"
