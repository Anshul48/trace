"""W1-W4 installed workload runners (TB-only, offline from bundled fixtures).

Workloads reuse :mod:`trace_bench.metrics.org_eval` and
:mod:`trace_bench.metrics.org_eval_natural` (imported, never modified) over
wheel-bundled fixtures (:data:`FIXTURE_DIR`). No network, no ``/tmp``
defaults, no implicit corpus: every run records fixtures (digests), seed,
budgets, costs, and per-arm evidence in a ``tb-workload-result-v1`` envelope.

Honesty labels (kept in every envelope and every terminal rendering):

- ``pilot_conjunction`` is a LABELED instrument/control demonstration: its
  before/after delta is attributable to the maintain pass on an unchanged
  population. It is never DB-improvement evidence.
- Faulty arms (``org_membership_liar``, ``org_stale_leak``) are expected to
  be flagged ``invalid``; an unflagged faulty arm FAILS the workload.
- W3 verdicts over changed populations are ``incomparable`` (confounded),
  never utility. W4 version replacement is ``incomparable`` by design.

Gates (fail closed before scoring): quarantined-ID exclusion (bundled
quarantine list, IDs only), LKML-content exclusion for every shipped small
fixture, budget ceilings, and absolute-path hygiene of recorded scopes.
"""

from __future__ import annotations

import copy
import hashlib
import json
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from trace_bench.lifecycle.contract import LifecycleBackend
from trace_bench.lifecycle.reference import ReferenceLifecycleBackend
from trace_bench.metrics.org_eval import (
    AppendOnlyControlBackend,
    NoDrainControlBackend,
    OrgEvalResult,
    OrgMembershipLiarBackend,
    OrgStaleLeakBackend,
    OrgTask,
    Stage,
    StageDescriptor,
    load_task_and_stages,
    run_before_after,
)
from trace_bench.metrics.org_eval_natural import (
    PilotConjunctionBackend,
    check_lifecycle_oracle,
    insert_stages,
    make_shift_task,
    order_variants,
    run_order_experiment,
    run_with_resources,
    summarize_order_vs_shift,
)
from trace_bench.workloads import ENVELOPE_FORMAT, FIXTURE_DIR

PILOT_LABEL = (
    "LABELED instrument/control demonstration (PilotConjunctionBackend): "
    "conjunctive lookup before maintain, overlap ranking after. The "
    "before/after delta on an unchanged population is attributable to the "
    "maintain pass. This is harness mechanics, never DB-improvement evidence."
)

SYNTHETIC_LABEL = (
    "Synthetic TB-authored fixture: proves the instrument (oracle, spans, "
    "lineage mechanics), never a historical-truth or usefulness claim."
)

EVIDENCE_EXCERPT_CHARS = 500
DEFAULT_SEED = 42
DEFAULT_BUDGETS = {"top_k_max": 10, "max_docs_per_arm": 1000,
                   "deadline_s": None, "memory_mb": None}


def tb_version() -> str:
    try:
        from trace_bench import __version__

        return __version__
    except Exception:
        return "unknown"


# -- backend registry (classes imported, never modified) --------------------

BACKEND_FACTORIES: dict[str, Callable[[], LifecycleBackend]] = {
    "reference": ReferenceLifecycleBackend,
    "pilot_conjunction": PilotConjunctionBackend,
    "no_drain": NoDrainControlBackend,
    "append_only": AppendOnlyControlBackend,
    "org_membership_liar": OrgMembershipLiarBackend,
    "org_stale_leak": OrgStaleLeakBackend,
}

BACKEND_NOTES: dict[str, str] = {
    "reference": "honest reference backend (overlap ranking, full lifecycle)",
    "pilot_conjunction": PILOT_LABEL,
    "no_drain": "honest control: full lifecycle except maintain",
    "append_only": "honest control: insert/query/snapshot/maintain only",
    "org_membership_liar": "DELIBERATELY FAULTY control: must be flagged invalid",
    "org_stale_leak": "DELIBERATELY FAULTY control: must be flagged invalid",
}


# -- gates ------------------------------------------------------------------

def load_quarantine_ids() -> frozenset[str]:
    """Bundled quarantine list (tbdoc IDs only, never bytes)."""
    path = FIXTURE_DIR / "quarantine-lkml-31.txt"
    ids = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            ids.add(line)
    return frozenset(ids)


def _iter_id_fields(payload: object) -> list[str]:
    found: list[str] = []
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in ("tbdoc_id", "native_id") and isinstance(value, str):
                found.append(value)
            else:
                found.extend(_iter_id_fields(value))
    elif isinstance(payload, list):
        for item in payload:
            found.extend(_iter_id_fields(item))
    return found


def quarantine_matches(stem: str) -> list[str]:
    """Quarantined IDs referenced by a fixture + provenance (must be empty)."""
    quarantined = load_quarantine_ids()
    fixture = json.loads((FIXTURE_DIR / f"{stem}.json").read_text(encoding="utf-8"))
    prov_path = FIXTURE_DIR / f"{stem}-provenance.json"
    provenance = json.loads(prov_path.read_text(encoding="utf-8")) if prov_path.is_file() else {}
    return sorted(set(_iter_id_fields(fixture)) & quarantined
                  | set(_iter_id_fields(provenance)) & quarantined)


def lkml_content_refs(stem: str) -> list[str]:
    """LKML *content* references (tbdoc/stratum/native identity), if any.

    A prose exclusion note mentioning LKML (e.g. ``arrival_key``) is
    compliance evidence, not content: only structured source identities
    (``tbdoc:lkml:`` IDs, ``lkml`` strata, ``lkml:`` native IDs) count.
    """
    fixture = json.loads((FIXTURE_DIR / f"{stem}.json").read_text(encoding="utf-8"))
    prov_path = FIXTURE_DIR / f"{stem}-provenance.json"
    provenance = json.loads(prov_path.read_text(encoding="utf-8")) if prov_path.is_file() else {}
    refs: list[str] = []
    for payload in (fixture, provenance):
        for value in _iter_id_fields(payload):
            lowered = value.lower()
            if ":lkml:" in lowered or lowered.startswith("lkml:"):
                refs.append(value)
        for pop in (provenance.get("population") or []) + (fixture.get("documents") or []):
            if isinstance(pop, dict) and str(pop.get("stratum", "")).lower() == "lkml":
                refs.append(f"stratum-of:{pop.get('doc_id')}")
    return sorted(set(refs))


def check_budgets(task: OrgTask, budgets: dict) -> None:
    """Fail closed when a fixture exceeds declared budgets (never truncate)."""
    if len(task.documents) > int(budgets.get("max_docs_per_arm", 10**9)):
        raise ValueError(
            f"fixture {task.name} has {len(task.documents)} docs, over budget "
            f"max_docs_per_arm={budgets['max_docs_per_arm']}; refusing (no truncation).")
    top_max = int(budgets.get("top_k_max", 10**9))
    for query in task.queries:
        if query.top_k > top_max:
            raise ValueError(
                f"query {query.query_id} top_k={query.top_k} exceeds budget "
                f"top_k_max={top_max}; refusing.")


def fixture_sha256(stem: str) -> str:
    return hashlib.sha256(
        (FIXTURE_DIR / f"{stem}.json").read_bytes()).hexdigest()


# -- recording proxy (per-stage per-query hit evidence) ---------------------

class RecordingProxy(LifecycleBackend):
    """Delegates to a real backend while recording query hit evidence."""

    def __init__(self, backend: LifecycleBackend) -> None:
        self._backend = backend
        self.recordings: list[dict] = []

    def name(self) -> str:
        return self._backend.name()

    def capabilities(self) -> dict[str, bool]:
        return dict(self._backend.capabilities() or {})

    def insert(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        return self._backend.insert(doc_id, text, title, metadata)

    def update(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        return self._backend.update(doc_id, text, title, metadata)

    def retire(self, doc_id: str) -> dict:
        return self._backend.retire(doc_id)

    def maintain(self) -> dict:
        return self._backend.maintain()

    def query(self, text: str, top_k: int = 10,
              generation: int | None = None) -> list:
        raw = self._backend.query(text, top_k, generation)
        hits = []
        for item in raw or []:
            if isinstance(item, dict):
                hits.append({"doc_id": item["doc_id"],
                             "score": float(item.get("score", 0.0)),
                             "text": item.get("text")})
            else:
                hits.append({"doc_id": item[0], "score": float(item[1]),
                             "text": item[2] if len(item) > 2 else None})
        self.recordings.append({"text": text, "top_k": top_k, "hits": hits})
        return raw

    def snapshot(self) -> dict:
        return self._backend.snapshot()

    def reopen(self) -> dict:
        return self._backend.reopen()

    def close(self) -> None:
        self._backend.close()


def chunk_recordings(proxy: RecordingProxy, task: OrgTask,
                     stages: list[Stage]) -> list[dict]:
    """Split recordings into per-stage per-query evidence (fail closed)."""
    per_stage = len(task.queries)
    expected = per_stage * len(stages)
    if len(proxy.recordings) != expected:
        raise ValueError(
            f"recording count {len(proxy.recordings)} != stages({len(stages)}) "
            f"x queries({per_stage}); evidence incomplete, refusing.")
    chunks = []
    for index, stage in enumerate(stages):
        queries = []
        for query, rec in zip(task.queries,
                              proxy.recordings[index * per_stage:(index + 1) * per_stage]):
            if rec["text"] != query.text:
                raise ValueError("recording/query order drifted; refusing.")
            queries.append({
                "query_id": query.query_id,
                "gold": list(query.gold),
                "hits": [
                    {"doc_id": h["doc_id"], "score": h["score"],
                     "text_excerpt": (h["text"] or "")[:EVIDENCE_EXCERPT_CHARS],
                     "text_sha256": hashlib.sha256(
                         (h["text"] or "").encode("utf-8")).hexdigest(),
                     "text_chars": len(h["text"] or "")}
                    for h in rec["hits"]],
            })
        chunks.append({"role": stage.descriptor.role, "queries": queries})
    return chunks


# -- arms -------------------------------------------------------------------

@dataclass
class ArmSpec:
    arm_id: str
    kind: str  # before_after | orders | shift_combined
    workload: str
    fixture: str
    backend: str
    expected: dict = field(default_factory=dict)


@dataclass
class Control:
    cancel_event: threading.Event | None = None
    deadline_monotonic: float | None = None

    def check(self, label: str) -> None:
        if self.cancel_event is not None and self.cancel_event.is_set():
            raise _Cancelled(f"cancel requested before {label}")
        if self.deadline_monotonic is not None and \
                time.monotonic() >= self.deadline_monotonic:
            raise _Deadline(f"deadline exceeded before {label}")


class _Cancelled(Exception):
    pass


class _Deadline(Exception):
    pass


def build_plan(workload: str, backends: list[str] | None = None) -> list[ArmSpec]:
    """Deterministic arm matrix for a workload (unknown names fail closed)."""
    if workload == "w1":
        fixtures = ["w1-pony", "w1-scifact"]
        default_backends = ["pilot_conjunction", "no_drain", "append_only",
                            "reference", "org_membership_liar"]
        kinds = "before_after"
    elif workload == "w2":
        fixtures = ["w2-orders"]
        default_backends = ["pilot_conjunction", "reference"]
        kinds = "orders"
    elif workload == "w3":
        fixtures = ["w3-chronological", "w3-topic"]
        default_backends = ["reference"]
        kinds = "before_after"
    elif workload == "w4":
        fixtures = ["w4-lifecycle", "w4-contradiction"]
        default_backends = ["reference", "org_stale_leak", "append_only"]
        kinds = "before_after"
    else:
        raise ValueError(f"unknown workload: {workload!r} (expected w1-w4)")
    chosen = default_backends if not backends else list(backends)
    for name in chosen:
        if name not in BACKEND_FACTORIES:
            raise ValueError(
                f"unknown workload backend: {name!r} "
                f"(available: {', '.join(sorted(BACKEND_FACTORIES))})")
    plan = [ArmSpec(arm_id=f"{workload}/{stem}/{name}", kind=kinds,
                    workload=workload, fixture=stem, backend=name,
                    expected=default_expectation(workload, stem, name))
            for stem in fixtures for name in chosen]
    if workload == "w3" and "reference" in chosen:
        plan.append(ArmSpec(arm_id="w3/combined-shift/reference",
                            kind="shift_combined", workload="w3",
                            fixture="w1-pony+w3-topic", backend="reference",
                            expected=default_expectation("w3", "combined-shift",
                                                         "reference")))
    return plan


def default_expectation(workload: str, fixture: str, backend: str) -> dict:
    """Harness expectation per arm (observed == expected passes the arm)."""
    if backend in ("org_membership_liar", "org_stale_leak"):
        check = "membership" if "membership" in backend else "no_stale_leakage"
        return {"verdict": "invalid", "checks": {check: False},
                "note": "faulty control must be flagged invalid"}
    if workload == "w1" and backend == "pilot_conjunction":
        return {"verdict": "improvement", "delta": "positive",
                "population_changed": False,
                "note": "labeled instrument: maintain-pass delta on unchanged population"}
    if workload == "w1":
        return {"verdict": "no_change", "delta": "zero",
                "population_changed": False,
                "note": "honest control/reference: no maintenance effect measured"}
    if workload == "w2" and backend == "pilot_conjunction":
        return {"verdict": "improvement", "equal_deltas": True,
                "note": "paired orders: same delta on every arrival order"}
    if workload == "w2":
        return {"verdict": "no_change", "equal_deltas": True,
                "note": "paired orders: flat delta on every arrival order"}
    if workload == "w3" and fixture == "w3-chronological":
        return {"verdict": "incomparable", "population_changed": True,
                "note": "EDGAR arrival waves: population shift by design (confounded, not utility)"}
    if workload == "w3" and fixture == "combined-shift":
        return {"verdict": "incomparable", "population_changed": True,
                "population_added_nonempty": True,
                "note": "topic shift arm: added population reported, never merged with order effects"}
    if workload == "w3":
        return {"verdict": "no_change", "population_changed": False,
                "note": "shift-population maintenance probe (population held constant)"}
    if workload == "w4" and fixture == "w4-contradiction":
        if backend == "append_only":
            return {"verdict": "invalid", "unsupported_min": 1,
                    "note": "append-only cannot retire the superseded version (fail closed)"}
        return {"verdict": "incomparable", "population_changed": True,
                "oracle": "contradiction",
                "note": "version replacement is a population change: incomparable by design + span oracle must pass"}
    if workload == "w4":
        if backend == "append_only":
            return {"verdict": "invalid", "unsupported_min": 1,
                    "note": "append-only cannot run the retire script (fail closed)"}
        return {"verdict": "incomparable", "population_changed": True,
                "oracle": "lifecycle",
                "note": "retire script: incomparable by design + stale-leak oracle must pass"}
    raise ValueError(f"no expectation for {workload}/{fixture}/{backend}")


# -- arm execution ----------------------------------------------------------

def load_provenance(stem: str) -> dict:
    path = FIXTURE_DIR / f"{stem}-provenance.json"
    if not path.is_file():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def check_expectation(spec: ArmSpec, observed: dict) -> tuple[bool, str]:
    """Compare observed arm outcome against the harness expectation."""
    exp = spec.expected
    failures: list[str] = []
    if observed.get("verdict") != exp.get("verdict"):
        failures.append(
            f"verdict {observed.get('verdict')!r} != expected {exp.get('verdict')!r}")
    for name, want in (exp.get("checks") or {}).items():
        got = (observed.get("checks") or {}).get(name)
        if got != want:
            failures.append(f"check {name}: {got} != expected {want}")
    if "delta" in exp:
        delta = observed.get("coverage_delta") or 0.0
        if exp["delta"] == "positive" and not delta > 0:
            failures.append(f"delta {delta} is not positive")
        if exp["delta"] == "zero" and not delta == 0.0:
            failures.append(f"delta {delta} is not zero")
    if "population_changed" in exp and \
            observed.get("population_changed") != exp["population_changed"]:
        failures.append("population_changed mismatch")
    if exp.get("population_added_nonempty") and not observed.get("population_added"):
        failures.append("population_added is empty")
    if "unsupported_min" in exp and \
            int(observed.get("unsupported_ops") or 0) < int(exp["unsupported_min"]):
        failures.append("expected unsupported ops were not recorded")
    if exp.get("equal_deltas") and not observed.get("deltas_equal"):
        failures.append("arrival-order deltas differ")
    if exp.get("oracle") and not observed.get("oracle_passed"):
        failures.append(f"{exp['oracle']} oracle did not pass")
    if failures:
        return False, "; ".join(failures)
    return True, "observed == expected"


def _observed_summary(result: OrgEvalResult) -> dict:
    return {
        "verdict": result.verdict,
        "coverage_delta": result.coverage_delta,
        "preservation_delta": result.preservation_delta,
        "checks": {c.name: c.passed for c in result.checks},
        "population_changed": result.attribution.get("population_changed"),
        "population_added": result.attribution.get("population_added", []),
        "population_removed": result.attribution.get("population_removed", []),
        "unsupported_ops": result.attribution.get("unsupported_ops", 0),
        "maintain_ops": result.attribution.get("maintain_ops", 0),
    }


def run_before_after_arm(spec: ArmSpec, budgets: dict, seed: int) -> dict:
    """Execute one fixture fixture x backend before/after arm with evidence."""
    task, stages = load_task_and_stages(FIXTURE_DIR / f"{spec.fixture}.json")
    check_budgets(task, budgets)
    factory = BACKEND_FACTORIES[spec.backend]
    proxy = RecordingProxy(factory())

    def _run():
        return run_before_after(proxy, task, stages)

    try:
        result, resources = run_with_resources(_run)
    finally:
        proxy.close()
    evidence = chunk_recordings(proxy, task, stages)
    observed = _observed_summary(result)
    oracle_report = run_oracle(spec, task, result, evidence)
    if oracle_report is not None:
        observed["oracle_passed"] = bool(oracle_report.get("passed"))
    met, detail = check_expectation(spec, observed)
    arm: dict = {
        "arm_id": spec.arm_id, "kind": spec.kind, "workload": spec.workload,
        "fixture": spec.fixture, "fixture_sha256": fixture_sha256(spec.fixture),
        "backend": spec.backend, "backend_note": BACKEND_NOTES[spec.backend],
        "expected": spec.expected, "observed": observed,
        "expectation_met": met, "expectation_detail": detail,
        "seed": seed, "budgets": dict(budgets),
        "result": result.to_dict(), "evidence_stages": evidence,
        "resources": resources.to_dict(),
        "evidence_text_excerpt_chars": EVIDENCE_EXCERPT_CHARS,
    }
    if oracle_report is not None:
        arm["oracle"] = oracle_report
    if spec.fixture == "w4-contradiction":
        arm["synthetic_note"] = SYNTHETIC_LABEL
    return arm


def run_orders_arm(spec: ArmSpec, budgets: dict, seed: int) -> dict:
    """Execute one W2 arrival-order arm (paired observations, 3 orders)."""
    task, _ = load_task_and_stages(FIXTURE_DIR / f"{spec.fixture}.json")
    check_budgets(task, budgets)
    orders = order_variants(sorted(task.doc_ids))
    factory = BACKEND_FACTORIES[spec.backend]
    proxies: list[RecordingProxy] = []

    def _factory() -> RecordingProxy:
        proxy = RecordingProxy(factory())
        proxies.append(proxy)
        return proxy

    runs = run_order_experiment(task, _factory, orders)
    for proxy in proxies:
        proxy.close()
    order_arms = []
    for order_run, proxy in zip(runs, proxies):
        stages = insert_stages(task, orders[order_run.order])
        evidence = chunk_recordings(proxy, task, stages)
        order_arms.append({
            "order": order_run.order, "arrival": orders[order_run.order],
            "verdict": order_run.result.verdict,
            "coverage_delta": order_run.result.coverage_delta,
            "checks": {c.name: c.passed for c in order_run.result.checks},
            "result": order_run.result.to_dict(),
            "evidence_stages": evidence,
            "resources": order_run.resources.to_dict(),
        })
    deltas = {round(o["coverage_delta"], 9) for o in order_arms}
    paired: dict[str, dict[str, float]] = {}
    for order_run in runs:
        before = order_run.result.stages[0].per_query_recall
        after = order_run.result.stages[-1].per_query_recall
        for qid in before:
            paired.setdefault(qid, {})[order_run.order] = round(
                after[qid] - before[qid], 9)
    observed = {
        "verdict": order_arms[0]["verdict"] if order_arms else None,
        "verdicts": [o["verdict"] for o in order_arms],
        "deltas_equal": len(deltas) == 1,
        "coverage_deltas": [o["coverage_delta"] for o in order_arms],
    }
    met, detail = check_expectation(spec, observed)
    if len({o["verdict"] for o in order_arms}) != 1:
        met, detail = False, f"order verdicts differ: {observed['verdicts']}"
    return {
        "arm_id": spec.arm_id, "kind": spec.kind, "workload": spec.workload,
        "fixture": spec.fixture, "fixture_sha256": fixture_sha256(spec.fixture),
        "backend": spec.backend, "backend_note": BACKEND_NOTES[spec.backend],
        "expected": spec.expected, "observed": observed,
        "expectation_met": met, "expectation_detail": detail,
        "seed": seed, "budgets": dict(budgets),
        "orders": order_arms, "paired_per_query_delta": paired,
        "evidence_text_excerpt_chars": EVIDENCE_EXCERPT_CHARS,
    }


def run_shift_combined_arm(spec: ArmSpec, budgets: dict, seed: int) -> dict:
    """Execute the W3 topic-shift arm (pony population + theorems cohort)."""
    pony_task, _ = load_task_and_stages(FIXTURE_DIR / "w1-pony.json")
    topic_task, _ = load_task_and_stages(FIXTURE_DIR / "w3-topic.json")
    if not set(pony_task.doc_ids).isdisjoint(topic_task.doc_ids):
        raise ValueError("shift cohorts overlap; refusing a confounded arm")
    check_budgets(pony_task, budgets)
    check_budgets(topic_task, budgets)
    shift_task = make_shift_task(pony_task, list(topic_task.documents),
                                 "hv-pilot-w3-shift-combined-v1")
    by_id = {d["doc_id"]: d for d in shift_task.documents}
    before_ids = sorted(pony_task.doc_ids)
    after_ids = sorted(shift_task.doc_ids)
    stages = [
        Stage(descriptor=StageDescriptor(
            role="before", population_id=shift_task.population_id,
            frontier=dict(shift_task.frontier),
            expected_live_ids=tuple(before_ids)),
            operations=tuple(
                {"op": "insert", "params": {"doc_id": d, "text": by_id[d]["text"]}}
                for d in before_ids)),
        Stage(descriptor=StageDescriptor(
            role="after", population_id=shift_task.population_id,
            frontier=dict(shift_task.frontier),
            expected_live_ids=tuple(after_ids)),
            operations=tuple(
                [{"op": "insert", "params": {"doc_id": d, "text": by_id[d]["text"]}}
                 for d in sorted(topic_task.doc_ids)]
                + [{"op": "maintain", "params": {}}])),
    ]
    factory = BACKEND_FACTORIES[spec.backend]
    proxy = RecordingProxy(factory())

    def _run():
        return run_before_after(proxy, shift_task, stages)

    try:
        result, resources = run_with_resources(_run)
    finally:
        proxy.close()
    evidence = chunk_recordings(proxy, shift_task, stages)
    observed = _observed_summary(result)
    met, detail = check_expectation(spec, observed)
    return {
        "arm_id": spec.arm_id, "kind": spec.kind, "workload": spec.workload,
        "fixture": spec.fixture,
        "fixture_sha256": {
            "w1-pony": fixture_sha256("w1-pony"),
            "w3-topic": fixture_sha256("w3-topic")},
        "backend": spec.backend, "backend_note": BACKEND_NOTES[spec.backend],
        "expected": spec.expected, "observed": observed,
        "expectation_met": met, "expectation_detail": detail,
        "seed": seed, "budgets": dict(budgets),
        "result": result.to_dict(), "evidence_stages": evidence,
        "resources": resources.to_dict(),
        "evidence_text_excerpt_chars": EVIDENCE_EXCERPT_CHARS,
    }


def run_arm(spec: ArmSpec, budgets: dict | None = None,
            seed: int = DEFAULT_SEED) -> dict:
    """Execute one arm (job-unit granularity)."""
    budgets = {**DEFAULT_BUDGETS, **(budgets or {})}
    if spec.kind == "before_after":
        return run_before_after_arm(spec, budgets, seed)
    if spec.kind == "orders":
        return run_orders_arm(spec, budgets, seed)
    if spec.kind == "shift_combined":
        return run_shift_combined_arm(spec, budgets, seed)
    raise ValueError(f"unknown arm kind: {spec.kind!r}")


# -- oracles ---------------------------------------------------------------

def run_oracle(spec: ArmSpec, task: OrgTask, result: OrgEvalResult,
               evidence: list[dict]) -> dict | None:
    """W4 oracles (lifecycle stale-leak + contradiction spans); None elsewhere."""
    if spec.workload != "w4" or spec.backend in (
            "org_membership_liar", "org_stale_leak", "append_only"):
        return None
    if spec.fixture == "w4-lifecycle":
        return lifecycle_oracle_report(result)
    if spec.fixture == "w4-contradiction":
        return contradiction_oracle_report(task, result, evidence)
    return None


def lifecycle_oracle_report(result: OrgEvalResult) -> dict:
    prov = load_provenance("w4-lifecycle")
    oracle_cfg = prov.get("oracle", {})
    expected_live = {"before": oracle_cfg.get("expected_live_before", []),
                     "after": oracle_cfg.get("expected_live_after", [])}
    retired = {"before": [], "after": oracle_cfg.get("retired", [])}
    oracle = check_lifecycle_oracle(result, expected_live, retired)
    return {"oracle": "lifecycle", **oracle.to_dict()}


def verify_spans(task: OrgTask, provenance: dict) -> dict:
    """Verify recorded span identities against embedded fixture texts."""
    by_id = {d["doc_id"]: d["text"] for d in task.documents}
    verified: dict[str, list[dict]] = {}
    failures: list[str] = []
    for doc_id, spans in (provenance.get("spans") or {}).items():
        verified[doc_id] = []
        text = by_id.get(doc_id)
        if text is None:
            failures.append(f"span doc {doc_id} not in fixture population")
            continue
        for span in spans:
            start, end = span.get("start"), span.get("end")
            observed = text[start:end] if isinstance(start, int) and isinstance(end, int) else None
            ok = (observed == span.get("text") and
                  hashlib.sha256((observed or "").encode("utf-8")).hexdigest()
                  == span.get("sha256"))
            verified[doc_id].append({"text": span.get("text"), "start": start,
                                     "end": end,
                                     "sha256": span.get("sha256"),
                                     "verified": ok})
            if not ok:
                failures.append(f"span identity failed for {doc_id}@{start}:{end}")
    return {"verified": verified, "failures": failures,
            "passed": not failures}


def contradiction_oracle_report(task: OrgTask, result: OrgEvalResult,
                                evidence: list[dict]) -> dict:
    """Span-identity + stale-version oracle over the contradiction evidence."""
    provenance = load_provenance("w4-contradiction")
    span_check = verify_spans(task, provenance)
    oracle_cfg = provenance.get("oracle", {})
    probe = oracle_cfg.get("probe", "qc1")
    after = next((s for s in evidence if s["role"] == "after"), {"queries": []})
    probe_evidence = next((q for q in after["queries"]
                           if q["query_id"] == probe), {"hits": []})
    hits = probe_evidence["hits"]
    # Re-resolve full hit texts from the fixture population for span checks
    # (envelope evidence carries excerpts; the verdict uses full texts).
    by_id = {d["doc_id"]: d["text"] for d in task.documents}
    failures: list[str] = list(span_check["failures"])
    top = hits[0]["doc_id"] if hits else None
    if top != oracle_cfg.get("expected_top_hit_after"):
        failures.append(f"top hit {top!r} != "
                        f"{oracle_cfg.get('expected_top_hit_after')!r}")
    top_text = by_id.get(top, "") if top else ""
    for needle in oracle_cfg.get("must_contain_after", []):
        if needle not in top_text:
            failures.append(f"after-stage top hit lacks {needle!r}")
    for needle in oracle_cfg.get("must_not_contain_after", []):
        if needle in top_text:
            failures.append(f"after-stage top hit still carries {needle!r}")
    retired = set(oracle_cfg.get("retired", []))
    leaked = [h["doc_id"] for h in hits if h["doc_id"] in retired]
    if leaked:
        failures.append(f"retired versions returned after: {leaked}")
    honest = result.check("no_stale_leakage").passed and \
        result.check("preservation").passed
    if not honest:
        failures.append("evaluator integrity checks failed")
    return {"oracle": "contradiction",
            "probe": probe, "top_hit_after": top,
            "lineage": provenance.get("lineage", []),
            "span_identities": span_check["verified"],
            "failures": failures, "passed": not failures,
            "synthetic_note": SYNTHETIC_LABEL}


# -- workload assembly -----------------------------------------------------

def _workload_fixtures(plan: list[ArmSpec]) -> list[dict]:
    stems: list[str] = []
    for spec in plan:
        if spec.kind == "shift_combined":
            stems.extend(["w1-pony", "w3-topic"])
        elif spec.fixture not in stems:
            stems.append(spec.fixture)
    entries = []
    for stem in stems:
        prov_path = FIXTURE_DIR / f"{stem}-provenance.json"
        entries.append({
            "stem": stem, "sha256": fixture_sha256(stem),
            "provenance_sha256": hashlib.sha256(
                prov_path.read_bytes()).hexdigest() if prov_path.is_file() else None,
            "quarantine_matches": quarantine_matches(stem),
            "lkml_content_refs": lkml_content_refs(stem),
        })
    return entries


def run_workload(workload: str, backends: list[str] | None = None,
                 budgets: dict | None = None, seed: int = DEFAULT_SEED,
                 control: Control | None = None) -> dict:
    """Run a full workload matrix into a ``tb-workload-result-v1`` envelope."""
    budgets = {**DEFAULT_BUDGETS, **(budgets or {})}
    if control is None and budgets.get("deadline_s") is not None:
        control = Control(deadline_monotonic=time.monotonic() + float(budgets["deadline_s"]))
    plan = build_plan(workload, backends)
    fixture_entries = _workload_fixtures(plan)
    for entry in fixture_entries:
        if entry["quarantine_matches"]:
            raise ValueError(
                f"fixture {entry['stem']} references quarantined IDs "
                f"{entry['quarantine_matches']}; refusing.")
        if entry["lkml_content_refs"]:
            raise ValueError(
                f"fixture {entry['stem']} references LKML content "
                f"{entry['lkml_content_refs']}; refusing.")
    started = time.perf_counter()
    arms: list[dict] = []
    stopped: dict | None = None
    for spec in plan:
        if control is not None:
            try:
                control.check(spec.arm_id)
            except _Cancelled as exc:
                stopped = {"status": "cancelled", "note": str(exc)}
                break
            except _Deadline as exc:
                stopped = {"status": "incomplete", "note": str(exc)}
                break
        arms.append(run_arm(spec, budgets, seed))
    wall_s = time.perf_counter() - started
    met = [a["arm_id"] for a in arms if a["expectation_met"]]
    failed = [a["arm_id"] for a in arms if not a["expectation_met"]]
    total_ops: dict[str, int] = {}
    max_rss = 0.0
    for arm in arms:
        max_rss = max(max_rss, float((arm.get("resources") or {}).get("rss_mb", 0.0)))
        for stage in (arm.get("result") or {}).get("stages", []):
            for key, value in (stage.get("cost") or {}).items():
                total_ops[key] = total_ops.get(key, 0) + int(value or 0)
        for order in arm.get("orders", []):
            max_rss = max(max_rss, float((order.get("resources") or {}).get("rss_mb", 0.0)))
            for stage in (order.get("result") or {}).get("stages", []):
                for key, value in (stage.get("cost") or {}).items():
                    total_ops[key] = total_ops.get(key, 0) + int(value or 0)
    envelope = {
        "format": ENVELOPE_FORMAT,
        "workload": workload,
        "tb_version": tb_version(),
        "seed": seed,
        "budgets": budgets,
        "seed_note": "backends are deterministic; the seed is recorded for the envelope (arrival hash-shuffle uses SHA-256, not RNG).",
        "fixtures": fixture_entries,
        "arms": arms,
        "arms_met": met,
        "arms_failed": failed,
        "costs_total": {"wall_s": round(wall_s, 3), "max_rss_mb": round(max_rss, 3),
                        "arms_executed": len(arms), "arms_planned": len(plan),
                        "ops": total_ops},
        "notes": [
            PILOT_LABEL,
            "Faulty arms are expected invalid; unflagged faulty arms fail the workload.",
            "W3/W4 population-changing arms are incomparable by design (confounded, not utility).",
        ],
        "verdict": ("PASS" if not failed and stopped is None else
                    ("FAIL" if failed else stopped["status"].upper())),
    }
    if stopped is not None:
        envelope["stopped"] = stopped
        envelope["arms_pending"] = [s.arm_id for s in plan[len(arms):]]
    if workload == "w4":
        envelope["notes"].append(
            "w4-contradiction: " + SYNTHETIC_LABEL)
    return envelope


def save_envelope(envelope: dict, output_dir: str | Path) -> Path:
    """Write the envelope + per-arm files (refuses to overwrite)."""
    outdir = Path(output_dir)
    target = outdir / f"{envelope['workload']}-result.json"
    if target.exists():
        raise FileExistsError(f"workload result already exists: {target}")
    outdir.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(envelope, indent=2, sort_keys=True),
                      encoding="utf-8")
    arms_dir = outdir / "arms"
    arms_dir.mkdir(parents=True, exist_ok=True)
    for arm in envelope["arms"]:
        safe = arm["arm_id"].replace("/", "__")
        (arms_dir / f"{safe}.json").write_text(
            json.dumps(arm, indent=2, sort_keys=True), encoding="utf-8")
    return target
