"""Job directories for workload runs: history, cancel, deadline, resume, drift.

Mirrors the :mod:`trace_bench.jobs` contract (immutable spec digest, per-unit
attempt records that are never discarded, sticky cancel markers, resume
verification) for workload arms. Reuses :func:`trace_bench.jobs.atomic_write_json`
and the same ``cancel.requested`` marker semantics; ``job status``/``cancel``/
``clear-cancel`` in the CLI dispatch to either implementation by version.

Drift invalidated on resume: fixture digests, backend implementation
(class + defining-source sha), seed, budgets, and TB version. A drifted arm
is rebuilt; its old attempts are preserved.
"""

from __future__ import annotations

import hashlib
import inspect
import json
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from trace_bench.jobs import atomic_write_json
from trace_bench.workloads import ENVELOPE_FORMAT
from trace_bench.workloads.runner import (
    BACKEND_FACTORIES,
    DEFAULT_SEED,
    ArmSpec,
    Control,
    _Cancelled,
    _Deadline,
    build_plan,
    default_expectation,
    fixture_sha256,
    run_arm,
    tb_version,
)

JOB_VERSION = "tb-workload-job-v1"
TERMINAL = {"success", "failed", "cancelled", "unsupported", "incomplete"}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _backend_identity(name: str) -> dict:
    from trace_bench.datasets.loader import compute_sha256, file_sha256

    cls = BACKEND_FACTORIES[name]
    try:
        source = inspect.getsourcefile(cls)
    except (OSError, TypeError):
        source = None
    try:
        source_sha = file_sha256(source) if source else None
    except OSError:
        source_sha = None
    return {"name": name,
            "class": f"{cls.__module__}:{cls.__qualname__}",
            "source_sha256": source_sha,
            "config_sha256": compute_sha256("{}")}


def _spec_fingerprint(workload: str, arm_ids: list[str], backends: list[str] | None,
                      budgets: dict, seed: int) -> str:
    from trace_bench.datasets.loader import compute_sha256

    return compute_sha256(json.dumps(
        {"workload": workload, "arms": sorted(arm_ids),
         "backends": sorted(backends or []), "budgets": budgets, "seed": seed,
         "tb_version": tb_version()}, sort_keys=True))


def create_workload_job(workload: str, job_dir: str | Path,
                        backends: list[str] | None = None,
                        budgets: dict | None = None,
                        seed: int = DEFAULT_SEED) -> Path:
    """Create a workload job directory. Refuses to overwrite an existing job."""
    from trace_bench.workloads.runner import DEFAULT_BUDGETS

    directory = Path(job_dir)
    if (directory / "job.json").exists():
        raise FileExistsError(f"Job already exists: {directory}")
    plan = build_plan(workload, backends)
    merged_budgets = {**DEFAULT_BUDGETS, **(budgets or {})}
    arm_ids = [spec.arm_id for spec in plan]
    directory.mkdir(parents=True, exist_ok=True)
    atomic_write_json(directory / "job.json", {
        "version": JOB_VERSION,
        "job_id": directory.name,
        "workload": workload,
        "backends": backends,
        "budgets": merged_budgets,
        "seed": seed,
        "units": arm_ids,
        "spec_sha256": _spec_fingerprint(workload, arm_ids, backends,
                                         merged_budgets, seed),
        "created_utc": _utcnow(),
        "status": "pending",
    })
    return directory


def load_workload_job(job_dir: str | Path) -> dict:
    raw = json.loads((Path(job_dir) / "job.json").read_text(encoding="utf-8"))
    if raw.get("version") != JOB_VERSION:
        raise ValueError(f"Unsupported workload job version: {raw.get('version')}")
    return raw


def _attempts(unit_dir: Path) -> list[Path]:
    return sorted(unit_dir.glob("attempt_*.json")) if unit_dir.is_dir() else []


def _read_attempt(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"status": "incomplete", "note": "unreadable attempt record (preserved)"}


def _arm_spec_for(job: dict, unit_id: str) -> ArmSpec:
    plan = build_plan(job["workload"], job.get("backends"))
    for spec in plan:
        if spec.arm_id == unit_id:
            return spec
    raise ValueError(f"unit {unit_id!r} is not in this job's workload plan")


def verify_workload_unit(job_dir: Path, unit_id: str) -> tuple[bool, str]:
    """Check whether an arm's recorded success is still valid (drift-aware)."""
    unit_dir = job_dir / "units" / unit_id.replace("/", "__")
    result_path = unit_dir / "result.json"
    attempts = _attempts(unit_dir)
    if not attempts or not result_path.exists():
        return False, "no completed attempt"
    latest = _read_attempt(attempts[-1])
    if latest.get("status") != "success":
        return False, f"latest attempt is {latest.get('status')}"
    try:
        result_bytes = result_path.read_bytes()
        stored = json.loads(result_bytes.decode("utf-8"))
    except (OSError, ValueError):
        return False, "result.json is unreadable"
    if hashlib.sha256(result_bytes).hexdigest() != latest.get("result_sha256"):
        return False, "result.json payload changed since the recorded attempt"
    job = load_workload_job(job_dir)
    if _spec_fingerprint(job["workload"], job["units"], job.get("backends"),
                         job["budgets"], job["seed"]) != job["spec_sha256"]:
        return False, "job spec definition does not match its recorded digest"
    spec = _arm_spec_for(job, unit_id)
    if stored.get("fixture_sha256") != latest.get("fixture_sha256"):
        return False, "recorded fixture digest disagrees with the arm payload"
    current_fixture = fixture_sha256(spec.fixture) if spec.kind == "before_after" or \
        spec.kind == "orders" else {"w1-pony": fixture_sha256("w1-pony"),
                                    "w3-topic": fixture_sha256("w3-topic")}
    if latest.get("fixture_sha256") != current_fixture:
        return False, "fixture changed since the recorded attempt"
    try:
        current_backend = _backend_identity(spec.backend)
    except Exception as exc:
        return False, f"backend unavailable for identity check: {exc}"
    if latest.get("backend_identity") != current_backend:
        return False, "backend implementation changed since the recorded attempt"
    if latest.get("seed") != job["seed"] or \
            latest.get("budgets") != job["budgets"] or \
            latest.get("tb_version") != tb_version():
        return False, "seed/budgets/TB version changed since the recorded attempt"
    return True, "verified"


def workload_job_status(job_dir: str | Path) -> dict[str, Any]:
    """Summarize a workload job without executing anything."""
    directory = Path(job_dir)
    job = load_workload_job(directory)
    units: dict[str, str] = {}
    for unit_id in job["units"]:
        ok, reason = verify_workload_unit(directory, unit_id)
        if ok:
            units[unit_id] = "success"
            continue
        attempts = _attempts(directory / "units" / unit_id.replace("/", "__"))
        if not attempts:
            units[unit_id] = "pending"
            continue
        latest = _read_attempt(attempts[-1])
        status = latest.get("status", "incomplete")
        if status == "running":
            units[unit_id] = "incomplete"
        elif status == "success":
            units[unit_id] = f"incomplete (recorded success no longer verifies: {reason})"
        else:
            units[unit_id] = status if status in TERMINAL else "incomplete"
    return {"job_id": job["job_id"], "workload": job["workload"],
            "spec_sha256": job["spec_sha256"], "units": units,
            "cancel_requested": (directory / "cancel.requested").exists()}


def _execute_arm(job_dir: Path, spec: ArmSpec, job: dict,
                 cancel_event: threading.Event,
                 deadline_remaining: float | None) -> dict:
    unit_dir = job_dir / "units" / spec.arm_id.replace("/", "__")
    attempt_no = len(_attempts(unit_dir)) + 1
    attempt_path = unit_dir / f"attempt_{attempt_no:03d}.json"
    record: dict[str, Any] = {"attempt": attempt_no, "unit_id": spec.arm_id,
                              "status": "running", "started_utc": _utcnow()}
    atomic_write_json(attempt_path, record)
    started = time.monotonic()
    try:
        if (job_dir / "cancel.requested").exists() or cancel_event.is_set():
            raise _Cancelled("cancel requested")
        if deadline_remaining is not None and deadline_remaining <= 0:
            raise _Deadline("job deadline exceeded")
        arm = run_arm(spec, job["budgets"], job["seed"])
        atomic_write_json(unit_dir / "result.json", arm)
        result_digest = hashlib.sha256(
            (unit_dir / "result.json").read_bytes()).hexdigest()
        record.update(
            status="success" if arm["expectation_met"] else "failed",
            status_detail=arm["expectation_detail"],
            finished_utc=_utcnow(),
            elapsed_s=round(time.monotonic() - started, 3),
            result_sha256=result_digest,
            fixture_sha256=arm["fixture_sha256"],
            backend_identity=_backend_identity(spec.backend),
            seed=job["seed"], budgets=job["budgets"],
            tb_version=tb_version())
    except _Cancelled as exc:
        record.update(status="cancelled", finished_utc=_utcnow(),
                      elapsed_s=round(time.monotonic() - started, 3),
                      note=str(exc))
    except _Deadline as exc:
        record.update(status="incomplete", finished_utc=_utcnow(),
                      elapsed_s=round(time.monotonic() - started, 3),
                      note=str(exc))
    except Exception as exc:
        record.update(status="failed", finished_utc=_utcnow(),
                      elapsed_s=round(time.monotonic() - started, 3),
                      error=f"{type(exc).__name__}: {exc}")
    atomic_write_json(attempt_path, record)
    return record


def run_workload_job(job_dir: str | Path, output_dir: str | Path,
                     resume: bool = True) -> dict[str, Any]:
    """Execute unfinished arms, then assemble the envelope from unit results."""
    from trace_bench.workloads.runner import run_workload as _unused  # noqa: F401 (re-export guard)

    directory = Path(job_dir)
    job = load_workload_job(directory)
    if _spec_fingerprint(job["workload"], job["units"], job.get("backends"),
                         job["budgets"], job["seed"]) != job["spec_sha256"]:
        raise ValueError("job spec definition does not match its recorded digest; "
                         "create a new job for the revised spec.")
    deadline = (job["budgets"] or {}).get("deadline_s")
    job_started = time.monotonic()
    cancel_event = threading.Event()
    summary: dict[str, Any] = {"job_id": job["job_id"], "units": {}}
    for unit_id in job["units"]:
        if (directory / "cancel.requested").exists() or cancel_event.is_set():
            summary["units"][unit_id] = "cancelled"
            continue
        if deadline is not None and (time.monotonic() - job_started) >= deadline:
            summary["units"][unit_id] = "incomplete (job deadline exceeded)"
            continue
        if resume:
            ok, _reason = verify_workload_unit(directory, unit_id)
            if ok:
                summary["units"][unit_id] = "success (resumed, verified)"
                continue
        remaining = (deadline - (time.monotonic() - job_started)
                     if deadline is not None else None)
        record = _execute_arm(directory, _arm_spec_for(job, unit_id), job,
                              cancel_event, remaining)
        summary["units"][unit_id] = record["status"]
    final = workload_job_status(directory)
    job["status"] = ("success" if set(final["units"].values()) == {"success"}
                     else "incomplete")
    atomic_write_json(directory / "job.json", job)
    envelope = assemble_envelope(directory, Path(output_dir))
    summary["job_status"] = job["status"]
    summary["envelope"] = str(envelope) if envelope else None
    return summary


def assemble_envelope(job_dir: str | Path,
                      output_dir: str | Path) -> Path | None:
    """Assemble the workload envelope from verified unit results (or None)."""
    from trace_bench.workloads.runner import _workload_fixtures

    directory = Path(job_dir)
    job = load_workload_job(directory)
    plan = build_plan(job["workload"], job.get("backends"))
    arms: list[dict] = []
    for spec in plan:
        ok, _reason = verify_workload_unit(directory, spec.arm_id)
        if not ok:
            return None
        payload = json.loads((directory / "units" / spec.arm_id.replace("/", "__")
                              / "result.json").read_text(encoding="utf-8"))
        arms.append(payload)
    met = [a["arm_id"] for a in arms if a["expectation_met"]]
    failed = [a["arm_id"] for a in arms if not a["expectation_met"]]
    total_ops: dict[str, int] = {}
    max_rss = 0.0
    for arm in arms:
        max_rss = max(max_rss, float((arm.get("resources") or {}).get("rss_mb", 0.0)))
        for stage in (arm.get("result") or {}).get("stages", []):
            for key, value in (stage.get("cost") or {}).items():
                total_ops[key] = total_ops.get(key, 0) + int(value or 0)
        for order in arm.get("orders", []):
            max_rss = max(max_rss, float((order.get("resources") or {}).get("rss_mb", 0.0)))
            for stage in (order.get("result") or {}).get("stages", []):
                for key, value in (stage.get("cost") or {}).items():
                    total_ops[key] = total_ops.get(key, 0) + int(value or 0)
    envelope = {
        "format": ENVELOPE_FORMAT,
        "workload": job["workload"],
        "tb_version": tb_version(),
        "seed": job["seed"],
        "budgets": job["budgets"],
        "seed_note": "backends are deterministic; the seed is recorded for the envelope.",
        "fixtures": _workload_fixtures(plan),
        "arms": arms,
        "arms_met": met,
        "arms_failed": failed,
        "costs_total": {"max_rss_mb": round(max_rss, 3),
                        "arms_executed": len(arms),
                        "arms_planned": len(plan),
                        "ops": total_ops},
        "notes": ["assembled from verified job unit results; see job dir for attempt history."],
        "verdict": "PASS" if not failed else "FAIL",
        "job": {"job_id": job["job_id"], "spec_sha256": job["spec_sha256"]},
    }
    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    target = outdir / f"{job['workload']}-result.json"
    if target.exists():
        raise FileExistsError(f"workload result already exists: {target}")
    target.write_text(json.dumps(envelope, indent=2, sort_keys=True),
                      encoding="utf-8")
    return target
