"""Bounded-memory two-pass BM25 over streamed corpora (TB-owned baseline).

Same scoring contract as :class:`trace_bench.baselines.bm25_retriever.BM25Retriever`
(same tokenizer, same Okapi constants, same smoothed IDF, same per-occurrence
term addition, same corpus-input-order tie break), but the corpus is never
materialized: pass 1 streams documents once for collection statistics, pass 2
streams them again scoring queries into per-query top-k heaps.

Memory is ``O(distinct query terms + queries * (top_k + exclusions))`` plus
one document of text, never ``O(corpus bytes)``. Text buffering per document
is the caller's ``max_doc_bytes`` ceiling. ``TOK-v1`` denominators are the
caller's job (see :mod:`trace_bench.workloads.hv`); this module reports only
its own BM25-token scoring statistics.

Floating-point note: per-document term gains are summed in document-term
order (one heap interaction per document per query), while the NumPy
implementation sums in query-token order. Scores agree to ~1e-12 relative;
rank order agrees unless two documents tie within that epsilon, in which
case both implementations break ties by corpus input order.
"""

from __future__ import annotations

import heapq
import inspect
import json
import math
from collections import Counter
from dataclasses import dataclass, field
from typing import Callable, Iterable

from trace_bench.baselines.bm25_retriever import tokenize

ENGINE_NAME = "streaming_bm25"
FORMULA = "okapi-bm25/tb-numpy-parity-v1"


@dataclass
class PlannedQuery:
    """One query with tokenization fixed before the collection passes."""

    query_id: str
    text: str
    tokens: list[str] = field(default_factory=list)


@dataclass
class StreamingStats:
    """Collection statistics observed during the two passes."""

    docs_seen: int = 0
    bm25_tokens_seen: int = 0
    avg_doc_len: float = 0.0
    passes: int = 0

    def to_dict(self) -> dict:
        return {
            "docs_seen": self.docs_seen,
            "bm25_tokens_seen": self.bm25_tokens_seen,
            "avg_doc_len": self.avg_doc_len,
            "passes": self.passes,
        }


def plan_queries(queries: Iterable[tuple[str, str]]) -> list[PlannedQuery]:
    """Tokenize queries once; empty-token queries stay in the denominator."""
    planned = [PlannedQuery(query_id=qid, text=text, tokens=tokenize(text))
               for qid, text in queries]
    if len({q.query_id for q in planned}) != len(planned):
        raise ValueError("duplicate query IDs in streaming plan")
    if not planned:
        raise ValueError("streaming plan needs at least one query")
    return planned


class StreamingBM25:
    """Two-pass BM25 scorer with per-query top-k heaps."""

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        if not k1 > 0 or not 0.0 <= b <= 1.0:
            raise ValueError(f"invalid BM25 constants k1={k1} b={b}")
        self.k1 = k1
        self.b = b

    # -- identity (mirrors the BaseRetriever contract; TB-owned, no target) --
    def name(self) -> str:
        return ENGINE_NAME

    def configuration(self) -> dict:
        return {"k1": self.k1, "b": self.b, "tokenizer": "ascii_word_lower",
                "implementation": "trace_bench_streaming_bm25",
                "formula": FORMULA, "score_dtype": "float64",
                "tie_break": "corpus_input_order", "passes": 2}

    def implementation_identity(self) -> dict:
        from trace_bench.datasets.loader import compute_sha256, file_sha256

        source = inspect.getsourcefile(type(self))
        config = self.configuration()
        return {"class": f"{type(self).__module__}:{type(self).__name__}",
                "source_sha256": file_sha256(source) if source else None,
                "configuration_sha256": compute_sha256(
                    json.dumps(config, sort_keys=True)),
                "formula": FORMULA}

    def native_pins(self) -> dict:
        return {}

    # -- scoring ------------------------------------------------------
    def score(
        self,
        planned: list[PlannedQuery],
        doc_iter_factory: Callable[[], Iterable[tuple[str, str, str]]],
        top_k: int,
        excluded: dict[str, set[str]] | None = None,
    ) -> tuple[dict[str, list[tuple[str, float]]], StreamingStats]:
        """Score every planned query over two streaming passes.

        ``doc_iter_factory`` must return a FRESH document iterator
        ``(doc_id, title, text)`` on each call, in the same input order.
        ``excluded`` maps query IDs to doc IDs filtered before the top-k
        cut (over-fetch mirrors ``execute_single_case``).
        """
        if top_k < 1:
            raise ValueError("top_k must be >= 1")
        if not planned:
            raise ValueError("streaming plan needs at least one query")
        excluded = excluded or {}
        wanted_terms: set[str] = set()
        for query in planned:
            wanted_terms.update(query.tokens)

        # Pass 1: N, total length, and df restricted to query terms.
        num_docs = 0
        total_len = 0
        doc_freqs: Counter[str] = Counter()
        for _doc_id, title, text in doc_iter_factory():
            tokens = tokenize(text + " " + title)
            num_docs += 1
            total_len += len(tokens)
            for term in set(tokens) & wanted_terms:
                doc_freqs[term] += 1
        avgdl = total_len / num_docs if num_docs else 0.0
        idf = {term: math.log(1.0 + (num_docs - df + 0.5) / (df + 0.5))
               for term, df in doc_freqs.items()}
        stats = StreamingStats(docs_seen=num_docs,
                               bm25_tokens_seen=total_len,
                               avg_doc_len=avgdl, passes=1)
        if num_docs == 0:
            return {q.query_id: [] for q in planned}, stats

        # Pass 2: one batched heap interaction per (document, query).
        capacities = {q.query_id: top_k + len(excluded.get(q.query_id, ()))
                      for q in planned}
        heaps: dict[str, list] = {q.query_id: [] for q in planned}
        repeats: dict[str, Counter[str]] = {
            q.query_id: Counter(q.tokens) for q in planned}
        term_queries: dict[str, list[str]] = {}
        for query in planned:
            for term in repeats[query.query_id]:
                term_queries.setdefault(term, []).append(query.query_id)
        k1, b = self.k1, self.b
        ordinal = 0
        for doc_id, title, text in doc_iter_factory():
            counts = Counter(tokenize(text + " " + title))
            doc_len = sum(counts.values())
            norm = k1 * (1.0 - b + b * (
                doc_len / avgdl if avgdl > 0 else 1.0))
            gains: dict[str, float] = {}
            for term, tf in counts.items():
                term_idf = idf.get(term)
                if term_idf is None:
                    continue
                base = term_idf * ((tf * (k1 + 1.0)) / (tf + norm))
                for qid in term_queries[term]:
                    increment = 0.0
                    for _ in range(repeats[qid][term]):
                        increment += base
                    gains[qid] = gains.get(qid, 0.0) + increment
            for qid, total in gains.items():
                if total <= 0:
                    continue
                entry = (total, -ordinal, doc_id)
                heap = heaps[qid]
                if len(heap) < capacities[qid]:
                    heapq.heappush(heap, entry)
                elif entry > heap[0]:
                    heapq.heapreplace(heap, entry)
            ordinal += 1
        stats.passes = 2

        results: dict[str, list[tuple[str, float]]] = {}
        for query in planned:
            skip = excluded.get(query.query_id, set())
            ranked = sorted(heaps[query.query_id],
                            key=lambda e: (-e[0], -e[1]))
            kept = [(doc_id, score) for score, _neg, doc_id in ranked
                    if doc_id not in skip][:top_k]
            results[query.query_id] = kept
        return results, stats
