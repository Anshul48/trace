"""HV profile route: package -> task/gold/exclusions -> backend -> artifacts.

Installed wiring for the HV100M gold maps (M1-M4) without hand-joined JSONL:

- :func:`list_tasks` -- profile -> tasks with gold-resolution classes,
  query-source mapping, and live readiness (offline, never downloads).
- :func:`preflight` -- bounded-memory/resource checks before any indexing.
- :func:`run_hv_retrieval` -- task gold resolution + exclusion handling +
  bounded-memory streaming BM25 -> scored envelope + ``run.json``
  (comparison/capsule/viewer compatible).
- :func:`refuse_pin_mismatch` -- comparison refusal for incompatible
  population/protocol/pin mixes (called from ``compare``, viewer, capsule).

Inputs are explicit: a package directory (tier manifest + shards + maps) or
the ``bundled:demo`` micro-package keyword, plus a query source (prepared
snapshot name/path, ``bundled:demo``, or a query JSONL path). There are no
``/tmp`` defaults and no implicit corpus. Missing opt-in inputs fail closed
with the exact acquisition command.

Custom-diagnostic boundaries (kept in every artifact): HV retrieval is a
custom diagnostic, never official-comparable; missing/native-pool-only gold
is shown explicitly; unjudged hits stay unjudged (counted, never scored);
withheld rows are encountered but never indexed.
"""

from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from trace_bench.datasets.loader import (
    compute_sha256,
    file_sha256,
)
from trace_bench.datasets.sharded import (
    DEFAULT_MAX_DOC_BYTES,
    DuplicateDocIdError,
    MalformedDocError,
    OversizedDocError,
    TierManifest,
    counted_text,
    load_tier_manifest,
    text_sha256,
    tok_v1_count,
    verify_tier,
)
from trace_bench.workloads import FIXTURE_DIR
from trace_bench.workloads.runner import load_quarantine_ids
from trace_bench.workloads.streaming_bm25 import (
    StreamingBM25,
    plan_queries,
)

BUNDLED_DEMO = "bundled:demo"
COHORT_FULL = "full"
M4_CLASSES = ("resolves_in_hv", "native_pool_only", "native_pool_missing", "missing")
ENGINE = "streaming_bm25"


# -- package ----------------------------------------------------------------

def resolve_package(package: str | Path) -> Path:
    """Resolve an explicit package selector (no defaults, no /tmp)."""
    if str(package) == BUNDLED_DEMO:
        return FIXTURE_DIR / "hv-micro"
    path = Path(package).expanduser()
    if not path.is_dir():
        raise FileNotFoundError(
            f"HV package directory not found: {path}. Pass --package-dir explicitly "
            f"(opt-in), or {BUNDLED_DEMO} for the wheel-bundled route demo.")
    return path


def load_package(package: str | Path) -> tuple[Path, TierManifest, dict]:
    """Load tier manifest + maps manifest (fail closed on any gap)."""
    root = resolve_package(package)
    tier_path = root / "tb-tier-manifest.json"
    if not tier_path.is_file():
        raise FileNotFoundError(f"package has no tb-tier-manifest.json: {root}")
    manifest = load_tier_manifest(tier_path)
    maps_manifest_path = root / "maps" / "MANIFEST.json"
    if not maps_manifest_path.is_file():
        raise FileNotFoundError(f"package has no maps/MANIFEST.json: {root}")
    maps_manifest = json.loads(maps_manifest_path.read_text(encoding="utf-8"))
    return root, manifest, maps_manifest


def m4_task_ids(root: Path) -> list[str]:
    return sorted(p.stem for p in (root / "maps" / "m4").glob("*.json"))


def load_m4(root: Path, task: str) -> dict:
    path = root / "maps" / "m4" / f"{task}.json"
    if not path.is_file():
        raise FileNotFoundError(
            f"unknown HV task {task!r} in this package (available: "
            f"{', '.join(m4_task_ids(root)) or 'none'}).")
    doc = json.loads(path.read_text(encoding="utf-8"))
    for cls in M4_CLASSES:
        if cls not in doc or not isinstance(doc[cls], list):
            raise ValueError(f"M4 task {task}: class {cls!r} missing or not a list")
    return doc


def m4_digest(root: Path, task: str) -> str:
    return file_sha256(root / "maps" / "m4" / f"{task}.json")


# -- tasks -------------------------------------------------------------------

def native_query_source(task: str) -> tuple[str | None, str]:
    """Map an M4 task to its native query source (name + split).

    Returns (None, reason) when no prepared-snapshot path exists and the
    caller must pass --query-source explicitly.
    """
    if task.startswith("beir-") and task.endswith("-test"):
        return f"{task[len('beir-'):-len('-test')]}", "test"
    if task.startswith("bright-"):
        return task, "test"
    if task.startswith("brightnew-"):
        return f"bright-{task[len('brightnew-'):]}", "test"
    if task == "demo-pony":
        return BUNDLED_DEMO, "fixture"
    if task in ("multihop-all", "musique-all"):
        return None, ("no prepared-snapshot path; import a normalized set first "
                      "(`trace-bench datasets import --source DIR --split SPLIT "
                      "--output-dir OUT`) and pass it as --query-source.")
    return None, f"no known native query source for task {task!r}"


def query_source_readiness(native: str | None, data_dir=None) -> str:
    if native == BUNDLED_DEMO:
        return "ready (bundled)"
    if native is None:
        return "explicit --query-source required"
    try:
        from trace_bench.datasets.portable import resolve_dataset

        resolve_dataset(native, data_dir)
        return "ready"
    except FileNotFoundError:
        return f"run setup: trace-bench setup --dataset {native}"


def list_tasks(package: str | Path, data_dir=None) -> list[dict]:
    """Task inventory with gold classes + query-source readiness (offline)."""
    root, manifest, _maps = load_package(package)
    entries = []
    for task in m4_task_ids(root):
        m4 = load_m4(root, task)
        queries: set[str] = set()
        for cls in M4_CLASSES:
            for link in m4[cls]:
                queries.add(str(link.get("query_native_id")))
        native, split_or_reason = native_query_source(task)
        entries.append({
            "task": task,
            "m4_sha256": m4_digest(root, task),
            "queries": len(queries),
            "gold_links": {cls: len(m4[cls]) for cls in M4_CLASSES},
            "native_query_source": native,
            "split_or_reason": split_or_reason,
            "readiness": query_source_readiness(native, data_dir),
        })
    return entries


# -- cohorts ------------------------------------------------------------------

def parse_cohort(spec: str, manifest: TierManifest) -> dict:
    """Parse + validate a cohort selector (fail closed on unknown shards)."""
    if spec == COHORT_FULL:
        return {"cohort": COHORT_FULL, "shards": [s.shard_id for s in manifest.shards],
                "stratum": None, "max_docs": None}
    if spec.startswith("shard:"):
        want = spec[len("shard:"):]
        ids = [s.shard_id for s in manifest.shards]
        if want not in ids:
            raise ValueError(f"unknown shard {want!r} (manifest shards: {ids})")
        return {"cohort": spec, "shards": [want], "stratum": None, "max_docs": None}
    if spec.startswith("stratum:"):
        return {"cohort": spec, "shards": [s.shard_id for s in manifest.shards],
                "stratum": spec[len("stratum:"):], "max_docs": None}
    if spec.startswith("max-docs:"):
        try:
            limit = int(spec[len("max-docs:"):])
        except ValueError:
            raise ValueError(f"invalid cohort {spec!r} (expected max-docs:N)") from None
        if limit < 1:
            raise ValueError(f"invalid cohort {spec!r} (N must be >= 1)")
        return {"cohort": spec, "shards": [s.shard_id for s in manifest.shards],
                "stratum": None, "max_docs": limit}
    raise ValueError(
        f"invalid cohort {spec!r} (expected 'full', 'shard:ID', 'stratum:NAME', or 'max-docs:N')")


# -- streaming row reader (extra tbdoc fields beyond sharded.Doc) -------------

def iter_cohort_rows(root: Path, manifest: TierManifest, cohort: dict,
                     max_doc_bytes: int | None = None,
                     ) -> Iterator[tuple[dict, str, str, str]]:
    """Yield ``(row, shard_id, counted_text, row_text_sha256)`` in tier order.

    The tier MUST be verified first (see :func:`verify_tier`); this reader
    additionally re-checks each shard's file sha while streaming so bytes
    cannot change between verification and scoring. Withheld rows yield
    with ``row["withheld"]`` and no text. Blank lines are skipped.
    """
    ceiling = max_doc_bytes or DEFAULT_MAX_DOC_BYTES
    by_id = {s.shard_id: s for s in manifest.shards}
    admitted = 0
    for shard_id in cohort["shards"]:
        spec = by_id[shard_id]
        path = Path(spec.path)
        shard_path = path if path.is_absolute() else root / path
        file_digest = hashlib.sha256()
        with shard_path.open("rb") as handle:
            for lineno, raw in enumerate(handle, 1):
                file_digest.update(raw)
                line = raw.rstrip(b"\r\n")
                if len(line) > ceiling and line.strip():
                    raise OversizedDocError(
                        f"{shard_path.name} line {lineno}: {len(line)} bytes exceeds "
                        f"max_doc_bytes={ceiling}; refusing (no truncation).")
                if not line.strip():
                    continue
                try:
                    row = json.loads(line.strip().decode("utf-8"))
                except (UnicodeDecodeError, ValueError) as exc:
                    raise MalformedDocError(
                        f"{shard_path.name} line {lineno}: bad JSON: {exc}") from exc
                if not isinstance(row, dict) or not row.get("tbdoc_id"):
                    raise MalformedDocError(
                        f"{shard_path.name} line {lineno}: missing 'tbdoc_id'.")
                if cohort.get("stratum") is not None and \
                        row.get("stratum") != cohort["stratum"]:
                    continue
                if cohort.get("max_docs") is not None and admitted >= cohort["max_docs"]:
                    # Capped: keep hashing to EOF so the file sha still
                    # verifies; later shards are skipped after this file.
                    continue
                admitted += 1
                if row.get("withheld") is True:
                    yield row, shard_id, "", ""
                else:
                    text = row.get("text", "")
                    title = row.get("title", "")
                    if not isinstance(text, str) or not isinstance(title, str):
                        raise MalformedDocError(
                            f"{shard_path.name} line {lineno}: text/title must be strings.")
                    counted = counted_text(title, text)
                    yield row, shard_id, counted, text_sha256(counted)
        if file_digest.hexdigest() != spec.sha256:
            raise ValueError(
                f"shard {shard_id} changed between verification and scoring "
                f"(file sha mismatch); refusing.")
        if cohort.get("max_docs") is not None and admitted >= cohort["max_docs"]:
            break


# -- queries -------------------------------------------------------------------

def load_queries(query_source: str | Path, package_root: Path,
                 data_dir=None) -> tuple[list[dict], dict]:
    """Load query texts + native exclusions.

    Returns (queries, source_identity). ``queries`` entries hold
    ``native_query_id`` (str), ``text``, ``excluded_native_ids`` (list).
    """
    if str(query_source) == BUNDLED_DEMO:
        path = package_root / "queries.jsonl"
        if not path.is_file():
            raise FileNotFoundError(
                f"bundled demo queries absent from package: {package_root}")
        queries = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                row = json.loads(line)
                queries.append({"native_query_id": str(row["native_query_id"]),
                                "text": row["text"],
                                "excluded_native_ids": [str(i) for i in
                                                        row.get("excluded_ids", [])]})
        if not queries:
            raise ValueError("bundled demo query file is empty")
        return queries, {"kind": BUNDLED_DEMO,
                         "sha256": file_sha256(path),
                         "queries": len(queries)}
    maybe_path = Path(str(query_source))
    if maybe_path.suffix == ".jsonl" and maybe_path.is_file():
        queries = []
        for line in maybe_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                row = json.loads(line)
                queries.append({"native_query_id": str(row["native_query_id"]),
                                "text": row["text"],
                                "excluded_native_ids": [str(i) for i in
                                                        row.get("excluded_ids", [])]})
        if not queries:
            raise ValueError(f"query file is empty: {maybe_path}")
        return queries, {"kind": "jsonl",
                         "sha256": file_sha256(maybe_path),
                         "queries": len(queries)}
    from trace_bench.datasets.portable import load_dataset

    manifest, docs = load_dataset(str(query_source), data_dir, "test")
    internal_to_native = {d.doc_id: str(d.metadata.get("native_doc_id", d.doc_id))
                          for d in docs}
    queries = [{"native_query_id": str(c.native_query_id or c.id),
                "text": c.query,
                "excluded_native_ids": [internal_to_native.get(i, i)
                                        for i in c.excluded_doc_ids]}
               for c in manifest.cases]
    if not queries:
        raise ValueError(f"query source has no cases: {query_source}")
    return queries, {"kind": "prepared-snapshot", "name": str(query_source),
                     "split": "test",
                     "cases_sha256": compute_sha256(json.dumps(
                         [c.model_dump() for c in manifest.cases],
                         sort_keys=True, ensure_ascii=False,
                         separators=(",", ":"))),
                     "queries": len(queries)}


# -- preflight ------------------------------------------------------------------

def preflight(package: str | Path, task: str, cohort_spec: str,
              query_source: str | Path | None = None, top_k: int = 10,
              data_dir=None, memory_mb: float | None = None) -> list[str]:
    """Check package/tasks/queries/resources before any indexing (offline)."""
    findings: list[str] = []
    try:
        root, manifest, _maps = load_package(package)
    except (FileNotFoundError, ValueError) as exc:
        return [f"error: {exc}"]
    findings.append(f"ok: tier manifest profile={manifest.profile} "
                    f"shards={len(manifest.shards)}")
    try:
        cohort = parse_cohort(cohort_spec, manifest)
    except ValueError as exc:
        return findings + [f"error: {exc}"]
    if task not in m4_task_ids(root):
        return findings + [f"error: unknown HV task {task!r} in this package "
                           f"(see: workload hv-tasks --package-dir DIR)"]
    findings.append(f"ok: task {task} m4_sha256={m4_digest(root, task)[:16]}...")
    if query_source is None:
        native, _ = native_query_source(task)
        query_source = native or ""
    if not query_source:
        _native, reason = native_query_source(task)
        return findings + [f"error: {reason}"]
    try:
        queries, identity = load_queries(query_source, root, data_dir)
    except (FileNotFoundError, ValueError) as exc:
        return findings + [f"error: query source failed: {exc}"]
    findings.append(f"ok: query source {identity['kind']} queries={identity['queries']}")
    shard_docs = sum(s.docs for s in manifest.shards if s.shard_id in cohort["shards"])
    shard_tok = sum(s.tok_v1 for s in manifest.shards if s.shard_id in cohort["shards"])
    if cohort.get("max_docs") is not None:
        shard_docs = min(shard_docs, cohort["max_docs"])
    findings.append(f"ok: cohort {cohort_spec} upper bound docs<={shard_docs:,} "
                    f"tok_v1<={shard_tok:,} (exact denominators recorded at run time)")
    if top_k < 1:
        findings.append("error: top_k must be >= 1")
    # Memory model (documented estimate, verified against available RAM):
    # admitted-id set + df over query terms + per-query heaps + native index.
    estimate_mb = (shard_docs * 120) / (1024 * 1024) + 512.0
    try:
        import psutil

        available_mb = psutil.virtual_memory().available / (1024 * 1024)
        findings.append(f"ok: estimated peak ~{estimate_mb:,.0f} MB; "
                        f"available {available_mb:,.0f} MB")
        if memory_mb is not None and estimate_mb > memory_mb:
            findings.append(f"error: estimate {estimate_mb:,.0f} MB exceeds budget "
                            f"--memory-mb {memory_mb}; narrow the cohort.")
        elif available_mb < estimate_mb:
            findings.append(f"error: available RAM {available_mb:,.0f} MB below estimate "
                            f"{estimate_mb:,.0f} MB; narrow the cohort or free memory.")
    except ImportError:
        findings.append("warn: psutil unavailable; RAM check skipped "
                        f"(estimate ~{estimate_mb:,.0f} MB)")
    if len(queries) > 100000:
        findings.append(f"warn: {len(queries):,} queries; scoring will be slow")
    return findings


# -- retrieval ------------------------------------------------------------------

def _doc_fingerprint_line(doc_id: str, title: str, text: str, metadata: dict) -> bytes:
    # tb-doc-id-v2 line construction, mirroring document_fingerprint exactly.
    return (json.dumps([doc_id, title, text, metadata or {}],
                       ensure_ascii=False, sort_keys=True, default=str,
                       separators=(",", ":")).encode("utf-8") + b"\n")


def run_hv_retrieval(package: str | Path, task: str, cohort_spec: str,
                     output_dir: str | Path,
                     query_source: str | Path | None = None,
                     top_k: int = 10, data_dir=None,
                     memory_mb: float | None = None,
                     max_doc_bytes: int | None = None) -> dict:
    """Run the opt-in HV retrieval journey (fail closed on any preflight error).

    Writes ``hv-<task>-<cohort>-result.json`` (native envelope) and
    ``run.json`` (BenchmarkRunResult for compare/capsule/viewer) into a NEW
    output directory. Returns the envelope.
    """
    outdir = Path(output_dir)
    if outdir.exists():
        raise FileExistsError(f"output directory already exists: {outdir}")
    problems = preflight(package, task, cohort_spec, query_source, top_k,
                         data_dir, memory_mb)
    errors = [p for p in problems if p.startswith("error:")]
    if errors:
        raise ValueError("HV preflight refused: " + "; ".join(errors))
    root, manifest, _maps = load_package(package)
    cohort = parse_cohort(cohort_spec, manifest)
    m4 = load_m4(root, task)
    if query_source is None:
        native, _ = native_query_source(task)
        query_source = native
    queries, query_identity = load_queries(query_source, root, data_dir)
    quarantined = load_quarantine_ids()

    started_all = time.perf_counter()
    # Integrity first: full tier verification (streaming, bounded memory).
    verify_started = time.perf_counter()
    tier_census = verify_tier(manifest, base_dir=root)
    verify_s = time.perf_counter() - verify_started

    # M4 gold classes per query (native keys; tbdoc resolution below).
    gold: dict[str, dict[str, list]] = {}
    for cls in M4_CLASSES:
        for link in m4[cls]:
            qid = str(link.get("query_native_id"))
            gold.setdefault(qid, {c: [] for c in M4_CLASSES})
            gold[qid][cls].append(link)
    query_text = {q["native_query_id"]: q["text"] for q in queries}
    query_excluded_native = {q["native_query_id"]: q["excluded_native_ids"]
                             for q in queries}
    relevant_native: set[str] = set()
    for qid, classes in gold.items():
        for link in classes["resolves_in_hv"]:
            if link.get("gold_native_id") is not None:
                relevant_native.add(str(link["gold_native_id"]))
    for excluded in query_excluded_native.values():
        relevant_native.update(excluded)

    # Pass 1: denominators, df stats input, native index, quarantine scan.
    pass1_started = time.perf_counter()
    admitted: set[str] = set()
    native_index: dict[str, list[str]] = {}
    docs_encountered = 0
    tok_encountered = 0
    tok_indexed = 0
    withheld: list[dict] = []
    quarantine_hits: list[str] = []
    tok_declared_mismatch = 0
    cohort_digest = hashlib.sha256()
    cohort_digest.update(b"tb-hv-cohort-v1\n")
    indexed_digest = hashlib.sha256()
    indexed_digest.update(b"tb-doc-id-v2\n")

    for row, _shard_id, counted, row_sha in iter_cohort_rows(
            root, manifest, cohort, max_doc_bytes):
        tbdoc = row["tbdoc_id"]
        docs_encountered += 1
        if tbdoc in quarantined and tbdoc not in quarantine_hits:
            quarantine_hits.append(tbdoc)
        if tbdoc in admitted:
            raise DuplicateDocIdError(f"duplicate tbdoc_id in cohort: {tbdoc!r}")
        admitted.add(tbdoc)
        cohort_digest.update(json.dumps(
            {"tbdoc_id": tbdoc, "text_sha256": row_sha,
             "tok_v1": tok_v1_count(counted) if not row.get("withheld") else
             int(row.get("tok_v1", 0) or 0)},
            sort_keys=True, separators=(",", ":"),
            ensure_ascii=True).encode("ascii") + b"\n")
        if row.get("withheld") is True:
            tok_encountered += int(row.get("tok_v1", 0) or 0)
            withheld.append({"tbdoc_id": tbdoc,
                             "native_id": row.get("native_id"),
                             "acquisition": row.get("acquisition",
                                                    "not recorded; see package provenance")})
            continue
        recomputed = tok_v1_count(counted)
        tok_encountered += recomputed
        tok_indexed += recomputed
        if "tok_v1" in row and row["tok_v1"] != recomputed:
            tok_declared_mismatch += 1
        native = row.get("native_id")
        if isinstance(native, str) and native in relevant_native:
            native_index.setdefault(native, []).append(tbdoc)
        indexed_digest.update(_doc_fingerprint_line(
            tbdoc, row.get("title", ""), row.get("text", ""),
            {"native_doc_id": native, "stratum": row.get("stratum")}))
    if quarantine_hits:
        raise ValueError(
            f"cohort references {len(quarantine_hits)} quarantined ID(s) "
            f"(showing IDs only): {quarantine_hits[:20]}; refusing.")
    pass1_s = time.perf_counter() - pass1_started
    docs_indexed = docs_encountered - len(withheld)
    cohort_sha = cohort_digest.hexdigest()
    indexed_sha = indexed_digest.hexdigest()

    # Gold resolution: resolves_in_hv tbdocs inside the admitted cohort.
    scored: list[dict] = []
    unscored: list[dict] = []
    for qid in sorted(gold):
        if qid not in query_text:
            unscored.append({"query_native_id": qid, "reason": "query_text_missing",
                             "classes": {c: len(gold[qid][c]) for c in M4_CLASSES}})
            continue
        in_cohort = sorted({link["tbdoc_id"] for link in gold[qid]["resolves_in_hv"]
                            if link.get("tbdoc_id") in admitted})
        if not in_cohort:
            unscored.append({"query_native_id": qid,
                             "reason": "no resolves_in_hv gold inside cohort",
                             "classes": {c: len(gold[qid][c]) for c in M4_CLASSES},
                             "resolves_outside_cohort": sorted(
                                 {str(link.get("tbdoc_id"))
                                  for link in gold[qid]["resolves_in_hv"]})})
            continue
        excluded_tbdocs: set[str] = set()
        unmapped_excluded: list[str] = []
        for native in query_excluded_native.get(qid, []):
            hits = native_index.get(native, [])
            if hits:
                excluded_tbdocs.update(h for h in hits if h in admitted)
            else:
                unmapped_excluded.append(native)
        scored.append({"query_native_id": qid, "text": query_text[qid],
                       "gold_tbdocs": in_cohort,
                       "excluded_tbdocs": sorted(excluded_tbdocs),
                       "excluded_unmapped_native": unmapped_excluded,
                       "classes": {c: [link.get("gold_native_id") for link in gold[qid][c]]
                                   for c in M4_CLASSES}})
    if not scored:
        raise ValueError("no scored queries: every M4 query lacks in-cohort gold or "
                         "query text; see cohort scope (refusing an empty run).")

    # Pass 2: streaming BM25 over admitted rows (withheld never indexed).
    planned = plan_queries([(s["query_native_id"], s["text"]) for s in scored])
    excluded_map = {s["query_native_id"]: set(s["excluded_tbdocs"]) for s in scored}

    def _factory():
        for row, _shard_id, _counted, _sha in iter_cohort_rows(
                root, manifest, cohort, max_doc_bytes):
            if row.get("withheld") is True:
                continue
            yield row["tbdoc_id"], row.get("title", ""), row.get("text", "")

    engine = StreamingBM25()
    pass2_started = time.perf_counter()
    rankings, stream_stats = engine.score(planned, _factory, top_k, excluded_map)
    pass2_s = time.perf_counter() - pass2_started
    if stream_stats.docs_seen != docs_indexed:
        raise ValueError(
            f"scoring pass saw {stream_stats.docs_seen} docs but pass 1 indexed "
            f"{docs_indexed}; cohort moved during the run, refusing.")

    # tbdoc -> native for retrieved IDs only (single set-membership pass).
    wanted = {doc for qid in rankings for doc, _score in rankings[qid]}
    tbdoc_native: dict[str, str] = {}
    for row, _shard_id, _counted, _sha in iter_cohort_rows(
            root, manifest, cohort, max_doc_bytes):
        if row.get("withheld") is True:
            continue
        if row["tbdoc_id"] in wanted and row["tbdoc_id"] not in tbdoc_native:
            tbdoc_native[row["tbdoc_id"]] = str(row.get("native_id",
                                                        row["tbdoc_id"]))
            if len(tbdoc_native) == len(wanted):
                break
    # (Bounded: at most queries * top_k entries.)

    # Score + build the run.json inputs.
    from trace_bench.datasets.schema import BenchmarkCase, BenchmarkManifest
    from trace_bench.metrics.aggregator import BenchmarkAggregator
    from trace_bench.metrics.retrieval import attach_case_evidence, evaluate_case_retrieval

    cases: list[BenchmarkCase] = []
    metrics = []
    total_unjudged = 0
    for entry in scored:
        qid = entry["query_native_id"]
        judged_tbdocs = {link.get("tbdoc_id") for cls in M4_CLASSES
                         for link in gold[qid][cls] if link.get("tbdoc_id")}
        retrieved = [d for d, _s in rankings[qid]]
        scores = [s for _d, s in rankings[qid]]
        unjudged = [d for d in retrieved if d not in judged_tbdocs]
        total_unjudged += len(unjudged)
        case = BenchmarkCase(
            id=f"{task}:{qid}", native_query_id=qid, category="direct_lookup",
            query=entry["text"], gold_atom_ids=entry["gold_tbdocs"],
            native_gold_doc_ids=[g for c in M4_CLASSES for g in entry["classes"][c]
                                 if g is not None],
            excluded_doc_ids=entry["excluded_tbdocs"],
            metadata={"gold_resolution": {
                "resolves_in_hv": sorted(
                    link["tbdoc_id"] for link in gold[qid]["resolves_in_hv"]
                    if link.get("tbdoc_id")),
                "cohort_absent": sorted(
                    str(link.get("tbdoc_id")) for link in gold[qid]["resolves_in_hv"]
                    if link.get("tbdoc_id") not in admitted),
                "native_pool_only": entry["classes"]["native_pool_only"],
                "native_pool_missing": entry["classes"]["native_pool_missing"],
                "missing": entry["classes"]["missing"]},
                "excluded_unmapped_native_ids": entry["excluded_unmapped_native"],
                "unjudged_at_k": unjudged})
        cases.append(case)
        metric = evaluate_case_retrieval(
            case.id, case.category, retrieved, case.gold_atom_ids, False, False)
        metric.retrieved_ids = retrieved
        metric.retrieved_scores = scores
        metric.native_query_id = qid
        metric.native_retrieved_ids = [tbdoc_native.get(d, d) for d in retrieved]
        metric.backend_receipt = {"engine": ENGINE, "cohort": cohort_spec,
                                  "profile": manifest.profile}
        attach_case_evidence(metric, case)
        metrics.append(metric)

    maps_digest = m4_digest(root, task)
    query_digest = query_identity.get("cases_sha256") or query_identity.get("sha256")
    provenance = {
        "suite": "HV profile (custom diagnostic)",
        "split": "test",
        "evaluation_unit": "document",
        "protocol_status": "custom_diagnostic_hv",
        "claim_boundary": ("Custom HV-profile diagnostic over an explicitly "
                           "denominated cohort; not official-comparable."),
        "ignore_identical_query_document_ids": False,
        "hv": {"profile": manifest.profile,
               "population_id": f"{manifest.profile}/{cohort_spec}",
               "cohort": cohort_spec,
               "task": task,
               "tier_corpus_sha256": tier_census.corpus_sha256,
               "gold_maps_digest": maps_digest,
               "query_source_digest": query_digest,
               "query_source": query_identity,
               "docs_encountered": docs_encountered,
               "docs_indexed": docs_indexed,
               "docs_withheld": len(withheld),
               "tok_v1_encountered": tok_encountered,
               "tok_v1_indexed": tok_indexed,
               "queries_scored": len(scored),
               "queries_unscored": len(unscored),
               "unjudged_hits_at_k": total_unjudged},
    }
    manifest_scored = BenchmarkManifest(
        name=f"hv-{task}", version=f"{manifest.profile}+m4-{maps_digest[:12]}",
        description=f"HV custom diagnostic: task {task}, cohort {cohort_spec}.",
        corpus_sha256=cohort_sha, cases=cases, metadata=dict(provenance))
    from trace_bench.datasets.loader import case_fingerprint

    cases_sha = case_fingerprint(manifest_scored)
    manifest_scored.metadata["cases_sha256"] = cases_sha

    baseline = BenchmarkAggregator.aggregate_baseline(ENGINE, metrics)
    baseline.configuration = {**engine.configuration(), "cohort": cohort_spec,
                              "top_k": top_k}
    baseline.implementation_identity = engine.implementation_identity()
    baseline.implementation_identity["native_pins"] = engine.native_pins()
    baseline.ops["hv_passes"] = {"verify_s": round(verify_s, 3),
                                 "pass1_s": round(pass1_s, 3),
                                 "pass2_s": round(pass2_s, 3)}

    from trace_bench.metrics.aggregator import BenchmarkRunResult
    from trace_bench.runner import evaluation_protocol, get_hardware_info, metric_availability

    now = datetime.now(timezone.utc)
    run_result = BenchmarkRunResult(
        run_id=f"hv_{now.strftime('%Y%m%d_%H%M%S_%f')}",
        dataset_name=manifest_scored.name, dataset_version=manifest_scored.version,
        timestamp=now.isoformat(), corpus_sha256=cohort_sha,
        total_cases=len(metrics), cases_sha256=cases_sha,
        indexed_documents_sha256=indexed_sha,
        protocol=evaluation_protocol(manifest_scored, top_k, 1, 0),
        metric_availability=metric_availability(top_k),
        dataset_provenance=dict(provenance),
        mode="regression", release_authority=False,
        is_certification_eligible=False,
        hardware_info=get_hardware_info(),
        baselines={ENGINE: baseline},
        run_schema_version="tb-run-v1", comparison_context={})

    outdir.mkdir(parents=True, exist_ok=False)
    run_path = outdir / "run.json"
    run_result.save_json(run_path)
    envelope = {
        "format": "tb-hv-result-v1",
        "task": task, "cohort": cohort_spec,
        "profile": manifest.profile,
        "tb_version": __import__("trace_bench").__version__,
        "top_k": top_k,
        "tier": {"profile": manifest.profile,
                 "corpus_sha256": tier_census.corpus_sha256,
                 "docs": tier_census.docs,
                 "tok_v1_total": tier_census.tok_v1_total,
                 "verify_s": round(verify_s, 3)},
        "denominators": {"docs_encountered": docs_encountered,
                         "docs_indexed": docs_indexed,
                         "docs_withheld": len(withheld),
                         "tok_v1_encountered": tok_encountered,
                         "tok_v1_indexed": tok_indexed,
                         "tok_declared_mismatch_rows": tok_declared_mismatch,
                         "cohort_sha256": cohort_sha,
                         "indexed_documents_sha256": indexed_sha},
        "withheld": withheld[:1000],
        "withheld_truncated": len(withheld) > 1000,
        "withheld_note": ("Withheld rows are encountered but never indexed; no "
                          "withheld bytes enter scores, rankings, or excerpts."),
        "queries": {"scored": [s["query_native_id"] for s in scored],
                    "unscored": unscored,
                    "source": query_identity},
        "gold_maps_digest": maps_digest,
        "unjudged_hits_at_k": total_unjudged,
        "unjudged_note": "Retrieved IDs outside every M4 class stay unjudged: counted, never scored.",
        "streaming": stream_stats.to_dict(),
        "costs": {"verify_s": round(verify_s, 3), "pass1_s": round(pass1_s, 3),
                  "pass2_s": round(pass2_s, 3),
                  "wall_s": round(time.perf_counter() - started_all, 3)},
        "preflight": problems,
        "run_json": {"path": "run.json", "sha256": file_sha256(run_path)},
        "claim_boundary": provenance["claim_boundary"],
    }
    envelope_path = outdir / f"hv-{task}-{cohort_spec.replace(':', '-')}-result.json"
    envelope_path.write_text(json.dumps(envelope, indent=2, sort_keys=True),
                             encoding="utf-8")
    return envelope


# -- comparison refusal ---------------------------------------------------------

HV_PIN_KEYS = ("population_id", "cohort", "gold_maps_digest", "query_source_digest",
               "tier_corpus_sha256")


def refuse_pin_mismatch(current: dict, baseline: dict) -> None:
    """Refuse incompatible HV population/protocol/pin mixes (fail closed).

    Compares HV provenance pins declared on BOTH runs; any mismatch refuses.
    Shared-engine native-pin mixes refuse only when both runs carry HV
    provenance; non-HV replay/event-contrast semantics are unaffected.
    """
    from trace_bench.metrics.aggregator import UnstableQueryPairingError

    cur_hv = (current.get("dataset_provenance") or {}).get("hv") or {}
    base_hv = (baseline.get("dataset_provenance") or {}).get("hv") or {}
    if bool(cur_hv) != bool(base_hv):
        raise UnstableQueryPairingError(
            "HV custom-diagnostic run compared against a non-HV run; comparison refused.")
    for key in HV_PIN_KEYS:
        if key in cur_hv and key in base_hv and cur_hv[key] != base_hv[key]:
            raise UnstableQueryPairingError(
                f"HV {key} differs ({cur_hv[key]!r} vs {base_hv[key]!r}); comparison refused.")
    if not (cur_hv and base_hv):
        return  # native-pin mixing is an HV-route check only; replay/event
        # contrast semantics for non-HV runs are owned by validate_comparison.
    cur_base = current.get("baselines") or {}
    base_base = baseline.get("baselines") or {}
    for engine in sorted(set(cur_base) & set(base_base)):
        cur_pins = (cur_base[engine] or {}).get("implementation_identity", {}).get("native_pins")
        base_pins = (base_base[engine] or {}).get("implementation_identity", {}).get("native_pins")
        if cur_pins is not None and base_pins is not None and cur_pins != base_pins:
            raise UnstableQueryPairingError(
                f"Engine {engine!r} native pins differ; comparison refused "
                f"(pin mix across runs is not comparable).")
