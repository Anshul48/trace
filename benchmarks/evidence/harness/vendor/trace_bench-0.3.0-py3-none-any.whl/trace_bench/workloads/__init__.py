"""Installed workload runners: W1-W4 org-eval pilots + opt-in HV retrieval.

Every entry point here runs offline from wheel-bundled fixtures unless the
caller passes an explicit package/cache directory. There are no ``/tmp``
defaults, no implicit 500M source, and no network access: missing opt-in
inputs fail closed with the exact acquisition command.

Submodules (all TB-only; :mod:`trace_bench.metrics.org_eval` and
:mod:`trace_bench.metrics.org_eval_natural` are imported, never modified):

- :mod:`trace_bench.workloads.runner` -- W1-W4 matrices, envelopes, oracles.
- :mod:`trace_bench.workloads.hv` -- HV profile route (tasks, gold, cohorts).
- :mod:`trace_bench.workloads.streaming_bm25` -- bounded-memory BM25 baseline.
- :mod:`trace_bench.workloads.jobs` -- job dirs for workload runs.
- :mod:`trace_bench.workloads.show` -- terminal inspection of envelopes.
"""

from __future__ import annotations

from pathlib import Path

FIXTURE_DIR = Path(__file__).parent / "fixtures"

WORKLOADS = ("w1", "w2", "w3", "w4")

ENVELOPE_FORMAT = "tb-workload-result-v1"

__all__ = ["FIXTURE_DIR", "WORKLOADS", "ENVELOPE_FORMAT"]
