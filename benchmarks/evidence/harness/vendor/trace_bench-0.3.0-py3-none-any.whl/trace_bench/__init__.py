"""trace-bench: Reproducible retrieval comparisons and portable benchmark inputs."""

from trace_bench.baselines.base import BaseRetriever, IndexedDocument, RetrievalCandidate, RetrievalResponse
from trace_bench.adapters.base import BaseDatasetAdapter, CorpusDocument, BenchmarkQuery
from trace_bench.datasets.schema import BenchmarkManifest, BenchmarkCase
from trace_bench.metrics.retrieval import evaluate_case_retrieval, CaseRetrievalMetrics
from trace_bench.metrics.aggregator import BenchmarkAggregator, BenchmarkRunResult

__version__ = "0.3.0"
__all__ = [
    "BaseRetriever",
    "IndexedDocument",
    "RetrievalCandidate",
    "RetrievalResponse",
    "BaseDatasetAdapter",
    "CorpusDocument",
    "BenchmarkQuery",
    "BenchmarkManifest",
    "BenchmarkCase",
    "evaluate_case_retrieval",
    "CaseRetrievalMetrics",
    "BenchmarkAggregator",
    "BenchmarkRunResult",
]
