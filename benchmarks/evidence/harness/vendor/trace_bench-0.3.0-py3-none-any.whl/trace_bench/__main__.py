from trace_bench.runner import cli

cli()
