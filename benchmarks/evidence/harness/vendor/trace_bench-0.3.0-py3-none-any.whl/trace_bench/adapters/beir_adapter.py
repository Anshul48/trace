"""BEIR dataset adapter for broad zero-shot retrieval benchmarking."""

import csv
import hashlib
import json
import urllib.request
import zipfile
from pathlib import Path
from trace_bench.adapters.base import BaseDatasetAdapter, CorpusDocument, BenchmarkQuery, download_file


class BeirAdapter(BaseDatasetAdapter):
    """
    Adapter for BEIR benchmark datasets (e.g., scifact, nfcorpus, fiqa, arguana).
    Parses corpus.jsonl, queries.jsonl, and qrels/test.tsv.
    """

    BEIR_BASE_URL = "https://public.ukp.informatik.tu-darmstadt.de/thakur/BEIR/datasets/{dataset}.zip"

    # Pinned Hugging Face sources for official lanes (SHIP_DIRECTIVE_20261007 FIQA).
    # Each entry pins repo + revision + file bytes + sha256; preparation and loads
    # fail closed on any mismatch. Only fiqa/test is pinned; every other
    # dataset/split keeps the legacy BEIR-jsonl/UKP behavior unchanged.
    HF_PINNED_SOURCES = {
        "fiqa": {
            "test": {
                "corpus": {
                    "repo": "BeIR/fiqa",
                    "revision": "979c07a7cb5ccc6ca009792241fa1250b98055dd",
                    "repo_path": "corpus/corpus-00000-of-00001.parquet",
                    "bytes": 27700817,
                    "sha256": "b36bb07dab3bfad488190818828e749a52faf5ba391c1d51dac8b06064576f99",
                },
                "queries": {
                    "repo": "BeIR/fiqa",
                    "revision": "979c07a7cb5ccc6ca009792241fa1250b98055dd",
                    "repo_path": "queries/queries-00000-of-00001.parquet",
                    "bytes": 321680,
                    "sha256": "e9b3863724ffd538d8efff19684ef8ae495bdbddd96b35e81bdc39e3e22860d6",
                },
                "qrels": {
                    "repo": "BeIR/fiqa-qrels",
                    "revision": "252958f2d646e22cab6d0c72dd3f0d5de6d0655a",
                    "repo_path": "test.tsv",
                    "bytes": 25256,
                    "sha256": "6adc2a640dcdd22bb8b3858f89107adef2a7c3db20a63550dfa7a0f71e379e44",
                },
            }
        }
    }

    def __init__(self, dataset: str, cache_dir: Path | str, split: str = "test"):
        super().__init__(cache_dir)
        self.dataset = dataset.lower()
        self.split = split
        self.dataset_dir = self.cache_dir / self.dataset
        self.pinned_dir = self.dataset_dir / "hf-pinned"

    def dataset_name(self) -> str:
        return f"beir-{self.dataset}"

    def pinned_spec(self) -> dict | None:
        """Pinned upstream spec for this dataset/split, or None (legacy path)."""
        return self.HF_PINNED_SOURCES.get(self.dataset, {}).get(self.split)

    @staticmethod
    def _pinned_filename(entry: dict) -> str:
        return Path(entry["repo_path"]).name

    def _pinned_paths(self, spec: dict) -> dict[str, Path]:
        return {role: self.pinned_dir / self._pinned_filename(spec[role])
                for role in ("corpus", "queries", "qrels")}

    @staticmethod
    def _file_identity_ok(path: Path, entry: dict) -> bool:
        if not path.is_file() or path.stat().st_size != entry["bytes"]:
            return False
        digest = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                digest.update(chunk)
        return digest.hexdigest() == entry["sha256"]

    def _active_layout(self) -> str | None:
        # Legacy BEIR-jsonl layout keeps serving existing caches unchanged.
        if (self.dataset_dir / "corpus.jsonl").is_file():
            return "beir-jsonl"
        spec = self.pinned_spec()
        if spec is not None and any(p.exists() for p in self._pinned_paths(spec).values()):
            return "hf-pinned-parquet"
        return None

    def download_or_prepare(self) -> None:
        if self.dataset_dir.exists() and (self.dataset_dir / "corpus.jsonl").exists():
            return

        spec = self.pinned_spec()
        if spec is not None:
            self._prepare_pinned(spec)
            return

        zip_path = self.cache_dir / f"{self.dataset}.zip"
        url = self.BEIR_BASE_URL.format(dataset=self.dataset)
        if not zip_path.exists():
            try:
                download_file(url, zip_path)
            except Exception as e:
                raise RuntimeError(f"Failed to download BEIR dataset '{self.dataset}' from {url}: {e}")

        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            root = self.cache_dir.resolve()
            for member in zip_ref.infolist():
                target = (root / member.filename).resolve()
                if not target.is_relative_to(root) or ((member.external_attr >> 16) & 0o170000) == 0o120000:
                    raise ValueError(f"Unsafe BEIR archive member: {member.filename}")
            zip_ref.extractall(self.cache_dir)


    def _prepare_pinned(self, spec: dict) -> None:
        """Fetch the pinned upstream files, verifying bytes+sha256. Reuses verified caches."""
        self.pinned_dir.mkdir(parents=True, exist_ok=True)
        for role, dest in self._pinned_paths(spec).items():
            entry = spec[role]
            if self._file_identity_ok(dest, entry):
                continue
            if dest.exists():
                dest.unlink()
            url = f"https://huggingface.co/datasets/{entry['repo']}/resolve/{entry['revision']}/{entry['repo_path']}"
            try:
                download_file(url, dest)
            except Exception as e:
                raise RuntimeError(f"Failed to download pinned {role} for '{self.dataset}' from {url}: {e}")
            if not self._file_identity_ok(dest, entry):
                dest.unlink(missing_ok=True)
                raise ValueError(
                    f"Pinned {role} identity mismatch for '{self.dataset}' "
                    f"(expected {entry['bytes']} bytes / sha256 {entry['sha256']}); "
                    f"refusing to use unverified bytes. Delete {self.pinned_dir} and retry setup.")
        record = {
            role: {"repo": spec[role]["repo"], "revision": spec[role]["revision"],
                   "repo_path": spec[role]["repo_path"], "bytes": spec[role]["bytes"],
                   "sha256": spec[role]["sha256"],
                   "url": f"https://huggingface.co/datasets/{spec[role]['repo']}"
                          f"/resolve/{spec[role]['revision']}/{spec[role]['repo_path']}"}
            for role in ("corpus", "queries", "qrels")
        }
        (self.pinned_dir / "source-record.json").write_text(json.dumps(record, indent=2), encoding="utf-8")

    def _require_verified_pinned(self, spec: dict) -> dict[str, Path]:
        paths = self._pinned_paths(spec)
        missing = [role for role, path in paths.items() if not path.is_file()]
        if missing:
            raise FileNotFoundError(
                f"Pinned {self.dataset} {self.split} files missing ({', '.join(missing)}). Run setup first.")
        bad = [role for role, path in paths.items() if not self._file_identity_ok(path, spec[role])]
        if bad:
            raise ValueError(
                f"Pinned {self.dataset} {self.split} identity mismatch ({', '.join(bad)}); "
                f"refusing to load unverified bytes. Re-run setup to refetch.")
        return paths

    @staticmethod
    def _read_qrels(qrels_path: Path) -> tuple[dict[str, list[str]], dict[str, dict[str, float]]]:
        query_golds: dict[str, list[str]] = {}
        query_scores: dict[str, dict[str, float]] = {}
        with open(qrels_path, "r", encoding="utf-8") as f:
            reader = csv.reader(f, delimiter="\t")
            header = next(reader, None)  # query-id, corpus-id, score
            if header != ["query-id", "corpus-id", "score"]:
                raise ValueError(f"Invalid BEIR qrels header in {qrels_path}: {header}")
            for row in reader:
                if len(row) != 3:
                    raise ValueError(f"Malformed qrel row in {qrels_path}: {row}")
                q_id, doc_id, score_str = row[0], row[1], row[2]
                score = float(score_str)
                if score < 0:
                    continue  # -1 denotes unjudged, never a positive relevance grade.
                if doc_id in query_scores.get(q_id, {}):
                    raise ValueError(f"Duplicate qrel for query {q_id}, document {doc_id}")
                query_scores.setdefault(q_id, {})[doc_id] = score
                if score > 0:
                    query_golds.setdefault(q_id, []).append(doc_id)
        return query_golds, query_scores

    def _build_queries(self, query_texts: dict[str, str], query_golds: dict[str, list[str]],
                       query_scores: dict[str, dict[str, float]], metadata: dict) -> list[BenchmarkQuery]:
        queries: list[BenchmarkQuery] = []
        for q_id, gold_ids in query_golds.items():
            if q_id not in query_texts:
                raise ValueError(f"Qrels reference missing query {q_id}")
            if q_id in query_texts:
                queries.append(
                    BenchmarkQuery(
                        query_id=q_id,
                        text=query_texts[q_id],
                        gold_doc_ids=gold_ids,
                        relevance_scores=query_scores.get(q_id, {}),
                        category="direct_lookup",
                        metadata=dict(metadata),
                    )
                )
        return queries

    def load_corpus(self) -> list[CorpusDocument]:
        if self._active_layout() == "hf-pinned-parquet":
            spec = self.pinned_spec()
            assert spec is not None
            return self._load_pinned_corpus(self._require_verified_pinned(spec)["corpus"])
        corpus_path = self.dataset_dir / "corpus.jsonl"
        if not corpus_path.exists():
            raise FileNotFoundError(f"BEIR corpus file not found: {corpus_path}. Run setup first.")

        docs: list[CorpusDocument] = []
        with open(corpus_path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                item = json.loads(line)
                docs.append(
                    CorpusDocument(
                        doc_id=str(item.get("_id", item.get("id", ""))),
                        title=item.get("title", ""),
                        text=item.get("text", ""),
                        metadata=item.get("metadata", {}),
                    )
                )
        return docs

    def _load_pinned_corpus(self, corpus_path: Path) -> list[CorpusDocument]:
        try:
            import pyarrow.parquet as pq
        except ImportError as e:
            raise RuntimeError(
                "Reading the pinned FIQA corpus requires pyarrow "
                "(pip install \"trace-bench[datasets]\").") from e
        # Official lane: retain EVERY native row, including genuine empty-text
        # documents (e.g. FIQA doc 117276). Empty text is retained as ""; text is
        # never manufactured. No filtering here; general validation is unchanged.
        table = pq.read_table(corpus_path)
        docs: list[CorpusDocument] = []
        for row in table.to_pylist():
            docs.append(
                CorpusDocument(
                    doc_id=str(row.get("_id", row.get("id", ""))),
                    title=row.get("title") or "",
                    text=row.get("text") or "",
                    metadata={},
                )
            )
        return docs

    def load_queries(self) -> list[BenchmarkQuery]:
        if self._active_layout() == "hf-pinned-parquet":
            spec = self.pinned_spec()
            assert spec is not None
            paths = self._require_verified_pinned(spec)
            return self._load_pinned_queries(paths["queries"], paths["qrels"], spec)
        queries_path = self.dataset_dir / "queries.jsonl"
        qrels_path = self.dataset_dir / "qrels" / f"{self.split}.tsv"

        if not queries_path.exists() or not qrels_path.exists():
            raise FileNotFoundError(f"BEIR queries or qrels missing in {self.dataset_dir}. Run setup first.")

        # Load query texts
        query_texts: dict[str, str] = {}
        with open(queries_path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                item = json.loads(line)
                q_id = str(item.get("_id", item.get("id", "")))
                if q_id in query_texts:
                    raise ValueError(f"Duplicate native query ID: {q_id}")
                query_texts[q_id] = item.get("text", "")

        query_golds, query_scores = self._read_qrels(qrels_path)
        return self._build_queries(query_texts, query_golds, query_scores, {"split": self.split})

    def _load_pinned_queries(self, queries_path: Path, qrels_path: Path, spec: dict) -> list[BenchmarkQuery]:
        try:
            import pyarrow.parquet as pq
        except ImportError as e:
            raise RuntimeError(
                "Reading the pinned FIQA queries requires pyarrow "
                "(pip install \"trace-bench[datasets]\").") from e
        query_texts: dict[str, str] = {}
        for row in pq.read_table(queries_path).to_pylist():
            q_id = str(row.get("_id", row.get("id", "")))
            if q_id in query_texts:
                raise ValueError(f"Duplicate native query ID: {q_id}")
            query_texts[q_id] = row.get("text") or ""
        # Official lane: qrels are consumed unchanged; every judged query is kept,
        # including links to retained empty-text documents.
        query_golds, query_scores = self._read_qrels(qrels_path)
        return self._build_queries(query_texts, query_golds, query_scores, {
            "split": self.split,
            "source_layout": "hf-pinned-parquet",
            "source_repos": {spec[role]["repo"]: spec[role]["revision"]
                             for role in ("corpus", "queries", "qrels")},
        })
