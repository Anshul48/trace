"""HippoRAG 2 / GraphRAG benchmark adapter for multi-hop graph retrieval."""

import json
from pathlib import Path
from trace_bench.adapters.base import BaseDatasetAdapter, CorpusDocument, BenchmarkQuery, download_file
from trace_bench.datasets.schema import AcquisitionError, ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN


class HippoRagAdapter(BaseDatasetAdapter):
    """
    Adapter for HippoRAG 2 multi-hop knowledge graph retrieval datasets.
    Supports 2WikiMultiHopQA, MuSiQue, and HotpotQA formats.
    Prohibits silent synthetic fallback generation.
    """

    SAMPLE_DATA_URL = "https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/main/reproduce/dataset/sample.json"

    def __init__(self, task: str = "sample", cache_dir: Path | str = "benchmarks/cache"):
        super().__init__(cache_dir)
        self.task = task.lower()
        self.dataset_dir = self.cache_dir / f"hipporag_{self.task}"

    def dataset_name(self) -> str:
        return f"hipporag-{self.task}"

    def download_or_prepare(self) -> None:
        self.dataset_dir.mkdir(parents=True, exist_ok=True)
        data_file = self.dataset_dir / "dataset.json"
        if data_file.exists():
            return

        if self.task != "sample":
            raise AcquisitionError(error_code=ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN,
                message=f"Provide official {self.task} data at {data_file}; a HippoRAG sample cannot substitute for this task.")
        if self.task == "sample":
            try:
                download_file(self.SAMPLE_DATA_URL, data_file, strict_tls=True)
            except Exception as e:
                raise AcquisitionError(
                    error_code=ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN,
                    message=f"Failed to acquire official HippoRAG dataset from {self.SAMPLE_DATA_URL}: {e}. "
                            f"Synthetic fallback fixture generation is strictly prohibited.",
                    details={"task": self.task, "url": self.SAMPLE_DATA_URL, "error": str(e)},
                )

    def load_corpus(self) -> list[CorpusDocument]:
        data_file = self.dataset_dir / "dataset.json"
        if not data_file.exists():
            self.download_or_prepare()
        with open(data_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        docs: list[CorpusDocument] = []
        seen_titles = set()

        for item in data:
            paragraphs = item.get("paragraphs", item.get("gold_paragraphs", []))
            for p in paragraphs:
                title = p.get("title", "")
                text = p.get("text", "")
                doc_id = f"hippo_doc_{len(docs)}"
                if title and title not in seen_titles:
                    seen_titles.add(title)
                    docs.append(CorpusDocument(doc_id=doc_id, title=title, text=text))
                elif not title:
                    docs.append(CorpusDocument(doc_id=doc_id, title="", text=text))

        return docs

    def load_queries(self) -> list[BenchmarkQuery]:
        data_file = self.dataset_dir / "dataset.json"
        if not data_file.exists():
            self.download_or_prepare()
        with open(data_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        docs = self.load_corpus()
        title_to_doc_id = {d.title: d.doc_id for d in docs if d.title}

        queries: list[BenchmarkQuery] = []
        for item in data:
            q_id = str(item.get("id", item.get("_id", f"q_{len(queries)}")))
            question = item.get("question", item.get("query", ""))
            gold_paras = item.get("gold_paragraphs", [])
            gold_ids = []
            for gp in gold_paras:
                t = gp.get("title", "")
                if t in title_to_doc_id:
                    gold_ids.append(title_to_doc_id[t])

            queries.append(
                BenchmarkQuery(
                    query_id=q_id,
                    text=question,
                    gold_doc_ids=gold_ids,
                    category="multi_hop",
                    metadata={"answer": item.get("answer", "")},
                )
            )

        return queries
