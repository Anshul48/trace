"""BRIGHT dataset adapter for reasoning-intensive hierarchical retrieval."""

import json
from pathlib import Path
from trace_bench.adapters.base import BaseDatasetAdapter, CorpusDocument, BenchmarkQuery


class BrightAdapter(BaseDatasetAdapter):
    """
    Adapter for BRIGHT reasoning-intensive benchmarks (e.g., coding, biology, earth_science, economics).
    Loads reasoning queries with multi-level candidates.
    """

    def __init__(self, task: str, cache_dir: Path | str, revision: str | None = None):
        super().__init__(cache_dir)
        self.task = task.lower()
        self.dataset_dir = self.cache_dir / f"bright_{self.task}"
        self.revision = revision
        self.raw_dir = self.cache_dir / "bright" / "raw"

    def dataset_name(self) -> str:
        return f"bright-{self.task}"

    def download_or_prepare(self) -> None:
        from trace_bench.datasets.portable import BRIGHT_TASKS
        if self.task not in BRIGHT_TASKS:
            raise ValueError(f"Unknown BRIGHT task '{self.task}'; choose from {BRIGHT_TASKS}")
        paths = [self.raw_dir / group / f"{self.task}-00000-of-00001.parquet"
                 for group in ("documents", "examples")]
        if all(p.exists() for p in paths):
            return
        if (self.dataset_dir / "corpus.jsonl").exists() and (self.dataset_dir / "queries.jsonl").exists():
            return
        self.dataset_dir.mkdir(parents=True, exist_ok=True)
        try:
            from huggingface_hub import HfApi, hf_hub_download
            import pyarrow.parquet  # noqa: F401
        except ImportError as exc:
            raise RuntimeError('BRIGHT setup requires: pip install "trace-bench[datasets]"') from exc
        revision = self.revision or HfApi().dataset_info("xlangai/BRIGHT").sha
        for group, path in zip(("documents", "examples"), paths):
            path.parent.mkdir(parents=True, exist_ok=True)
            downloaded = hf_hub_download("xlangai/BRIGHT", repo_type="dataset", revision=revision,
                filename=f"{group}/{self.task}-00000-of-00001.parquet", cache_dir=self.cache_dir / "hf")
            import shutil
            shutil.copyfile(downloaded, path)
        self.revision = revision

    def _official_rows(self, group: str):
        path = self.raw_dir / group / f"{self.task}-00000-of-00001.parquet"
        if not path.exists():
            return None
        try:
            import pyarrow.parquet as parquet
        except ImportError as exc:
            raise RuntimeError('Reading BRIGHT parquet requires: pip install "trace-bench[datasets]"') from exc
        return parquet.read_table(path).to_pylist()

    def load_corpus(self) -> list[CorpusDocument]:
        official = self._official_rows("documents")
        if official is not None:
            return [CorpusDocument(doc_id=str(d["id"]), text=d["content"]) for d in official]
        corpus_path = self.dataset_dir / "documents.json"
        if not corpus_path.exists():
            corpus_path = self.dataset_dir / "corpus.jsonl"
        if not corpus_path.exists():
            raise FileNotFoundError(f"BRIGHT documents file missing in {self.dataset_dir}. Run setup first.")

        docs: list[CorpusDocument] = []
        if corpus_path.suffix == ".jsonl":
            with open(corpus_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        item = json.loads(line)
                        docs.append(
                            CorpusDocument(
                                doc_id=str(item.get("id", item.get("doc_id", ""))),
                                title=item.get("title", ""),
                                text=item.get("text", item.get("content", "")),
                                metadata=item.get("metadata", {}),
                            )
                        )
        else:
            with open(corpus_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for item in data:
                    docs.append(
                        CorpusDocument(
                            doc_id=str(item.get("id", item.get("doc_id", ""))),
                            title=item.get("title", ""),
                            text=item.get("text", item.get("content", "")),
                            metadata=item.get("metadata", {}),
                        )
                    )
        return docs

    def load_queries(self) -> list[BenchmarkQuery]:
        official = self._official_rows("examples")
        if official is not None:
            return [BenchmarkQuery(query_id=str(q["id"]), text=q["query"],
                gold_doc_ids=[str(i) for i in q["gold_ids"]], category="cross_domain",
                metadata={"subset": self.task, "excluded_ids": [str(i) for i in q.get("excluded_ids", []) if str(i) != "N/A"]})
                for q in official]
        queries_path = self.dataset_dir / "queries.json"
        if not queries_path.exists():
            queries_path = self.dataset_dir / "queries.jsonl"
        if not queries_path.exists():
            raise FileNotFoundError(f"BRIGHT queries file missing in {self.dataset_dir}. Run setup first.")

        queries: list[BenchmarkQuery] = []
        if queries_path.suffix == ".jsonl":
            with open(queries_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        item = json.loads(line)
                        queries.append(
                            BenchmarkQuery(
                                query_id=str(item.get("id", item.get("query_id", ""))),
                                text=item.get("query", item.get("text", "")),
                                gold_doc_ids=[str(x) for x in item.get("gold_ids", item.get("gold_doc_ids", []))],
                                category="cross_domain",
                                metadata=item.get("metadata", {}),
                            )
                        )
        else:
            with open(queries_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for item in data:
                    queries.append(
                        BenchmarkQuery(
                            query_id=str(item.get("id", item.get("query_id", ""))),
                            text=item.get("query", item.get("text", "")),
                            gold_doc_ids=[str(x) for x in item.get("gold_ids", item.get("gold_doc_ids", []))],
                            category="cross_domain",
                            metadata=item.get("metadata", {}),
                        )
                    )
        return queries
