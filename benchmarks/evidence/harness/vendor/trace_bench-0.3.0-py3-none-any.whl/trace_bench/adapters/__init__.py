"""Dataset adapters for the complete benchmark matrix (P0 through P2)."""

from trace_bench.adapters.base import BaseDatasetAdapter, CorpusDocument, BenchmarkQuery
from trace_bench.adapters.beir_adapter import BeirAdapter
from trace_bench.adapters.bright_adapter import BrightAdapter
from trace_bench.adapters.multihop_adapter import MultiHopAdapter
from trace_bench.adapters.hichunk_adapter import HiChunkAdapter
from trace_bench.adapters.longmemeval_adapter import LongMemEvalAdapter
from trace_bench.adapters.trec_rag_adapter import TrecRagAdapter
from trace_bench.adapters.mteb_adapter import MtebAdapter
from trace_bench.adapters.ann_scale_adapter import AnnScaleAdapter
from trace_bench.adapters.hipporag_adapter import HippoRagAdapter

__all__ = [
    "BaseDatasetAdapter",
    "CorpusDocument",
    "BenchmarkQuery",
    "BeirAdapter",
    "BrightAdapter",
    "MultiHopAdapter",
    "HiChunkAdapter",
    "LongMemEvalAdapter",
    "TrecRagAdapter",
    "MtebAdapter",
    "AnnScaleAdapter",
    "HippoRagAdapter",
]
