"""Base protocol and data models for benchmark dataset adapters."""

import json
import os
import shutil
import ssl
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

from trace_bench.datasets.schema import (
    BenchmarkManifest,
    BenchmarkCase,
    SourceMapping,
    DatasetAdmission,
    AcquisitionError,
    ERR_INSECURE_TLS_FORBIDDEN,
    ERR_CHECKSUM_MISMATCH,
)


def remote_size(url: str, timeout: float = 10.0) -> int | None:
    """Best-effort Content-Length via HEAD. Returns None when unknown."""
    import httpx

    try:
        response = httpx.head(url, follow_redirects=True, verify=True, timeout=timeout,
                              headers={"User-Agent": "Trace-Bench/1.0"})
        if response.status_code >= 400:
            return None
        length = response.headers.get("content-length")
        return int(length) if length and length.isdigit() else None
    except Exception:
        return None


def download_file(url: str, dest_path: Path | str, strict_tls: bool = True,
                  resume: bool = True) -> Path:
    """
    Download a file using httpx atomically with strict TLS verification.
    Resumes a partial ``.download.tmp`` via Range requests when the server
    supports them; otherwise restarts. Raises AcquisitionError on TLS/network
    failure; NEVER falls back to verify=False.
    """
    import httpx

    if not strict_tls:
        raise AcquisitionError(
            error_code=ERR_INSECURE_TLS_FORBIDDEN,
            message="Insecure TLS download requested (strict_tls=False is prohibited).",
            details={"url": url},
        )

    dest = Path(dest_path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp_dest = dest.with_suffix(".download.tmp")
    offset = temp_dest.stat().st_size if (resume and temp_dest.exists()) else 0

    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Trace-Bench/1.0"}
    if offset:
        headers["Range"] = f"bytes={offset}-"

    try:
        with httpx.stream("GET", url, headers=headers, follow_redirects=True, verify=True, timeout=180.0) as resp:
            if resp.status_code == 416:
                # Range unsatisfiable: complete only if our bytes match the total.
                total = (resp.headers.get("content-range", "").rsplit("/", 1) or [""])[-1]
                if offset and total.isdigit() and offset == int(total):
                    temp_dest.replace(dest)
                    return dest
                offset = 0
                temp_dest.unlink(missing_ok=True)
                return download_file(url, dest_path, strict_tls=strict_tls, resume=False)
            resp.raise_for_status()
            if resp.status_code == 206 and offset:
                print(f"Resuming {dest.name} at byte {offset:,}.")
                mode = "ab"
            else:
                if offset:
                    print(f"Server ignored resume for {dest.name}; restarting download.")
                offset = 0
                mode = "wb"
            with open(temp_dest, mode) as f:
                for chunk in resp.iter_bytes(chunk_size=65536):
                    f.write(chunk)
    except AcquisitionError:
        raise
    except Exception as e:
        # Keep the partial file for a later resume; only the final rename completes.
        raise AcquisitionError(
            error_code="ERR_DOWNLOAD_FAILED",
            message=f"Strict TLS download failed for {url}: {e}",
            details={"url": url, "error": str(e), "resumable": True},
        )

    if temp_dest.exists():
        if dest.exists():
            dest.unlink()
        temp_dest.replace(dest)

    return dest


@dataclass
class CorpusDocument:
    """A document or passage in a benchmark corpus."""
    doc_id: str
    title: str = ""
    text: str = ""
    metadata: dict = field(default_factory=dict)


@dataclass
class BenchmarkQuery:
    """A query in a benchmark with ground-truth relevant document IDs."""
    query_id: str
    text: str
    gold_doc_ids: list[str] = field(default_factory=list)
    relevance_scores: dict[str, int] = field(default_factory=dict)
    category: str = "general"
    metadata: dict = field(default_factory=dict)


class BaseDatasetAdapter(ABC):
    """Abstract interface for public benchmark suite loaders."""

    def __init__(self, cache_dir: Path | str):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    @abstractmethod
    def dataset_name(self) -> str:
        """Name of the dataset (e.g. 'scifact', 'bright-coding', 'multihop-rag')."""
        pass

    @abstractmethod
    def download_or_prepare(self) -> None:
        """Download or extract dataset to cache if not already present."""
        pass

    @abstractmethod
    def load_corpus(self) -> list[CorpusDocument]:
        """Load and return all corpus documents."""
        pass

    @abstractmethod
    def load_queries(self) -> list[BenchmarkQuery]:
        """Load and return evaluation queries with gold document IDs."""
        pass

    def export_manifest(self, output_path: Path | str | None = None) -> tuple[BenchmarkManifest, str]:
        """Convert loaded dataset into a validated BenchmarkManifest JSON file with reversible source mappings."""
        from trace_bench.datasets.loader import compute_sha256

        docs = self.load_corpus()
        queries = self.load_queries()
        native_ids = [d.doc_id for d in docs]
        if len(native_ids) != len(set(native_ids)) or any(not doc_id for doc_id in native_ids):
            raise ValueError("Native corpus IDs must be nonempty and unique")

        paragraphs = []
        doc_id_to_idx: dict[str, int] = {}
        source_mappings: list[SourceMapping] = []

        char_offset = 0
        for idx, d in enumerate(docs):
            content = f"{d.title}\n\n{d.text}".strip() if d.title else d.text
            paragraphs.append(content)
            internal_atom_id = f"atom-{idx}"
            doc_id_to_idx[d.doc_id] = idx

            start_off = char_offset
            end_off = char_offset + len(content)
            char_offset = end_off + 2  # plus separator \n\n

            source_mappings.append(
                SourceMapping(
                    dataset_name=self.dataset_name(),
                    native_id=d.doc_id,
                    internal_id=internal_atom_id,
                    entity_type="document",
                    source_hash=compute_sha256(content),
                    char_offset_start=start_off,
                    char_offset_end=end_off,
                    metadata=d.metadata,
                )
            )

        corpus_text = "\n\n".join(paragraphs)
        corpus_hash = compute_sha256(corpus_text)

        cases: list[BenchmarkCase] = []
        for q in queries:
            missing = (set(q.gold_doc_ids) | set(q.relevance_scores) |
                       set(q.metadata.get("excluded_ids", []))) - set(doc_id_to_idx)
            if missing:
                raise ValueError(f"Query {q.query_id} references missing gold documents: {sorted(missing)}")
            gold_atom_ids = [
                f"atom-{doc_id_to_idx[g_id]}" for g_id in q.gold_doc_ids if g_id in doc_id_to_idx
            ]
            cases.append(
                BenchmarkCase(
                    id=q.query_id,
                    native_query_id=q.query_id,
                    category=q.category if q.category in (
                        "direct_lookup", "chronology", "contradiction", "cross_domain",
                        "global_context", "multi_hop", "historical", "out_of_scope"
                    ) else "direct_lookup",
                    query=q.text,
                    gold_atom_ids=gold_atom_ids,
                    native_gold_doc_ids=q.gold_doc_ids,
                    expected_abstention=q.metadata.get("expected_abstention", len(gold_atom_ids) == 0),
                    relevance_scores={f"atom-{doc_id_to_idx[g]}": grade for g, grade in q.relevance_scores.items()
                                      if g in doc_id_to_idx},
                    excluded_doc_ids=[f"atom-{doc_id_to_idx[g]}" for g in q.metadata.get("excluded_ids", [])],
                    metadata=q.metadata,
                )
            )

        manifest = BenchmarkManifest(
            name=self.dataset_name(),
            version="1.0.0",
            description=f"Curated manifest for {self.dataset_name()}",
            corpus_sha256=corpus_hash,
            corpus_text=corpus_text,
            release_authority=False,
            mode="regression",
            source_mappings=source_mappings,
            cases=cases,
            metadata={"source": self.dataset_name(), "total_docs": len(docs), "total_queries": len(queries)},
        )

        out = Path(output_path) if output_path else (self.cache_dir / f"{self.dataset_name()}_manifest.json")
        out.parent.mkdir(parents=True, exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            json.dump(manifest.model_dump(), f, indent=2)

        return manifest, corpus_text
