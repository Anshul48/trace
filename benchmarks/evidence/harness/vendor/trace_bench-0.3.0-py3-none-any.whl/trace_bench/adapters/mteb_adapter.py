"""MTEB / LMEB embedding layer benchmark adapter."""

import json
from pathlib import Path
from trace_bench.adapters.base import BaseDatasetAdapter, CorpusDocument, BenchmarkQuery
from trace_bench.datasets.schema import AcquisitionError, ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN


class MtebAdapter(BaseDatasetAdapter):
    """
    Adapter for MTEB / LMEB retrieval tasks.
    Evaluates raw embedding bi-encoder backends against standardized retrieval tasks.
    Prohibits silent synthetic fallback data generation.
    """

    def __init__(self, task_name: str = "scifact", cache_dir: Path | str = "benchmarks/cache"):
        super().__init__(cache_dir)
        self.task_name = task_name.lower()
        self.dataset_dir = self.cache_dir / f"mteb_{self.task_name}"

    def dataset_name(self) -> str:
        return f"mteb-{self.task_name}"

    def download_or_prepare(self) -> None:
        self.dataset_dir.mkdir(parents=True, exist_ok=True)
        corpus_path = self.dataset_dir / "corpus.jsonl"
        queries_path = self.dataset_dir / "queries.jsonl"

        if not corpus_path.exists() or not queries_path.exists():
            raise AcquisitionError(
                error_code=ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN,
                message=f"MTEB dataset files missing in {self.dataset_dir}. "
                        f"Provide official corpus.jsonl and queries.jsonl; synthetic substitution is forbidden.",
                details={"dataset_dir": str(self.dataset_dir)},
            )

    def load_corpus(self) -> list[CorpusDocument]:
        self.download_or_prepare()
        corpus_path = self.dataset_dir / "corpus.jsonl"
        docs: list[CorpusDocument] = []
        with open(corpus_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    item = json.loads(line)
                    docs.append(
                        CorpusDocument(
                            doc_id=str(item.get("id", item.get("doc_id", ""))),
                            title=item.get("title", ""),
                            text=item.get("text", item.get("content", "")),
                        )
                    )
        return docs

    def load_queries(self) -> list[BenchmarkQuery]:
        self.download_or_prepare()
        queries_path = self.dataset_dir / "queries.jsonl"
        queries: list[BenchmarkQuery] = []
        with open(queries_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    item = json.loads(line)
                    queries.append(
                        BenchmarkQuery(
                            query_id=str(item.get("id", item.get("query_id", ""))),
                            text=item.get("query", item.get("text", "")),
                            gold_doc_ids=[str(x) for x in item.get("gold_ids", [])],
                            category="direct_lookup",
                        )
                    )
        return queries
