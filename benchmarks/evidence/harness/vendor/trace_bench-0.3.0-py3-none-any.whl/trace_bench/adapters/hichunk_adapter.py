"""HiCBench / HiChunk adapter for hierarchical chunk and multi-level retrieval."""

import json
from pathlib import Path
from trace_bench.adapters.base import BaseDatasetAdapter, CorpusDocument, BenchmarkQuery
from trace_bench.datasets.schema import AcquisitionError, ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN


class HiChunkAdapter(BaseDatasetAdapter):
    """
    Adapter for HiCBench / HiChunk datasets.
    Evaluates multi-level tree chunking, granular atom boundaries, and evidence-dense retrieval.
    Requires official cached dataset files; prohibits silent synthetic data generation.
    """

    def __init__(self, cache_dir: Path | str = "benchmarks/cache"):
        super().__init__(cache_dir)
        self.dataset_dir = self.cache_dir / "hichunk"

    def dataset_name(self) -> str:
        return "hichunk-benchmark"

    def download_or_prepare(self) -> None:
        self.dataset_dir.mkdir(parents=True, exist_ok=True)
        corpus_path = self.dataset_dir / "corpus.jsonl"
        queries_path = self.dataset_dir / "queries.jsonl"

        if not corpus_path.exists() or not queries_path.exists():
            raise AcquisitionError(
                error_code=ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN,
                message=f"HiChunk dataset files missing in {self.dataset_dir}. "
                        f"Provide official corpus.jsonl and queries.jsonl; synthetic substitution is forbidden.",
                details={"dataset_dir": str(self.dataset_dir)},
            )

    def load_corpus(self) -> list[CorpusDocument]:
        self.download_or_prepare()
        corpus_path = self.dataset_dir / "corpus.jsonl"
        docs: list[CorpusDocument] = []
        with open(corpus_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    item = json.loads(line)
                    docs.append(
                        CorpusDocument(
                            doc_id=str(item.get("id", item.get("chunk_id", ""))),
                            title=item.get("section_title", item.get("title", "")),
                            text=item.get("content", item.get("text", "")),
                            metadata={
                                "level": item.get("hierarchy_level", 0),
                                "parent_id": item.get("parent_id"),
                            },
                        )
                    )
        return docs

    def load_queries(self) -> list[BenchmarkQuery]:
        self.download_or_prepare()
        queries_path = self.dataset_dir / "queries.jsonl"
        queries: list[BenchmarkQuery] = []
        with open(queries_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    item = json.loads(line)
                    queries.append(
                        BenchmarkQuery(
                            query_id=str(item.get("id", item.get("query_id", ""))),
                            text=item.get("query", item.get("question", "")),
                            gold_doc_ids=[str(x) for x in item.get("gold_chunk_ids", item.get("gold_ids", []))],
                            category="direct_lookup",
                            metadata={"evidence_type": "hierarchical_chunk"},
                        )
                    )
        return queries
