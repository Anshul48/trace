"""Backend capability declarations and explicit selection semantics.

Every engine TB can run has a declared capability record: what it needs
(packages, platform, network), what it costs, and whether concurrent queries
against one instance are safe. Unknown engines (`python:module:Class`) get a
conservative default: not selectable by `all`, thread-safety unknown.
"""

from __future__ import annotations

import importlib.util
import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class BackendCapability:
    """Static declaration for one engine name."""

    name: str
    description: str
    requires_packages: tuple[str, ...] = ()
    requires_posix: bool = False
    needs_network: bool = False
    cost_class: str = "cheap"  # "cheap" | "expensive"
    thread_safe: bool | None = None  # None = unknown / undeclared
    thread_safety_notes: str = ""
    selectable_by_all: bool = False
    supports_checkpoints: bool = False


BACKEND_CAPABILITIES: dict[str, BackendCapability] = {
    "bm25": BackendCapability(
        name="bm25",
        description="In-process NumPy BM25 over the frozen corpus. Offline, deterministic.",
        thread_safe=True,
        thread_safety_notes="Read-only postings after index(); safe for concurrent retrieve().",
        selectable_by_all=True,
    ),
    "hipporag_ppr": BackendCapability(
        name="hipporag_ppr",
        description="Local heuristic bipartite PageRank baseline (not official HippoRAG).",
        requires_packages=("sentence_transformers",),
        needs_network=False,
        cost_class="expensive",
        thread_safe=None,
        thread_safety_notes="Wraps DenseRetriever; thread-safety of the embedding model is undeclared.",
        selectable_by_all=False,
    ),
    "dense": BackendCapability(
        name="dense",
        description="Dense MiniLM retrieval. Downloads/caches model weights on first use.",
        requires_packages=("sentence_transformers",),
        needs_network=True,
        cost_class="expensive",
        thread_safe=None,
        thread_safety_notes="sentence-transformers encode() thread-safety is undeclared; verify before concurrency>1.",
        selectable_by_all=False,
    ),
    "dense_bge": BackendCapability(
        name="dense_bge",
        description="Dense BGE-large retrieval (~1.3 GB weights).",
        requires_packages=("sentence_transformers",),
        needs_network=True,
        cost_class="expensive",
        thread_safe=None,
        selectable_by_all=False,
    ),
    "hybrid_rrf": BackendCapability(
        name="hybrid_rrf",
        description="BM25 + dense reciprocal-rank fusion. Inherits dense requirements.",
        requires_packages=("sentence_transformers",),
        needs_network=True,
        cost_class="expensive",
        thread_safe=None,
        selectable_by_all=False,
    ),
    "flat_hierarchy": BackendCapability(
        name="flat_hierarchy",
        description="Flat-hierarchy dense baseline. Inherits dense requirements.",
        requires_packages=("sentence_transformers",),
        needs_network=True,
        cost_class="expensive",
        thread_safe=None,
        selectable_by_all=False,
    ),
    "trace_flat": BackendCapability(
        name="trace_flat",
        description="Trace-Lite flat mode via the v1 API (currently version-skewed; see status).",
        requires_packages=("trace_lite",),
        cost_class="expensive",
        thread_safe=None,
        selectable_by_all=False,
    ),
    "trace_tree": BackendCapability(
        name="trace_tree",
        description="Trace-Lite tree mode via the v1 API (currently version-skewed; see status).",
        requires_packages=("trace_lite",),
        cost_class="expensive",
        thread_safe=None,
        selectable_by_all=False,
    ),
    "trace_hybrid": BackendCapability(
        name="trace_hybrid",
        description="Trace-Lite hybrid mode via the v1 API (currently version-skewed; see status).",
        requires_packages=("trace_lite",),
        cost_class="expensive",
        thread_safe=None,
        selectable_by_all=False,
    ),
    "tl_narrow": BackendCapability(
        name="tl_narrow",
        description="Real tlsys S-04 Narrow in a disposable store. Requires a trace-architecture checkout and POSIX locking.",
        requires_packages=("sentence_transformers",),
        requires_posix=True,
        needs_network=True,
        cost_class="expensive",
        thread_safe=None,
        thread_safety_notes="Product store/index thread-safety is undeclared; run concurrency=1.",
        selectable_by_all=False,
    ),
    "trace_narrow": BackendCapability(
        name="trace_narrow",
        description="Legacy alias of tl_narrow: real tlsys S-04 Narrow in a disposable store. Requires a trace-architecture checkout and POSIX locking.",
        requires_packages=("sentence_transformers",),
        requires_posix=True,
        needs_network=True,
        cost_class="expensive",
        thread_safe=None,
        thread_safety_notes="Product store/index thread-safety is undeclared; run concurrency=1.",
        selectable_by_all=False,
    ),
}

CUSTOM_CAPABILITY = BackendCapability(
    name="python:...",
    description="Custom user backend. Capabilities unknown until declared.",
    thread_safe=None,
    thread_safety_notes="Custom backends default to NOT thread-safe. Set assume_thread_safe=true "
    "in the backend config only after verifying concurrent retrieve() safety.",
    selectable_by_all=False,
)


def capability_for(name: str) -> BackendCapability:
    """Return the declared capability, or the conservative custom default."""
    if name.startswith("python:"):
        return CUSTOM_CAPABILITY
    return BACKEND_CAPABILITIES.get(
        name,
        BackendCapability(name=name, description="Unregistered engine.", thread_safe=None),
    )


def availability(cap: BackendCapability) -> tuple[bool, list[str]]:
    """Check static availability. Returns (available, missing_reasons)."""
    reasons: list[str] = []
    for package in cap.requires_packages:
        if importlib.util.find_spec(package) is None:
            reasons.append(f"optional package '{package}' is not installed")
    if cap.requires_posix and os.name == "nt":
        reasons.append("requires POSIX locking (run in WSL/Linux)")
    return (not reasons, reasons)


def resolve_backends(selection: str) -> tuple[list[str], list[dict[str, str]]]:
    """Resolve a --baselines selection to explicit engines plus skip reasons.

    `all` selects only cheap, locally runnable, explicitly opted-in engines.
    Expensive, remote, or unknown engines must be named explicitly and are
    reported as skipped-with-reason when unavailable.
    """
    from trace_bench.runner import AVAILABLE_BASELINES

    text = selection.strip()
    if text.lower() == "all":
        selected: list[str] = []
        skipped: list[dict[str, str]] = []
        for name in AVAILABLE_BASELINES:
            cap = capability_for(name)
            if not cap.selectable_by_all:
                skipped.append({"name": name, "reason": f"not in the safe 'all' set ({cap.cost_class}; name it explicitly)"})
                continue
            ok, reasons = availability(cap)
            if not ok:
                skipped.append({"name": name, "reason": "; ".join(reasons)})
                continue
            selected.append(name)
        if not selected:
            raise ValueError("No safe local backends available for 'all': install base dependencies.")
        return selected, skipped
    names = [b.strip() for b in text.split(",") if b.strip()]
    if not names:
        raise ValueError("Empty backend selection.")
    return names, []


def check_concurrency(name: str, concurrency: int, config: dict | None) -> list[str]:
    """Return preflight findings for concurrency vs the thread-safety contract."""
    if concurrency <= 1:
        return []
    cap = capability_for(name)
    if cap.thread_safe is True:
        return []
    if (config or {}).get("assume_thread_safe") is True:
        return [f"warning: {name}: concurrency={concurrency} accepted via explicit assume_thread_safe=true"]
    return [
        f"error: {name}: concurrency={concurrency} but thread-safety is "
        f"{'undeclared' if cap.thread_safe is None else 'not declared safe'} "
        f"({cap.thread_safety_notes or 'no notes'}). Use concurrency=1 or set "
        f"assume_thread_safe=true in this backend's config after verifying safety."
    ]
