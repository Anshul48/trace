"""Command-line interface and fail-closed batch execution engine for the trace-bench suite."""

import concurrent.futures
import importlib
import inspect
import math
import threading
import csv
import importlib.metadata
import json
import os
import platform
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Literal
import click
from rich.console import Console
from rich.table import Table

from trace_bench.datasets.loader import (load_manifest, compute_sha256, file_sha256,
    documents_from_manifest, validate_evaluation_inputs, case_fingerprint, document_fingerprint)
from trace_bench.datasets.portable import load_dataset
from trace_bench.datasets.schema import (
    BenchmarkManifest,
    BenchmarkCase,
    ExecutionMode,
    QueryOutcome,
    ErrorReceipt,
    TraceLiteArtifactIdentity,
    DatasetAdmission,
    SourceMapping,
    ModelProviderFingerprint,
    PreflightError,
    AcquisitionError,
    IndexStageError,
    QueryStageError,
    MetricError,
    ERR_MOCK_PROVIDER_FORBIDDEN,
    ERR_INSECURE_TLS_FORBIDDEN,
    ERR_CHECKSUM_MISMATCH,
    ERR_DATASET_NOT_ADMITTED,
    ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN,
    ERR_MISSING_SOURCE_IDENTITY,
    ERR_EDITABLE_IMPORT_FORBIDDEN,
    ERR_UNAVAILABLE_PROVIDER,
    ERR_INDEX_FAILED,
    ERR_QUERY_FAILED,
    ERR_QUERY_TIMEOUT,
    ERR_UNSUPPORTED_BACKEND,
    ERR_FORCED_FALLBACK_FORBIDDEN,
    ERR_MISSING_EVIDENCE_MAPPING,
    ERR_UNSTABLE_QUERY_PAIRING,
    ERR_FABRICATED_COVERAGE,
    ERR_UNHANDLED_STAGE_FAILURE,
)
from trace_bench.baselines.base import BaseRetriever, IndexedDocument
from trace_bench.baselines.bm25_retriever import BM25Retriever
from trace_bench.baselines.dense_retriever import DenseRetriever
from trace_bench.baselines.hybrid_rrf_retriever import HybridRRFRetriever
from trace_bench.baselines.flat_hierarchy_retriever import FlatHierarchyRetriever
from trace_bench.baselines.trace_retriever import TraceLiteRetriever
from trace_bench.baselines.hipporag_retriever import HippoRagPPRRetriever
from trace_bench.metrics.retrieval import evaluate_case_retrieval, CaseRetrievalMetrics, attach_case_evidence
from trace_bench.metrics.organization import OrganizationMetrics, source_atom_coverage, measure_organization
from trace_bench.metrics.operations import LatencyTracker, MemoryTracker, MemorySampler, StorageTracker, OpsProfile
from trace_bench.metrics.aggregator import (
    BenchmarkAggregator,
    BaselineEvaluationResult,
    BenchmarkRunResult,
    generate_comparison_markdown,
    check_release_gates,
)
from trace_bench.generators.scale_corpus import generate_scale_benchmark, ScaleTier

console = Console()

AVAILABLE_BASELINES: dict[str, type[BaseRetriever] | tuple[type[BaseRetriever], dict]] = {
    "bm25": BM25Retriever,
    "dense": (DenseRetriever, {"model_name": "all-MiniLM-L6-v2"}),
    "dense_bge": (DenseRetriever, {"model_name": "BAAI/bge-large-en-v1.5"}),
    "hybrid_rrf": (HybridRRFRetriever, {"dense_model": "all-MiniLM-L6-v2"}),
    "flat_hierarchy": (FlatHierarchyRetriever, {"dense_model": "all-MiniLM-L6-v2"}),
    "trace_flat": (TraceLiteRetriever, {"mode": "flat", "mock_llm": False}),
    "trace_tree": (TraceLiteRetriever, {"mode": "tree", "mock_llm": False}),
    "trace_hybrid": (TraceLiteRetriever, {"mode": "hybrid", "mock_llm": False}),
    "hipporag_ppr": HippoRagPPRRetriever,
}

# M0a: canonical engine names. trace_narrow is the legacy alias of tl_narrow;
# both select the same TL S-04 Narrow implementation. Recorded selection names
# in old artifacts are never rewritten.
ENGINE_ALIASES: dict[str, str] = {
    "trace_narrow": "tl_narrow",
}


def canonical_engine_name(selection: str) -> str:
    """Resolve a selected engine name to its canonical engine identity."""
    return ENGINE_ALIASES.get(selection, selection)

# DEC-P-001 Admitted Dataset Portfolio
ADMITTED_DATASETS = {
    "scifact", "beir-scifact",
    "nfcorpus", "beir-nfcorpus",
    "fiqa", "beir-fiqa",
    "bright-coding", "bright-math", "bright_coding", "bright_math",
    "multihop_rag", "multihop-multihop_rag",
    "musique", "multihop-musique",
    "ann-scale-10k", "ann-scale-100k", "bigann", "sift1m",
}


def get_hardware_info() -> dict:
    """Collect non-sensitive hardware metadata for reproducible benchmark logs."""
    versions = {}
    for package in ("trace-bench", "numpy", "scipy", "pydantic", "psutil", "sentence-transformers", "torch", "blake3", "pyarrow"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            pass
    package_root = Path(__file__).parent
    source_inventory = [(path.relative_to(package_root).as_posix(), file_sha256(path))
                        for path in sorted(package_root.rglob("*.py"))]
    return {
        "tb_source_sha256": compute_sha256(json.dumps(source_inventory)),
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "processor": platform.processor(),
        "cpu_count": os.cpu_count(),
        "dependency_versions": versions,
        "thread_settings": {k: os.environ[k] for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS") if k in os.environ},
    }


def inspect_tracelite_artifact_identity(mode: ExecutionMode = "regression") -> TraceLiteArtifactIdentity:
    """Inspect Trace-Lite package identity, installation type, and runtime environment."""
    package_name = "trace-lite"
    pkg_version = "unknown"
    is_editable = False
    is_pinned = False
    commit_hash = None
    wheel_hash = None

    try:
        dist = importlib.metadata.distribution(package_name)
        pkg_version = dist.version
        direct_url = dist.read_text("direct_url.json")
        if direct_url:
            data = json.loads(direct_url)
            if data.get("dir_info", {}).get("editable", False):
                is_editable = True
            vcs = data.get("vcs_info", {})
            commit_hash = vcs.get("commit_id")
    except Exception:
        try:
            import trace_lite
            pkg_version = getattr(trace_lite, "__version__", "0.1.0-dev")
            is_editable = True
        except ImportError:
            pass

    is_cert_eligible = (not is_editable) and (pkg_version != "unknown")

    return TraceLiteArtifactIdentity(
        package_name=package_name,
        package_version=pkg_version,
        commit_hash=commit_hash,
        wheel_hash_sha256=wheel_hash,
        python_version=platform.python_version(),
        runtime_platform=platform.platform(),
        dependency_fingerprint_sha256=compute_sha256(platform.python_version() + pkg_version),
        config_hash_sha256="default",
        is_editable=is_editable,
        is_pinned=is_pinned,
        is_certification_eligible=is_cert_eligible,
    )


def validate_certification_preflight(
    manifest: BenchmarkManifest,
    mode: ExecutionMode,
    mock_llm: bool,
    strict_tls: bool = True,
    provider_fingerprint: ModelProviderFingerprint | None = None,
    artifact_identity: TraceLiteArtifactIdentity | None = None,
) -> None:
    """
    Fail-closed preflight validation for certification mode.
    Rejects mock providers, editable imports, missing manifests, unadmitted datasets, insecure TLS.
    """
    if mode != "certification":
        return

    # 1. Reject mock provider in certification
    if mock_llm:
        raise PreflightError(
            error_code=ERR_MOCK_PROVIDER_FORBIDDEN,
            message="Mock LLM provider is strictly forbidden in certification mode.",
            details={"mode": mode, "mock_llm": mock_llm},
        )

    if provider_fingerprint and provider_fingerprint.is_mock:
        raise PreflightError(
            error_code=ERR_MOCK_PROVIDER_FORBIDDEN,
            message=f"Provider fingerprint '{provider_fingerprint.provider}' is flagged as mock in certification mode.",
            details={"provider": provider_fingerprint.provider},
        )

    # 2. Reject insecure TLS
    if not strict_tls:
        raise PreflightError(
            error_code=ERR_INSECURE_TLS_FORBIDDEN,
            message="Insecure TLS (strict_tls=False) is forbidden in certification mode.",
            details={"strict_tls": strict_tls},
        )

    # 3. Check for synthetic data markers in manifest (first, for specific error code)
    if ("synthetic" in manifest.name.lower() or manifest.description.lower().startswith("deterministic")
            or manifest.metadata.get("evidence_type", "").startswith("synthetic")):
        raise PreflightError(
            error_code=ERR_SYNTHETIC_SUBSTITUTION_FORBIDDEN,
            message=f"Synthetic corpus '{manifest.name}' cannot certify production release gates.",
            details={"dataset_name": manifest.name},
        )

    # 4. Check dataset admission under DEC-P-001
    d_name = manifest.name.lower()
    if d_name not in ADMITTED_DATASETS and not any(adm in d_name for adm in ADMITTED_DATASETS):
        raise PreflightError(
            error_code=ERR_DATASET_NOT_ADMITTED,
            message=f"Dataset '{manifest.name}' is not admitted for certification under DEC-P-001. "
                    f"Admitted portfolio: {sorted(list(ADMITTED_DATASETS))}",
            details={"dataset_name": manifest.name},
        )

    # 5. Check artifact source identity and editable imports
    if artifact_identity is not None:
        if artifact_identity.is_editable:
            raise PreflightError(
                error_code=ERR_EDITABLE_IMPORT_FORBIDDEN,
                message="Editable local source import detected. Certification requires pinned wheel / artifact.",
                details={"package": artifact_identity.package_name, "version": artifact_identity.package_version},
            )
        if not artifact_identity.commit_hash and not artifact_identity.wheel_hash_sha256:
            raise PreflightError(
                error_code=ERR_MISSING_SOURCE_IDENTITY,
                message="Missing pinned commit or wheel hash for Trace-Lite package under test.",
                details={"package": artifact_identity.package_name},
            )

    # 6. Verify provider availability if endpoint declared
    if provider_fingerprint and provider_fingerprint.endpoint_url:
        try:
            import httpx
            with httpx.Client(timeout=5.0, verify=True) as client:
                resp = client.get(provider_fingerprint.endpoint_url)
                if resp.status_code >= 500:
                    raise PreflightError(
                        error_code=ERR_UNAVAILABLE_PROVIDER,
                        message=f"Provider endpoint '{provider_fingerprint.endpoint_url}' returned HTTP {resp.status_code}.",
                        details={"endpoint": provider_fingerprint.endpoint_url, "status_code": resp.status_code},
                    )
        except Exception as e:
            if not isinstance(e, PreflightError):
                raise PreflightError(
                    error_code=ERR_UNAVAILABLE_PROVIDER,
                    message=f"Provider endpoint '{provider_fingerprint.endpoint_url}' is unreachable: {e}",
                    details={"endpoint": provider_fingerprint.endpoint_url, "error": str(e)},
                )
            raise


def instantiate_baseline(name: str, mock_llm: bool = False, config: dict | None = None) -> BaseRetriever:
    """Instantiate a baseline retriever instance."""
    if name in ("trace_narrow", "tl_narrow"):
        from trace_bench.baselines.trace_narrow_retriever import TraceNarrowRetriever
        kwargs = dict(config or {})
        kwargs.setdefault("selected_name", name)
        return TraceNarrowRetriever(**kwargs)
    if name.startswith("python:"):
        module_name, class_name = name.removeprefix("python:").rsplit(":", 1)
        cls = getattr(importlib.import_module(module_name), class_name)
        if not issubclass(cls, BaseRetriever):
            raise TypeError("Custom retrievers must inherit BaseRetriever")
        return cls(**(config or {}))
    if name not in AVAILABLE_BASELINES:
        raise ValueError(f"Unknown baseline '{name}'. Available: {list(AVAILABLE_BASELINES.keys())}")
    spec = AVAILABLE_BASELINES[name]
    if isinstance(spec, tuple):
        cls, kwargs = spec
        kwargs_copy = dict(kwargs)
        kwargs_copy.update(config or {})
        if issubclass(cls, TraceLiteRetriever):
            kwargs_copy["mock_llm"] = mock_llm
        return cls(**kwargs_copy)
    return spec(**(config or {}))


def parse_corpus_to_documents(corpus_text: str) -> list[IndexedDocument]:
    """Parse text into indexed paragraphs/documents."""
    paragraphs = [p.strip() for p in corpus_text.split("\n\n") if p.strip()]
    documents: list[IndexedDocument] = []
    for idx, p in enumerate(paragraphs):
        documents.append(
            IndexedDocument(
                doc_id=f"atom-{idx}",
                text=p,
                title="",
                metadata={"paragraph_index": idx},
            )
        )
    return documents


def execute_single_case(
    retriever: BaseRetriever,
    case: BenchmarkCase,
    top_k: int,
    known_ids: set[str] | None = None,
    ignore_identical_ids: bool = False,
) -> tuple[CaseRetrievalMetrics, float, ErrorReceipt | None]:
    """Execute a single evaluation case with fail-closed error capturing."""
    t0 = time.perf_counter()
    receipt: ErrorReceipt | None = None
    try:
        # Retrieve extra candidates when the suite specifies per-query exclusions.
        response = retriever.retrieve_with_outcome(case.query, top_k=top_k + len(case.excluded_doc_ids) + int(ignore_identical_ids))
        candidates = response.candidates
        if response.abstained and candidates:
            raise ValueError("Backend emitted candidates while declaring abstention")
        unique = {}
        excluded = set(case.excluded_doc_ids)
        if ignore_identical_ids:
            excluded.add(case.native_query_id or case.id)
        for candidate in candidates:
            if known_ids is not None and candidate.doc_id not in known_ids:
                raise ValueError(f"Backend emitted unknown document ID: {candidate.doc_id}")
            if not math.isfinite(candidate.score):
                raise ValueError("Backend emitted a non-finite retrieval score")
            if candidate.doc_id not in excluded:
                unique.setdefault(candidate.doc_id, candidate)
        candidates = list(unique.values())[:top_k]
        duration = time.perf_counter() - t0
        retrieved_ids = [c.doc_id for c in candidates]
        is_abstaining = response.abstained

        metric = evaluate_case_retrieval(
            case_id=case.id,
            category=case.category,
            retrieved_ids=retrieved_ids,
            gold_ids=case.gold_atom_ids,
            is_abstaining=is_abstaining,
            expected_abstention=case.expected_abstention,
            relevance_scores=case.relevance_scores,
        )
        metric.retrieved_ids = retrieved_ids
        metric.retrieved_scores = [c.score for c in candidates]
        metric.native_query_id = case.native_query_id or case.id
        metric.backend_receipt = response.receipt
        metric.latency_ms = duration * 1000
        attach_case_evidence(metric, case)
        return metric, duration, None
    except Exception as e:
        duration = time.perf_counter() - t0
        error_code = getattr(e, "error_code", ERR_QUERY_FAILED)
        receipt = ErrorReceipt(
            error_code=error_code,
            stage="query",
            message=f"Query failed on case '{case.id}': {e}",
            manifest_id=case.id,
            fallback_forbidden=True,
            exception_type=e.__class__.__name__,
            details={"case_id": case.id, "query": case.query},
        )
        metric = evaluate_case_retrieval(
            case_id=case.id,
            category=case.category,
            retrieved_ids=[],
            gold_ids=case.gold_atom_ids,
            is_abstaining=False,
            expected_abstention=case.expected_abstention,
            is_error=True,
            error_code=error_code,
        )
        metric.native_query_id = case.native_query_id or case.id
        metric.latency_ms = duration * 1000
        attach_case_evidence(metric, case)
        return metric, duration, receipt


def evaluation_protocol(manifest, top_k, concurrency, warmup_queries):
    return {"version": "tb-evaluation-v2", "top_k": top_k, "concurrency": concurrency,
            "warmup_queries": min(warmup_queries, len(manifest.cases)),
            "ndcg_gain": "linear", "precision_denominator": "k", "deduplication": "first_document_occurrence",
            "split": manifest.metadata.get("split", "fixture"),
            "ignore_identical_ids": manifest.metadata.get("ignore_identical_query_document_ids", False)}


def metric_availability(top_k):
    return {key: top_k >= cutoff for key, cutoff in {
        "recall_at_5": 5, "recall_at_20": 20, "recall_at_100": 100,
        "ndcg_at_10": 10, "ndcg_at_30": 30, "average_precision_at_10": 10,
        "precision_at_5": 5, "complete_gold_coverage_at_10": 10,
        "complete_gold_coverage_at_20": 20, "citation_precision_at_5": 5,
        "mrr": 100}.items()}


class JobControlCancelled(Exception):
    """Raised when a job is cancelled or its deadline passes. Never a query failure."""

    def __init__(self, message: str, kind: str = "cancelled"):
        super().__init__(message)
        self.kind = kind  # "cancelled" | "incomplete"


@dataclass
class JobControl:
    """Cooperative cancellation/deadlines/timeouts for long runs.

    Checked between queries; a hung backend thread is bounded at result
    collection, and hard containment is available via isolated jobs.
    """
    cancel_event: threading.Event | None = None
    per_query_timeout_s: float | None = None
    heartbeat: Callable[[], None] | None = None

    def check(self) -> None:
        if self.cancel_event is not None and self.cancel_event.is_set():
            raise JobControlCancelled("cancel requested", kind="cancelled")
        if self.heartbeat is not None:
            self.heartbeat()


def _zero_baseline(name: str, manifest, receipt: ErrorReceipt, status: str,
                   detail: str) -> BaselineEvaluationResult:
    """A backend that never ran keeps every query in the denominator at zero."""
    failed_metrics = [evaluate_case_retrieval(case.id, case.category, [], case.gold_atom_ids,
        False, case.expected_abstention, is_error=True, error_code=receipt.error_code)
        for case in manifest.cases]
    for metric, case in zip(failed_metrics, manifest.cases):
        metric.native_query_id = case.native_query_id or case.id
        attach_case_evidence(metric, case)
    result = BenchmarkAggregator.aggregate_baseline(name, failed_metrics, error_receipts=[receipt])
    result.status = status
    result.status_detail = detail
    return result


def _timeout_metric(case, timeout: float) -> tuple[CaseRetrievalMetrics, float, ErrorReceipt]:
    """A timed-out query stays in the denominator as an explicit failure."""
    metric = evaluate_case_retrieval(case.id, case.category, [], case.gold_atom_ids,
        False, case.expected_abstention, is_error=True, error_code=ERR_QUERY_TIMEOUT)
    metric.native_query_id = case.native_query_id or case.id
    metric.latency_ms = timeout * 1000
    attach_case_evidence(metric, case)
    receipt = ErrorReceipt(error_code=ERR_QUERY_TIMEOUT, stage="query",
        message=f"Query timed out after {timeout}s on case '{case.id}'",
        manifest_id=case.id, fallback_forbidden=True,
        details={"case_id": case.id, "timeout_s": timeout})
    return metric, timeout, receipt


def _run_query_stage(retriever, manifest, top_k: int, known_ids, ignore_ids: bool,
                     concurrency: int, timeout: float | None, control: JobControl | None,
                     latency_tracker, case_metrics: list, baseline_receipts: list) -> None:
    """Score every case, honoring cooperative cancellation and per-query timeouts."""
    if concurrency > 1:
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=concurrency)
        try:
            if control is not None:
                control.check()
            future_to_case = {
                executor.submit(execute_single_case, retriever, case, top_k, known_ids,
                                ignore_ids): case
                for case in manifest.cases
            }
            results_by_case_id: dict[str, tuple[CaseRetrievalMetrics, float, ErrorReceipt | None]] = {}
            for fut in concurrent.futures.as_completed(future_to_case):
                if control is not None:
                    control.check()
                case = future_to_case[fut]
                try:
                    metric, duration, receipt = fut.result(timeout=timeout)
                except concurrent.futures.TimeoutError:
                    metric, duration, receipt = _timeout_metric(case, timeout or 0.0)
                results_by_case_id[case.id] = (metric, duration, receipt)

            for case in manifest.cases:
                metric, duration, receipt = results_by_case_id[case.id]
                latency_tracker.record(duration)
                case_metrics.append(metric)
                if receipt:
                    baseline_receipts.append(receipt)
        finally:
            # Never hang run completion on a lingering backend thread; a hung
            # thread may outlive the process wait, so use isolation for hard
            # containment of untrusted backends.
            executor.shutdown(wait=False, cancel_futures=True)
    else:
        single = concurrent.futures.ThreadPoolExecutor(max_workers=1) if timeout else None
        try:
            for position, case in enumerate(manifest.cases, 1):
                if control is not None:
                    control.check()
                if single is None:
                    metric, duration, receipt = execute_single_case(retriever, case, top_k, known_ids,
                                                                   ignore_ids)
                else:
                    fut = single.submit(execute_single_case, retriever, case, top_k, known_ids,
                                        ignore_ids)
                    try:
                        metric, duration, receipt = fut.result(timeout=timeout)
                    except concurrent.futures.TimeoutError:
                        metric, duration, receipt = _timeout_metric(case, timeout or 0.0)
                latency_tracker.record(duration)
                case_metrics.append(metric)
                if receipt:
                    baseline_receipts.append(receipt)
                if len(manifest.cases) >= 100 and (position % 100 == 0 or position == len(manifest.cases)):
                    console.print(f"Scored {position:,}/{len(manifest.cases):,} queries ({len(baseline_receipts)} failures).")
        finally:
            if single is not None:
                single.shutdown(wait=False, cancel_futures=True)


def execute_benchmark(
    manifest: BenchmarkManifest,
    corpus_text: str,
    baseline_names: list[str],
    mode: ExecutionMode = "regression",
    top_k: int = 10,
    concurrency: int = 1,
    mock_llm: bool = False,
    strict_tls: bool = True,
    provider_fingerprint: ModelProviderFingerprint | None = None,
    documents: list[IndexedDocument] | None = None,
    baseline_config: dict[str, dict] | None = None,
    warmup_queries: int = 0,
    control: JobControl | None = None,
) -> BenchmarkRunResult:
    """Execute fail-closed benchmark evaluation across specified baselines."""
    if top_k < 1 or concurrency < 1 or warmup_queries < 0 or not baseline_names:
        raise PreflightError("ERR_INVALID_PROTOCOL", "Positive top-K/concurrency and at least one engine are required.")
    if len(baseline_names) != len(set(baseline_names)):
        raise PreflightError("ERR_INVALID_PROTOCOL", "Duplicate engine labels are not allowed.")
    from trace_bench.backends import check_concurrency as _check_concurrency
    for _name in baseline_names:
        for finding in _check_concurrency(_name, concurrency, (baseline_config or {}).get(_name)):
            if finding.startswith("error:"):
                raise PreflightError("ERR_INVALID_PROTOCOL", finding)
            console.print(f"[yellow]{finding}[/yellow]")
    run_id = f"run_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}"
    artifact_identity = inspect_tracelite_artifact_identity(mode=mode)

    # 1. Stage: Preflight Validation
    validate_certification_preflight(
        manifest=manifest,
        mode=mode,
        mock_llm=mock_llm,
        strict_tls=strict_tls,
        provider_fingerprint=provider_fingerprint,
        artifact_identity=artifact_identity,
    )

    documents = documents if documents is not None else documents_from_manifest(manifest, corpus_text)
    validate_evaluation_inputs(manifest, documents)
    known_ids = {d.doc_id for d in documents}
    native_ids = {d.doc_id: str(d.metadata.get("native_doc_id", d.doc_id)) for d in documents}
    is_cert_eligible = (mode == "certification") and manifest.release_authority

    run_result = BenchmarkRunResult(
        run_id=run_id,
        dataset_name=manifest.name,
        dataset_version=manifest.version,
        timestamp=datetime.now(timezone.utc).isoformat(),
        corpus_sha256=manifest.corpus_sha256,
        total_cases=len(manifest.cases),
        cases_sha256=case_fingerprint(manifest),
        indexed_documents_sha256=document_fingerprint(documents),
        protocol=evaluation_protocol(manifest, top_k, concurrency, warmup_queries),
        metric_availability=metric_availability(top_k),
        dataset_provenance=manifest.metadata,
        mode=mode,
        release_authority=manifest.release_authority,
        is_certification_eligible=is_cert_eligible,
        hardware_info=get_hardware_info(),
        artifact_identity=artifact_identity.model_dump(),
        admission=manifest.admission.model_dump() if manifest.admission else {},
        run_schema_version="tb-run-v1",
        comparison_context={},
    )

    from trace_bench.backends import availability as _availability, capability_for as _capability_for
    for b_name in baseline_names:
        console.print(f"[bold cyan]Evaluating baseline ({mode}):[/bold cyan] {b_name} (concurrency={concurrency}) ...")
        if control is not None:
            control.check()
        cap = _capability_for(b_name)
        available, missing = _availability(cap)
        if not available:
            detail = f"Backend '{b_name}' is unavailable: {'; '.join(missing)}"
            receipt = ErrorReceipt(error_code=ERR_UNSUPPORTED_BACKEND, stage="preflight",
                message=detail, fallback_forbidden=True, details={"baseline": b_name})
            run_result.error_receipts.append(receipt.model_dump())
            run_result.baselines[b_name] = _zero_baseline(b_name, manifest, receipt, "unsupported", detail)
            continue
        retriever = None
        pre_target = None
        sampler = MemorySampler()
        sampler.start()

        # 2. Stage: Indexing & Ingestion
        t0 = time.perf_counter()
        mem_before = MemoryTracker.get_current_rss_mb()
        try:
            retriever = instantiate_baseline(b_name, mock_llm=mock_llm, config=(baseline_config or {}).get(b_name))
            pre_target = retriever.target_identity()
            retriever.index(documents)
            index_duration = time.perf_counter() - t0
            for case in manifest.cases[:warmup_queries]:
                _metric, _duration, warmup_receipt = execute_single_case(retriever, case, top_k, known_ids,
                    run_result.protocol["ignore_identical_ids"])
                if warmup_receipt:
                    raise RuntimeError(f"Warmup failed: {warmup_receipt.message}")
        except Exception as e:
            error_code = getattr(e, "error_code", ERR_INDEX_FAILED)
            receipt = ErrorReceipt(
                error_code=error_code,
                stage="index",
                message=f"Indexing failed for baseline '{b_name}': {e}",
                fallback_forbidden=True,
                exception_type=e.__class__.__name__,
                details={"baseline": b_name},
            )
            run_result.error_receipts.append(receipt.model_dump())
            run_result.baselines[b_name] = _zero_baseline(
                b_name, manifest, receipt, "failed", f"Indexing failed for baseline '{b_name}'")
            sampler.stop()
            if retriever is not None:
                cleanup_backend(retriever, b_name, run_result)
            continue

        mem_after = MemoryTracker.get_current_rss_mb()
        console.print(f"Indexed {len(documents):,} documents in {index_duration:.2f}s; scoring {len(manifest.cases):,} queries.")

        # 3. Stage: Query Evaluation & Latency Tracking
        latency_tracker = LatencyTracker()
        case_metrics: list[CaseRetrievalMetrics] = []
        baseline_receipts: list[ErrorReceipt] = []

        timeout = control.per_query_timeout_s if control is not None else None
        q_wall_start = time.perf_counter()
        try:
            _run_query_stage(retriever, manifest, top_k, known_ids,
                             run_result.protocol["ignore_identical_ids"],
                             concurrency, timeout, control,
                             latency_tracker, case_metrics, baseline_receipts)
        except JobControlCancelled:
            sampler.stop()
            cleanup_backend(retriever, b_name, run_result)
            raise

        q_wall_total = time.perf_counter() - q_wall_start
        concurrent_qps = len(manifest.cases) / q_wall_total if q_wall_total > 0 else 0.0

        for metric in case_metrics:
            metric.native_retrieved_ids = [native_ids[i] for i in metric.retrieved_ids]

        # 4. Stage: Ops & Organization Metrics
        lat_summary = latency_tracker.summary()
        ops_profile = OpsProfile(
            total_queries=len(manifest.cases),
            latency_p50_ms=lat_summary["p50"],
            latency_p95_ms=lat_summary["p95"],
            latency_p99_ms=lat_summary["p99"],
            latency_mean_ms=lat_summary["mean"],
            latency_min_ms=lat_summary["min"],
            latency_max_ms=lat_summary["max"],
            ingestion_duration_sec=index_duration,
            ingestion_documents_per_sec=len(documents) / index_duration if index_duration > 0 else 0.0,
            ingestion_atoms_per_sec=len(documents) / index_duration if index_duration > 0 else 0.0,
            peak_memory_rss_mb=sampler.stop(),
        )

        config, identity = {}, {}
        try:
            org_metrics = measure_organization(retriever, documents)
            config = retriever.configuration()
            source_path = inspect.getsourcefile(type(retriever))
            identity = {**retriever.implementation_identity(), "class": f"{type(retriever).__module__}:{type(retriever).__name__}",
                "source_sha256": file_sha256(source_path) if source_path else None,
                "configuration_sha256": compute_sha256(json.dumps(config, sort_keys=True))}
            from trace_bench.datasets.schema import ERR_TARGET_IDENTITY_DRIFT
            from trace_bench.target_identity import compare_target_identity
            post_target = retriever.target_identity()
            verified, note = compare_target_identity(pre_target, post_target)
            identity["target_identity_verified"] = verified
            identity["target_identity_note"] = note
            identity["native_pins"] = retriever.native_pins()
            if verified is False:
                baseline_receipts.append(ErrorReceipt(
                    error_code=ERR_TARGET_IDENTITY_DRIFT, stage="validation",
                    message=f"Target identity drifted during baseline '{b_name}': {note}",
                    details={"baseline": b_name}))
        except Exception as exc:
            org_metrics = OrganizationMetrics(total_source_atoms=len(documents))
            receipt = ErrorReceipt(error_code="ERR_METRIC_FAILED", stage="metric", message=str(exc),
                                   details={"baseline": b_name}, exception_type=type(exc).__name__)
            baseline_receipts.append(receipt)
        finally:
            cleanup_backend(retriever, b_name, run_result)

        base_res = BenchmarkAggregator.aggregate_baseline(
            baseline_name=b_name,
            case_metrics=case_metrics,
            ops_profile=ops_profile,
            org_metrics=org_metrics,
            error_receipts=baseline_receipts,
        )
        base_res.ops["concurrent_qps"] = concurrent_qps
        base_res.configuration = config
        base_res.implementation_identity = identity
        run_result.baselines[b_name] = base_res
        run_result.error_receipts.extend([r.model_dump() for r in baseline_receipts])

    return run_result


def cleanup_backend(retriever, name, run_result):
    try:
        retriever.cleanup()
    except Exception as exc:
        run_result.error_receipts.append(ErrorReceipt(error_code="ERR_CLEANUP_FAILED", stage="validation",
            message=str(exc), details={"baseline": name}, exception_type=type(exc).__name__).model_dump())


def render_summary_table(run_result: BenchmarkRunResult) -> None:
    """Print a Rich terminal table showing benchmark results."""
    table = Table(title=f"Benchmark Results [{run_result.mode.upper()}]: {run_result.dataset_name} ({run_result.total_cases} queries)")
    table.add_column("Engine", style="cyan bold", overflow="fold")
    table.add_column("nDCG@10", justify="right")
    table.add_column("MAP@10", justify="right")
    table.add_column("Recall@20", justify="right")
    table.add_column("p95", justify="right")
    table.add_column("Failures", justify="right")

    for b_name, res in run_result.baselines.items():
        p95_str = f"{res.ops['latency_p95_ms']:.1f}ms" if "latency_p95_ms" in res.ops else "N/A"
        value = lambda field, number: f"{number:.3f}" if run_result.metric_availability.get(field, True) else "N/A"
        table.add_row(
            b_name,
            value("ndcg_at_10", res.overall_ndcg_at_10),
            value("average_precision_at_10", res.overall_map_at_10),
            value("recall_at_20", res.overall_recall_at_20),
            p95_str,
            str(res.failed_cases_count),
        )

    console.print(table)
    if any(result.abstention_cases_count for result in run_result.baselines.values()):
        decisions = Table(title="Explicit abstention decisions")
        for label in ("Engine", "Negative queries", "False accept", "False reject"):
            decisions.add_column(label)
        for name, result in run_result.baselines.items():
            fmt = lambda rate: f"{rate:.1%}" if rate is not None else "N/A"
            decisions.add_row(name, str(result.abstention_cases_count),
                              fmt(result.false_accept_rate), fmt(result.false_reject_rate))
        console.print(decisions)


@click.group()
def cli():
    """Reproducible retrieval comparisons and portable benchmark inputs."""
    pass


@cli.command("run")
@click.option("--dataset", "-d", default="smoke", show_default=True, help="Dataset name, BEIR directory, or TB manifest.")
@click.option("--data-dir", type=click.Path(path_type=Path), help="Dataset cache (or TRACE_BENCH_DATA).")
@click.option("--split", default="test", show_default=True, help="Exact evaluation split; never silently substituted.")
@click.option("--limit", type=click.IntRange(min=1), help="Diagnostic query subset; retains the full corpus.")
@click.option("--config", "config_path", type=click.Path(exists=True, path_type=Path), help="JSON mapping engine names to constructor parameters.")
@click.option("--warmup", default=0, type=click.IntRange(min=0), help="Queries executed before timed evaluation.")
@click.option(
    "--mode",
    "-m",
    default="regression",
    type=click.Choice(["unit", "regression", "exploratory", "certification"]),
    help="Explicit evaluation mode.",
)
@click.option(
    "--baselines",
    "-b",
    default="bm25",
    help="Comma-separated baselines, python:module:Class customs, or 'all' (cheap local safe set only; expensive engines must be named explicitly).",
)
@click.option("--top-k", "-k", default=100, type=click.IntRange(min=1), help="Document retrieval budget.")
@click.option("--concurrency", "-c", default=1, type=click.IntRange(min=1), help="Concurrent worker threads.")
@click.option("--mock-llm/--real-llm", default=False, help="Use mock LLM (prohibited in certification).")
@click.option("--strict-tls/--insecure-tls", default=True, help="Enforce strict TLS (insecure prohibited in certification).")
@click.option("--output-dir", "-o", default="benchmarks/results", help="Directory to store JSON/CSV run logs.")
@click.option("--format", "-f", "out_format", default="all", type=click.Choice(["json", "csv", "all"]), help="Output artifact format.")
@click.option("--compare-to", default=None, help="Optional baseline run JSON to compare against.")
@click.option("--assert-gate", is_flag=True, default=False, help="Fail with code 1 if release gate standards are not met.")
def run_command(
    dataset: str,
    data_dir: Path | None,
    split: str,
    limit: int | None,
    config_path: Path | None,
    warmup: int,
    mode: ExecutionMode,
    baselines: str,
    top_k: int,
    concurrency: int,
    mock_llm: bool,
    strict_tls: bool,
    output_dir: str,
    out_format: str,
    compare_to: str | None,
    assert_gate: bool,
):
    """Run benchmark evaluation over a dataset manifest."""
    try:
        manifest, documents = load_dataset(dataset, data_dir, split, limit)
        config = json.loads(config_path.read_text(encoding="utf-8")) if config_path else {}
    except (OSError, ValueError, PreflightError, AcquisitionError) as exc:
        raise click.ClickException(str(exc)) from exc

    from trace_bench.backends import resolve_backends
    try:
        selected_baselines, skipped = resolve_backends(baselines)
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc
    for skip in skipped:
        console.print(f"[yellow]Skipped '{skip['name']}': {skip['reason']}[/yellow]")
    console.print(f"Selected backends: {', '.join(selected_baselines)}")

    try:
        run_result = execute_benchmark(
            manifest=manifest,
            corpus_text="",
            documents=documents,
            baseline_config=config,
            warmup_queries=warmup,
            baseline_names=selected_baselines,
            mode=mode,
            top_k=top_k,
            concurrency=concurrency,
            mock_llm=mock_llm,
            strict_tls=strict_tls,
        )
    except PreflightError as e:
        console.print(f"[bold red]Preflight Error ({e.error_code}):[/bold red] {e.message}")
        sys.exit(1)

    render_summary_table(run_result)

    out_json = Path(output_dir) / f"{run_result.run_id}.json"
    out_csv = Path(output_dir) / f"{run_result.run_id}.csv"

    if out_format in ("json", "all") or run_result.error_receipts:
        run_result.save_json(out_json)
        console.print(f"[green]Saved JSON artifact to:[/green] {out_json}")

    if out_format in ("csv", "all"):
        run_result.save_csv(out_csv)
        console.print(f"[green]Saved CSV artifact to:[/green] {out_csv}")

    if out_format == "all":
        from trace_bench.reporter import generate_html_report
        run_result.save_trec(output_dir)
        html_path = Path(output_dir) / f"{run_result.run_id}.html"
        html_path.write_text(generate_html_report(run_result), encoding="utf-8")
        console.print(f"[green]Saved HTML and native-ID TREC files to:[/green] {output_dir}")

    if compare_to:
        comp_path = Path(compare_to)
        if comp_path.exists():
            with open(comp_path, "r", encoding="utf-8") as f:
                b_data = json.load(f)
            base_run = BenchmarkRunResult.from_dict(b_data)
            diff_md = generate_comparison_markdown(run_result, base_run)
            console.print("\n" + diff_md)

    if assert_gate:
        console.print(f"\n[bold yellow]Asserting Production Release Gates (mode={mode})...[/bold yellow]")
        all_passed = True
        for b_name, b_res in run_result.baselines.items():
            passed, failures = check_release_gates(b_res, release_authority=manifest.release_authority, mode=mode)
            if passed:
                console.print(f"[bold green][PASS] {b_name}: PASSED ALL RELEASE GATES[/bold green]")
            else:
                console.print(f"[bold red][FAIL] {b_name}: FAILED RELEASE GATES[/bold red]")
                for fail_msg in failures:
                    console.print(f"  - [red]{fail_msg}[/red]")
                all_passed = False

        if not all_passed:
            console.print("[bold red]Release Gate Assertion Failed![/bold red]")
            sys.exit(1)

    if run_result.error_receipts:
        raise click.ClickException("Run contains failures; artifacts were saved. Inspect error_receipts before comparing.")


@cli.command("scale")
@click.option("--tier", "-t", default="1k", type=click.Choice(["1k", "10k", "100k", "1m"]), help="Scale ladder tier.")
@click.option(
    "--baselines",
    "-b",
    default="bm25,dense,hybrid_rrf",
    help="Comma-separated baselines to evaluate.",
)
@click.option("--concurrency", "-c", default=1, type=int, help="Concurrent worker threads.")
@click.option("--seed", "-s", default=42, type=int, help="Deterministic generator random seed.")
@click.option("--top-k", "-k", default=100, type=click.IntRange(min=1), help="Document retrieval budget.")
@click.option("--output-dir", "-o", default="benchmarks/results", help="Directory to store JSON logs.")
def scale_command(tier: ScaleTier, baselines: str, concurrency: int, seed: int, top_k: int, output_dir: str):
    """Run deterministic scale ladder stress benchmark (non-certifying)."""
    console.print(f"[bold yellow]Generating synthetic {tier.upper()} scale benchmark (seed={seed})...[/bold yellow]")
    manifest, corpus_text = generate_scale_benchmark(tier=tier, seed=seed)

    from trace_bench.backends import resolve_backends
    try:
        selected_baselines, skipped = resolve_backends(baselines)
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc
    for skip in skipped:
        console.print(f"[yellow]Skipped '{skip['name']}': {skip['reason']}[/yellow]")

    run_result = execute_benchmark(
        manifest=manifest,
        corpus_text=corpus_text,
        baseline_names=selected_baselines,
        mode="exploratory",
        top_k=top_k,
        concurrency=concurrency,
        mock_llm=False,
    )

    render_summary_table(run_result)
    out_path = Path(output_dir) / f"{run_result.run_id}_scale_{tier}.json"
    run_result.save_json(out_path)
    console.print(f"[green]Saved scale run artifact to:[/green] {out_path}")
    if run_result.error_receipts:
        raise click.ClickException("Scale run contains failures; inspect the saved error receipts.")


@cli.command("compare")
@click.option("--current", "-c", required=True, help="Current run JSON file.")
@click.option("--baseline", "-b", required=True, help="Baseline run JSON file.")
@click.option("--output", "-o", default=None, help="Optional output markdown file.")
@click.option("--current-engine", default=None)
@click.option("--baseline-engine", default=None)
@click.option("--mode", type=click.Choice(["static", "replay", "event_contrast"]), default="static", show_default=True,
              help="Declared comparison mode: static (same frozen inputs), replay (same logical stage), or event_contrast (declared before/after stages).")
def compare_command(current: str, baseline: str, output: str | None, current_engine: str | None, baseline_engine: str | None,
                    mode: str):
    """Compare two benchmark runs with stable query-ID pairing and output a markdown diff report."""
    with open(current, "r", encoding="utf-8") as f:
        c_data = json.load(f)
    with open(baseline, "r", encoding="utf-8") as f:
        b_data = json.load(f)

    c_run = BenchmarkRunResult.from_dict(c_data)
    b_run = BenchmarkRunResult.from_dict(b_data)

    try:
        diff_md = generate_comparison_markdown(c_run, b_run, current_engine, baseline_engine, mode)
    except (ValueError, MetricError, KeyError) as exc:
        raise click.ClickException(str(exc)) from exc
    console.print(diff_md)

    if output:
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(diff_md, encoding="utf-8")
        console.print(f"[green]Saved comparison report to:[/green] {output}")


@cli.command("setup")
@click.option(
    "--dataset",
    "-d",
    required=True,
    help="BEIR name, bright-<official-task>, or 'all' (= the three BEIR starters scifact/nfcorpus/fiqa only).",
)
@click.option("--cache-dir", "--data-dir", "cache_dir", default=None, help="Dataset cache (or TRACE_BENCH_DATA).")
@click.option("--split", default="test", show_default=True)
@click.option("--output-dir", default=None, type=click.Path(path_type=Path))
def setup_command(dataset: str, cache_dir: str | None, split: str, output_dir: Path | None):
    """Freeze an explicit BEIR/BRIGHT split, reusing data before downloading."""
    from trace_bench.datasets.commands import prepare_public
    targets = ["scifact", "nfcorpus", "fiqa"] if dataset == "all" else [dataset]
    if len(targets) > 1 and output_dir:
        raise click.ClickException("Choose one dataset when supplying --output-dir.")
    for target in targets:
        try:
            console.print(f"Prepared: {prepare_public(target, cache_dir, split, output_dir)}")
        except (OSError, ValueError, RuntimeError, AcquisitionError, PreflightError) as exc:
            raise click.ClickException(str(exc)) from exc


@cli.command("report")
@click.option("--run", "-r", required=True, help="Benchmark run JSON file path.")
@click.option("--baseline", "-b", default=None, help="Optional reference run JSON file for paired significance comparison.")
@click.option("--output", "-o", default=None, help="Output HTML file path (default: run_id.html in results dir).")
def report_command(run: str, baseline: str | None, output: str | None):
    """Generate a standalone interactive HTML benchmark report with SVG charts."""
    from trace_bench.reporter import generate_html_report

    run_path = Path(run)
    with open(run_path, "r", encoding="utf-8") as f:
        run_data = json.load(f)
    run_result = BenchmarkRunResult.from_dict(run_data)

    baseline_run = None
    if baseline:
        b_path = Path(baseline)
        if b_path.exists():
            with open(b_path, "r", encoding="utf-8") as f:
                b_data = json.load(f)
            baseline_run = BenchmarkRunResult.from_dict(b_data)

    html_content = generate_html_report(run_result, baseline_run=baseline_run)

    out_file = Path(output) if output else (run_path.parent / f"{run_result.run_id}_report.html")
    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text(html_content, encoding="utf-8")
    console.print(f"[bold green][OK] Generated interactive HTML report:[/bold green] {out_file}")


@cli.command("quickstart")
@click.option("--output-dir", default="benchmarks/results/quickstart", type=click.Path(path_type=Path))
@click.pass_context
def quickstart_command(context, output_dir):
    """Run the bundled offline smoke suite and write JSON, CSV, TREC and HTML."""
    context.invoke(run_command, dataset="smoke", baselines="bm25", output_dir=str(output_dir))


@cli.command("score")
@click.option("--dataset", required=True)
@click.option("--data-dir", type=click.Path(path_type=Path))
@click.option("--split", default="test")
@click.option("--run-file", required=True, type=click.Path(exists=True, path_type=Path))
@click.option("--engine", default="external")
@click.option("--top-k", default=100, type=click.IntRange(min=1))
@click.option("--output-dir", default="benchmarks/results", type=click.Path(path_type=Path))
def score_command(dataset, data_dir, split, run_file, engine, top_k, output_dir):
    """Score an external TREC file; missing queries remain in the denominator."""
    from trace_bench.metrics.interchange import score_trec
    try:
        manifest, docs = load_dataset(dataset, data_dir, split)
        result = score_trec(manifest, docs, run_file, engine, top_k)
        result.save_json(output_dir / f"{result.run_id}.json")
        result.save_csv(output_dir / f"{result.run_id}.csv")
        render_summary_table(result)
        click.echo(f"Saved: {output_dir / (result.run_id + '.json')}")
        click.echo("TREC input supplies no latency, memory, organization or explicit abstention measurements.")
    except (OSError, ValueError, PreflightError, AcquisitionError) as exc:
        raise click.ClickException(str(exc)) from exc


@cli.group("recipe")
def recipe_command():
    """Versioned run recipes: dry-run, preflight, and resumable job execution."""


@recipe_command.command("list")
def recipe_list():
    """List shipped recipe presets usable by name with --recipe."""
    from trace_bench.presets import list_presets
    for name in list_presets():
        click.echo(name)


@recipe_command.command("show")
@click.argument("name")
def recipe_show(name: str):
    """Print a shipped preset's JSON (NAME with or without .json)."""
    from trace_bench.presets import preset_text
    try:
        click.echo(preset_text(name))
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc


@recipe_command.command("dry-run")
@click.option("--recipe", "recipe_path", required=True, metavar="PATH|PRESET",
              help="Recipe file path or shipped preset name (see 'recipe list').")
def recipe_dry_run(recipe_path: str):
    """Expand a recipe to job units without downloads or indexing."""
    from trace_bench.recipes import dry_run_text, load_recipe
    try:
        click.echo(dry_run_text(load_recipe(recipe_path)))
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@recipe_command.command("preflight")
@click.option("--recipe", "recipe_path", required=True, metavar="PATH|PRESET",
              help="Recipe file path or shipped preset name (see 'recipe list').")
def recipe_preflight(recipe_path: str):
    """Check datasets, backends, thread-safety, and disk before running."""
    from trace_bench.recipes import load_recipe, preflight
    try:
        findings = preflight(load_recipe(recipe_path))
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    for line in findings:
        click.echo(line)
    if any(line.startswith("error:") for line in findings):
        raise click.ClickException("Preflight found blocking errors; see above.")


@recipe_command.command("run")
@click.option("--recipe", "recipe_path", required=True, metavar="PATH|PRESET",
              help="Recipe file path or shipped preset name (see 'recipe list').")
@click.option("--job-dir", required=True, type=click.Path(path_type=Path),
              help="New job directory for persistent attempt records.")
@click.option("--isolate/--no-isolate", default=False,
              help="Run each backend in a subprocess for isolated resource measurement.")
@click.option("--resume/--no-resume", default=True,
              help="Resume verified successful units (default) or re-run everything.")
def recipe_run(recipe_path: str, job_dir: Path, isolate: bool, resume: bool):
    """Execute a recipe as a persistent, resumable job."""
    from trace_bench.jobs import create_job, run_job
    from trace_bench.recipes import load_recipe
    try:
        recipe = load_recipe(recipe_path)
        if not (job_dir / "job.json").exists():
            create_job(recipe, job_dir, isolate=isolate)
            console.print(f"[green]Created job:[/green] {job_dir}")
        summary = run_job(job_dir, resume=resume)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    for unit_id, status in summary["units"].items():
        console.print(f"  {unit_id}: {status}")
    console.print(f"Job status: {summary['job_status']}")


@cli.group("job")
def job_command():
    """Inspect and cancel persistent recipe jobs."""


@job_command.command("status")
@click.option("--job-dir", required=True, type=click.Path(exists=True, path_type=Path))
def job_status_command(job_dir: Path):
    """Show per-unit outcomes without executing anything."""
    try:
        version = json.loads((job_dir / "job.json").read_text(encoding="utf-8")).get("version")
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    try:
        if version == "tb-workload-job-v1":
            from trace_bench.workloads.jobs import workload_job_status

            summary = workload_job_status(job_dir)
            click.echo(f"Job {summary['job_id']} (workload {summary['workload']})")
        else:
            from trace_bench.jobs import job_status

            summary = job_status(job_dir)
            click.echo(f"Job {summary['job_id']} (recipe {summary['recipe']})")
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    for unit_id, status in summary["units"].items():
        click.echo(f"  {unit_id}: {status}")
    if summary["cancel_requested"]:
        click.echo("Cancel requested.")


@job_command.command("cancel")
@click.option("--job-dir", required=True, type=click.Path(exists=True, path_type=Path))
def job_cancel_command(job_dir: Path):
    """Request cancellation of a running job (checked between queries)."""
    from trace_bench.jobs import request_cancel
    request_cancel(job_dir)
    click.echo(f"Cancel requested for {job_dir}")


@job_command.command("clear-cancel")
@click.option("--job-dir", required=True, type=click.Path(exists=True, path_type=Path))
def job_clear_cancel_command(job_dir: Path):
    """Clear a cancellation marker so a later resume may proceed."""
    from trace_bench.jobs import clear_cancel
    click.echo("Cancellation cleared." if clear_cancel(job_dir) else "No cancellation marker present.")


@cli.command("run-unit", hidden=True)
@click.option("--job-dir", required=True, type=click.Path(exists=True, path_type=Path))
@click.option("--unit-id", required=True)
def run_unit_command(job_dir: Path, unit_id: str):
    """Execute exactly one job unit (worker entrypoint for isolated jobs)."""
    from trace_bench.jobs import run_unit
    try:
        record = run_unit(job_dir, unit_id)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(f"{unit_id}: {record['status']}")


@cli.command("backends")
def backends_command():
    """List engines with capability, platform, dependency, and cost declarations."""
    from trace_bench.backends import BACKEND_CAPABILITIES, availability
    for name in sorted(set(BACKEND_CAPABILITIES) | set(AVAILABLE_BASELINES)):
        cap = BACKEND_CAPABILITIES.get(name)
        if cap is None:
            click.echo(f"{name:16} undeclared backend (custom defaults apply)")
            continue
        ok, reasons = availability(cap)
        state = "ready" if ok else f"unavailable: {'; '.join(reasons)}"
        threads = {True: "thread-safe", False: "not thread-safe", None: "thread-safety undeclared"}[cap.thread_safe]
        click.echo(f"{name:16} {cap.cost_class:9} {threads:24} {state}")
        click.echo(f"{'':16} {cap.description}")
    click.echo("Custom backends: --baselines python:module:Class (not in 'all'; concurrency=1 unless verified).")


@cli.group("capsule")
def capsule_command():
    """Portable versioned result capsules: pack, unpack, verify, and report."""


@capsule_command.command("pack")
@click.option("--run", "run_path", required=True, type=click.Path(exists=True, path_type=Path))
@click.option("--output", required=True, type=click.Path(path_type=Path))
@click.option("--trec-dir", default=None, type=click.Path(exists=True, path_type=Path))
@click.option("--job-dir", default=None, type=click.Path(exists=True, path_type=Path))
@click.option("--include-inputs-from", default=None, type=click.Path(exists=True, path_type=Path),
              help="Prepared snapshot dir whose manifest/corpus/checksums travel with the capsule.")
def capsule_pack(run_path: Path, output: Path, trec_dir, job_dir, include_inputs_from):
    """Pack a run artifact and its evidence into a tb-capsule-v1 archive."""
    from trace_bench.capsule import pack
    try:
        pack(run_path, output, trec_dir=trec_dir, job_dir=job_dir,
             include_inputs_from=include_inputs_from)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@capsule_command.command("unpack")
@click.option("--archive", required=True, type=click.Path(exists=True, path_type=Path))
@click.option("--output-dir", required=True, type=click.Path(path_type=Path))
def capsule_unpack(archive: Path, output_dir: Path):
    """Validate and unpack a capsule (refuses overwrites, unsafe paths, corruption)."""
    from trace_bench.capsule import unpack
    try:
        click.echo(unpack(archive, output_dir))
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@capsule_command.command("verify")
@click.option("--path", "target", required=True, type=click.Path(exists=True, path_type=Path),
              help="Capsule archive or unpacked capsule directory.")
def capsule_verify(target: Path):
    """Validate a capsule and report findings."""
    from trace_bench.capsule import verify
    try:
        findings = verify(target)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    for line in findings:
        click.echo(line)
    if findings:  # verify() returns [] exactly when the capsule is valid
        raise click.ClickException("Capsule verification failed.")


@capsule_command.command("report")
@click.option("--capsule", "capsule_dir", required=True, type=click.Path(exists=True, path_type=Path))
@click.option("--baseline-capsule", default=None, type=click.Path(exists=True, path_type=Path))
@click.option("--output", required=True, type=click.Path(path_type=Path))
def capsule_report(capsule_dir: Path, baseline_capsule: Path | None, output: Path):
    """Regenerate the authoritative HTML report from an unpacked capsule."""
    from trace_bench.capsule import report
    try:
        report(capsule_dir, output, baseline_capsule)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(output)


@cli.command("view")
@click.option("--run", "run_path", default=None, type=click.Path(exists=True, path_type=Path),
              help="Run JSON file or unpacked capsule directory.")
@click.option("--baseline", default=None, type=click.Path(exists=True, path_type=Path))
@click.option("--output", required=True, type=click.Path(path_type=Path))
def view_command(run_path: Path | None, baseline: Path | None, output: Path):
    """Build the self-contained offline TB viewer for a run artifact."""
    from trace_bench.viewer import STATIC_VIEWER_HTML, build_viewer_html
    try:
        if run_path is None:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(STATIC_VIEWER_HTML, encoding="utf-8")
        else:
            build_viewer_html(run_path, output, baseline)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(output)


@cli.group("lifecycle")
def lifecycle_command():
    """Event-workload lifecycle evaluation (reference mechanics, not product capability)."""


@lifecycle_command.command("list")
def lifecycle_list():
    """List frozen fixtures and available lifecycle backends."""
    from trace_bench.lifecycle import BACKEND_REGISTRY
    from trace_bench.lifecycle.fixtures import list_fixtures
    click.echo("Fixtures: " + ", ".join(list_fixtures()))
    click.echo("Backends: " + ", ".join(sorted(BACKEND_REGISTRY)))
    click.echo("Trace product lifecycle interfaces: unsupported (see docs/LIFECYCLE.md).")


@lifecycle_command.command("run")
@click.option("--fixture", required=True, help="Frozen fixture name.")
@click.option("--backend", default="reference", help="Lifecycle backend name.")
@click.option("--output-dir", required=True, type=click.Path(path_type=Path))
def lifecycle_run(fixture: str, backend: str, output_dir: Path):
    """Replay a frozen event workload and report named checks."""
    from trace_bench.lifecycle import BACKEND_REGISTRY
    from trace_bench.lifecycle.fixtures import get_fixture
    from trace_bench.lifecycle.runner import run_lifecycle
    try:
        workload = get_fixture(fixture)
    except KeyError as exc:
        raise click.ClickException(str(exc)) from exc
    if backend not in BACKEND_REGISTRY:
        raise click.ClickException(f"Unknown lifecycle backend '{backend}'. "
                                   f"Available: {', '.join(sorted(BACKEND_REGISTRY))}")
    try:
        result = run_lifecycle(workload, BACKEND_REGISTRY[backend](), output_dir)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    for item in result.checks:
        mark = "PASS" if item.passed else "FAIL"
        console.print(f"  [{mark}] {item.name}")
    console.print(f"Lifecycle result: {'all checks passed' if result.all_passed else 'FAILURES present'}")
    if not result.all_passed:
        raise click.ClickException("Lifecycle checks failed; see the saved result JSON.")


@cli.group("workload")
def workload_command():
    """W1-W4 self-organization workloads (offline, wheel-bundled fixtures)."""


@workload_command.command("list")
def workload_list():
    """List workloads with their fixture x backend arm matrix."""
    from trace_bench.workloads.runner import BACKEND_NOTES, build_plan

    from trace_bench.workloads import WORKLOADS

    for workload in WORKLOADS:
        plan = build_plan(workload)
        fixtures = sorted({s.fixture for s in plan})
        backends = sorted({s.backend for s in plan})
        click.echo(f"{workload}: {len(plan)} arms; fixtures {', '.join(fixtures)}")
        click.echo(f"  backends: {', '.join(backends)}")
    click.echo("Backend notes:")
    for name in sorted(BACKEND_NOTES):
        click.echo(f"  {name}: {BACKEND_NOTES[name]}")


@workload_command.command("run")
@click.option("--workload", "workload", required=True,
              type=click.Choice(["w1", "w2", "w3", "w4"]),
              help="Workload matrix to execute.")
@click.option("--output-dir", required=True, type=click.Path(path_type=Path),
              help="Directory for the result envelope (refuses to overwrite).")
@click.option("--backends", default=None,
              help="Comma-separated backend subset (default: full matrix).")
@click.option("--seed", default=42, type=int, show_default=True)
@click.option("--max-docs", default=None, type=click.IntRange(min=1),
              help="Budget ceiling: max fixture docs per arm (refuses, never truncates).")
@click.option("--top-k-max", default=None, type=click.IntRange(min=1),
              help="Budget ceiling: max query top_k (refuses, never truncates).")
@click.option("--deadline-s", default=None, type=float,
              help="Stop starting new arms after SECONDS (records incomplete).")
@click.option("--job-dir", default=None, type=click.Path(path_type=Path),
              help="Persistent job dir: per-arm attempt history, resume, drift checks.")
@click.option("--resume/--no-resume", default=True, show_default=True,
              help="With --job-dir: resume verified arms (default) or re-run all.")
def workload_run(workload: str, output_dir: Path, backends: str | None,
                 seed: int, max_docs: int | None, top_k_max: int | None,
                 deadline_s: float | None, job_dir: Path | None, resume: bool):
    """Run a W1-W4 matrix into a tb-workload-result-v1 envelope."""
    from trace_bench.workloads.runner import run_workload, save_envelope

    budgets: dict = {}
    if max_docs is not None:
        budgets["max_docs_per_arm"] = max_docs
    if top_k_max is not None:
        budgets["top_k_max"] = top_k_max
    if deadline_s is not None:
        budgets["deadline_s"] = deadline_s
    chosen = [b.strip() for b in backends.split(",")] if backends else None
    try:
        if job_dir is not None:
            from trace_bench.workloads.jobs import create_workload_job, run_workload_job

            if not (job_dir / "job.json").exists():
                create_workload_job(workload, job_dir, backends=chosen,
                                    budgets=budgets or None, seed=seed)
                click.echo(f"Created workload job: {job_dir}")
            summary = run_workload_job(job_dir, output_dir, resume=resume)
            for unit_id, status in summary["units"].items():
                click.echo(f"  {unit_id}: {status}")
            click.echo(f"Job status: {summary['job_status']}")
            if summary["envelope"] is None:
                raise click.ClickException(
                    "Not all arms verified; envelope withheld. "
                    "See 'trace-bench job status --job-dir DIR'.")
            click.echo(f"Saved: {summary['envelope']}")
            return
        envelope = run_workload(workload, backends=chosen,
                                budgets=budgets or None, seed=seed)
        target = save_envelope(envelope, output_dir)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(f"Saved: {target}")
    click.echo(f"Verdict: {envelope['verdict']} "
               f"({len(envelope['arms_met'])}/{len(envelope['arms'])} arms met)")


@workload_command.command("show")
@click.option("--result", "result_path", required=True,
              type=click.Path(exists=True, path_type=Path),
              help="tb-workload-result-v1 or tb-hv-result-v1 envelope.")
def workload_show(result_path: Path):
    """Render a workload/HV envelope in the terminal (read-only)."""
    from trace_bench.workloads.show import load_envelope, render_envelope

    try:
        click.echo(render_envelope(load_envelope(result_path)), nl=False)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@cli.group("hv")
def hv_command():
    """Opt-in HV profile retrieval (explicit package, explicit cohort)."""


@hv_command.command("tasks")
@click.option("--package-dir", "package", required=True,
              help="HV package directory, or bundled:demo for the wheel-bundled route demo.")
@click.option("--data-dir", type=click.Path(path_type=Path),
              help="Dataset cache (or TRACE_BENCH_DATA).")
def hv_tasks(package: str, data_dir: Path | None):
    """List M4 tasks with gold-resolution classes and query-source readiness."""
    from trace_bench.workloads.hv import list_tasks

    try:
        entries = list_tasks(package, data_dir)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    for entry in entries:
        click.echo(f"{entry['task']}: queries={entry['queries']} "
                     f"gold={json.dumps(entry['gold_links'], sort_keys=True)}")
        click.echo(f"  query source: {entry['native_query_source'] or entry['split_or_reason']}; "
                     f"{entry['readiness']}")


@hv_command.command("preflight")
@click.option("--package-dir", "package", required=True)
@click.option("--task", required=True, help="M4 task id (see 'hv tasks').")
@click.option("--cohort", "cohort_spec", required=True,
              help="full | shard:ID | stratum:NAME | max-docs:N (explicit denominators).")
@click.option("--query-source", default=None,
              help="Prepared snapshot name, query JSONL path, or bundled:demo.")
@click.option("--top-k", default=10, type=click.IntRange(min=1), show_default=True)
@click.option("--data-dir", type=click.Path(path_type=Path))
@click.option("--memory-mb", default=None, type=float,
              help="Refuse when the estimated peak exceeds this budget.")
def hv_preflight(package: str, task: str, cohort_spec: str,
                 query_source: str | None, top_k: int,
                 data_dir: Path | None, memory_mb: float | None):
    """Check package/tasks/queries/resources before any indexing (offline)."""
    from trace_bench.workloads.hv import preflight

    findings = preflight(package, task, cohort_spec, query_source,
                         top_k, data_dir, memory_mb)
    for line in findings:
        click.echo(line)
    if any(line.startswith("error:") for line in findings):
        raise click.ClickException("Preflight found blocking errors; see above.")


@hv_command.command("run")
@click.option("--package-dir", "package", required=True)
@click.option("--task", required=True, help="M4 task id (see 'hv tasks').")
@click.option("--cohort", "cohort_spec", required=True,
              help="full | shard:ID | stratum:NAME | max-docs:N (explicit denominators).")
@click.option("--output-dir", required=True, type=click.Path(path_type=Path),
              help="NEW directory for the envelope + run.json (refuses existing).")
@click.option("--query-source", default=None,
              help="Prepared snapshot name, query JSONL path, or bundled:demo.")
@click.option("--top-k", default=10, type=click.IntRange(min=1), show_default=True)
@click.option("--data-dir", type=click.Path(path_type=Path))
@click.option("--memory-mb", default=None, type=float)
@click.option("--max-doc-bytes", default=None, type=click.IntRange(min=1),
              help="Refuse oversized shard rows (default: tier ceiling).")
def hv_run(package: str, task: str, cohort_spec: str, output_dir: Path,
           query_source: str | None, top_k: int, data_dir: Path | None,
           memory_mb: float | None, max_doc_bytes: int | None):
    """Run opt-in HV retrieval (streaming BM25, bounded memory)."""
    from trace_bench.workloads.hv import run_hv_retrieval

    try:
        envelope = run_hv_retrieval(package, task, cohort_spec, output_dir,
                                    query_source, top_k, data_dir,
                                    memory_mb, max_doc_bytes)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    denom = envelope["denominators"]
    click.echo(f"Saved: {output_dir}")
    click.echo(f"docs encountered={denom['docs_encountered']} "
               f"indexed={denom['docs_indexed']} "
               f"withheld={denom['docs_withheld']}; "
               f"queries scored={len(envelope['queries']['scored'])}")


from trace_bench.datasets.commands import datasets_command, doctor_command
cli.add_command(datasets_command)
cli.add_command(doctor_command)


if __name__ == "__main__":
    cli()
