"""Offline self-contained viewer for benchmark run artifacts.

The viewer renders recorded numbers only: every score, interval, and verdict is
computed at build time in Python (reusing the authoritative
:mod:`trace_bench.metrics.aggregator` functions) and embedded into one HTML
file. The page has zero external references, performs no network access, and
runs when opened directly from disk with networking disabled.

``STATIC_VIEWER_HTML`` is the same page without embedded data: it offers a
local file loader (FileReader only) that validates the shape/version of an
imported ``run.json``/``capsule.json`` and renders recorded values without
scoring anything.
"""

from __future__ import annotations

import html
import json
from pathlib import Path

from trace_bench.metrics.aggregator import (
    BenchmarkRunResult,
    compute_paired_statistics,
    validate_comparison,
)

PAIRED_METRICS: tuple[tuple[str, str], ...] = (
    ("MAP@10", "average_precision_at_10"),
    ("P@5", "precision_at_5"),
    ("Recall@5", "recall_at_5"),
    ("Recall@20", "recall_at_20"),
    ("nDCG@10", "ndcg_at_10"),
    ("Complete Coverage@10", "complete_gold_coverage_at_10"),
    ("Returned relevance@5", "citation_precision_at_5"),
    ("MRR", "mrr"),
    ("Abstention Accuracy", "abstention_accuracy"),
)

_OUTCOME_LABELS = {
    "success": "success",
    "explicit_abstention": "explicit abstention",
    "empty_result": "empty result",
    "query_failed": "query failed",
    "excluded": "excluded",
}

_NOT_COMPUTED = "not computed \u2014 regenerate with trace-bench"


def _esc(value) -> str:
    if value is None:
        return ""
    return html.escape(str(value), quote=True)


def _num(value, ndigits: int = 3) -> str:
    if value is None:
        return '<span class="st-unknown">unknown</span>'
    try:
        return f"{float(value):.{ndigits}f}"
    except (TypeError, ValueError):
        return '<span class="st-unknown">unknown</span>'


def _int_or_unknown(value) -> str:
    if value is None:
        return '<span class="st-unknown">unknown</span>'
    try:
        return str(int(value))
    except (TypeError, ValueError):
        return '<span class="st-unknown">unknown</span>'


def _na_not_measured() -> str:
    return '<span class="st-na">N/A (not measured)</span>'


def _percentile(sorted_values: list[float], pct: float) -> float:
    if not sorted_values:
        raise ValueError("no samples")
    if len(sorted_values) == 1:
        return sorted_values[0]
    rank = (pct / 100.0) * (len(sorted_values) - 1)
    low = int(rank)
    high = min(low + 1, len(sorted_values) - 1)
    frac = rank - low
    return sorted_values[low] * (1.0 - frac) + sorted_values[high] * frac


def _latency_stats(cases: list[dict]) -> dict | None:
    samples = [
        float(case["latency_ms"])
        for case in cases
        if isinstance(case.get("latency_ms"), (int, float))
    ]
    if not samples:
        return None
    ordered = sorted(samples)
    return {
        "count": len(samples),
        "mean": sum(samples) / len(samples),
        "p50": _percentile(ordered, 50),
        "p95": _percentile(ordered, 95),
        "p99": _percentile(ordered, 99),
        "min": ordered[0],
        "max": ordered[-1],
        "samples": samples,
    }


def _histogram_html(samples: list[float], bins: int = 10) -> str:
    if not samples:
        return _na_not_measured()
    low, high = min(samples), max(samples)
    width = (high - low) / bins if high > low else 1.0
    counts = [0] * bins
    for value in samples:
        index = min(int((value - low) / width), bins - 1) if width else 0
        counts[index] += 1
    peak = max(counts) or 1
    bars = []
    for index, count in enumerate(counts):
        height = max(2, int(64 * count / peak)) if count else 2
        edge = low + width * index
        bars.append(
            f'<div class="hbar" style="height:{height}px" '
            f'title="{edge:.2f} ms: {count} queries"></div>'
        )
    return (
        f'<div class="hist">{"".join(bars)}</div>'
        f'<div class="hist-axis"><span>{low:.1f} ms</span>'
        f"<span>n=" + str(len(samples)) + "</span>"
        f"<span>{high:.1f} ms</span></div>"
    )


def _load_run_document(source) -> dict:
    if isinstance(source, dict):
        return source
    path = Path(source)
    if path.is_dir():
        path = path / "run.json"
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or "baselines" not in raw:
        raise ValueError(f"Not a run artifact: {path}")
    return raw


def _case_query_id(case: dict) -> str:
    return str(case.get("native_query_id") or case.get("case_id") or "unknown")


def _case_retrieved(case: dict) -> list[str]:
    ids = case.get("native_retrieved_ids") or case.get("retrieved_ids") or []
    return [str(item) for item in ids]


def _case_gold(case: dict) -> list[str] | None:
    for key in ("native_gold_doc_ids", "native_gold_ids", "gold_atom_ids", "gold_ids"):
        if case.get(key):
            return [str(item) for item in case[key]]
    return None


def _outcome_badge(outcome: str | None) -> str:
    label = _OUTCOME_LABELS.get(outcome or "", None)
    if label is None:
        return f'<span class="badge st-unknown">unknown: {_esc(outcome)}</span>'
    css = {
        "success": "b-success",
        "explicit_abstention": "b-abstain",
        "empty_result": "b-empty",
        "query_failed": "b-failed",
        "excluded": "b-excluded",
    }[outcome or "success"]
    return f'<span class="badge {css}">{_esc(label)}</span>'


def _comparison_at_build(current: dict, baseline: dict) -> dict:
    """Run validate_comparison + paired stats in Python; JS only renders this."""
    current_run = BenchmarkRunResult.from_dict(current)
    baseline_run = BenchmarkRunResult.from_dict(baseline)
    try:
        validate_comparison(current_run, baseline_run)
    except Exception as exc:  # comparison refused: embed the reason, not scores
        return {
            "compatible": False,
            "reason": f"{type(exc).__name__}: {exc}",
            "engines": {},
        }
    engines: dict[str, dict] = {}
    for name in sorted(set(current_run.baselines) & set(baseline_run.baselines)):
        c_base = current_run.baselines[name]
        b_base = baseline_run.baselines[name]
        per_metric: dict[str, dict] = {}
        for label, field in PAIRED_METRICS:
            if not current.get("metric_availability", {}).get(field, True):
                continue
            if field == "abstention_accuracy" and not (
                c_base.abstention_evaluated and b_base.abstention_evaluated
            ):
                continue
            positive_only = field != "abstention_accuracy"
            c_map = {
                item["case_id"]: float(item.get(field, 0.0))
                for item in c_base.case_results
                if item.get("outcome") != "excluded"
                and (not positive_only or item.get("is_positive_query", True))
            }
            b_map = {
                item["case_id"]: float(item.get(field, 0.0))
                for item in b_base.case_results
                if item.get("outcome") != "excluded"
                and (not positive_only or item.get("is_positive_query", True))
            }
            try:
                per_metric[label] = compute_paired_statistics(c_map, b_map)
            except Exception as exc:  # unstable pairing: record, do not score
                per_metric[label] = {"error": f"{type(exc).__name__}: {exc}"}
        engines[name] = per_metric
    return {"compatible": True, "reason": None, "engines": engines}


def _header_html(run: dict) -> str:
    protocol = run.get("protocol") or {}
    badges = [
        f"Dataset: {run.get('dataset_name', 'unknown')} v{run.get('dataset_version', '?')}",
        f"Run: {run.get('run_id', 'unknown')}",
        f"Queries: {run.get('total_cases', 'unknown')}",
        f"Mode: {run.get('mode', 'unknown')}",
        f"top_k={protocol.get('top_k', '?')}",
        f"corpus {str(run.get('corpus_sha256', '?'))[:12]}...",
        "release authority" if run.get("release_authority") else "no release authority",
        "certification eligible" if run.get("is_certification_eligible") else "not certified",
    ]
    items = "".join(f'<span class="badge">{_esc(item)}</span>' for item in badges)
    return (
        "<header><h2>Trace-Bench Offline Viewer</h2>"
        f'<p class="sub">Recorded results for {_esc(run.get("dataset_name", "?"))} '
        f"&mdash; rendered offline from embedded data.</p>"
        f'<div class="badges">{items}</div></header>'
    )


def _comparison_panel_html(
    run: dict, baseline: dict | None, comparison: dict | None
) -> str:
    if baseline is None or comparison is None:
        return (
            '<section class="card"><h3>Comparison compatibility</h3>'
            "<p>Single run &mdash; no baseline attached. Attach a baseline at build "
            "time or load two files below for a fingerprint check.</p></section>"
        )
    if not comparison.get("compatible"):
        return (
            '<section class="card"><h3>Comparison compatibility</h3>'
            '<p><span class="badge b-failed">comparison refused</span></p>'
            f"<p>{_esc(comparison.get('reason') or 'unknown reason')}</p></section>"
        )
    rows = []
    for engine in sorted(comparison.get("engines", {})):
        for label, stats in comparison["engines"][engine].items():
            if "error" in stats:
                rows.append(
                    f"<tr><td>{_esc(engine)}</td><td>{_esc(label)}</td>"
                    f"<td colspan='4'>{_esc(stats['error'])}</td></tr>"
                )
                continue
            delta = stats.get("delta", 0.0)
            rows.append(
                f"<tr><td>{_esc(engine)}</td><td>{_esc(label)}</td>"
                f"<td>{delta:+.3f}</td>"
                f"<td>[{_num(stats.get('ci_lower'))}, {_num(stats.get('ci_upper'))}]</td>"
                f"<td>{_num(stats.get('p_value'), 4)}</td>"
                f"<td>{'yes' if stats.get('stat_significant') else 'no'}</td></tr>"
            )
    return (
        '<section class="card"><h3>Comparison compatibility</h3>'
        '<p><span class="badge b-success">compatible</span> '
        f"Paired stats computed at build time vs {_esc(baseline.get('run_id', '?'))}.</p>"
        '<div class="tbl"><table><thead><tr><th>Engine</th><th>Metric</th>'
        "<th>Delta</th><th>95% CI</th><th>p-value</th><th>p &lt; 0.05</th>"
        "</tr></thead><tbody>"
        f"{''.join(rows) or '<tr><td colspan=6>no shared engines</td></tr>'}"
        "</tbody></table></div>"
        "<p class='note'>95% CIs: paired percentile bootstrap (2,000 samples, seed 42). "
        "p-values: two-sided paired Student-t; no multiple-comparison correction.</p>"
        "</section>"
    )


def _uncertainty_cell(engine: str, comparison: dict | None) -> str:
    if comparison is None:
        return "&mdash;"
    if not comparison.get("compatible"):
        return '<span class="st-unknown">refused</span>'
    per_metric = (comparison.get("engines") or {}).get(engine) or {}
    for label in ("Recall@5", "nDCG@10", "Complete Coverage@10", "MRR"):
        stats = per_metric.get(label)
        if stats and "error" not in stats:
            return (
                f"{stats.get('delta', 0.0):+.3f} "
                f"[{stats.get('ci_lower', 0.0):.3f}, {stats.get('ci_upper', 0.0):.3f}] "
                f"p={stats.get('p_value', 1.0):.4f}"
            )
    return '<span class="st-unknown">unknown</span>'


def _engine_table_html(run: dict, comparison: dict | None) -> str:
    availability = run.get("metric_availability") or {}
    rows = []
    for name, res in (run.get("baselines") or {}).items():
        if not isinstance(res, dict):
            continue
        status = res.get("status", "unknown")
        if status == "unsupported":
            status_html = '<span class="st-unsupported">not supported</span>'
        elif status == "success":
            status_html = '<span class="badge b-success">success</span>'
        elif status == "failed":
            status_html = '<span class="badge b-failed">failed</span>'
        else:
            status_html = f'<span class="st-unknown">{_esc(status)}</span>'
        denom = (
            f"total {_int_or_unknown(res.get('total_cases'))} / "
            f"pos {_int_or_unknown(res.get('positive_cases_count'))} / "
            f"abs {_int_or_unknown(res.get('abstention_cases_count'))} / "
            f"failed {_int_or_unknown(res.get('failed_cases_count'))} / "
            f"empty {_int_or_unknown(res.get('empty_result_count'))}"
        )

        def metric(field: str, overall: str) -> str:
            if not availability.get(field, True):
                return _na_not_measured()
            return _num(res.get(overall))

        ops = res.get("ops") or {}
        stats = _latency_stats(res.get("case_results") or [])
        if stats is None:
            latency_html = _na_not_measured()
        else:
            latency_html = (
                f"mean {stats['mean']:.1f} / p50 {stats['p50']:.1f} / "
                f"p95 {stats['p95']:.1f} / p99 {stats['p99']:.1f} ms "
                f"(n={stats['count']})"
            )
        rss = ops.get("peak_memory_rss_mb")
        resource_html = (
            f"{float(rss):.1f} MB sampled RSS"
            if isinstance(rss, (int, float))
            else _na_not_measured()
        )
        rows.append(
            f"<tr><td><strong>{_esc(name)}</strong><br>{status_html}</td>"
            f"<td>{denom}</td>"
            f"<td>{metric('recall_at_5', 'overall_recall_at_5')}</td>"
            f"<td>{metric('ndcg_at_10', 'overall_ndcg_at_10')}</td>"
            f"<td>{metric('complete_gold_coverage_at_10', 'overall_complete_coverage_at_10')}</td>"
            f"<td>{_num(res.get('overall_abstention_accuracy')) if res.get('abstention_evaluated') else _na_not_measured()}</td>"
            f"<td>{latency_html}</td>"
            f"<td>{resource_html}</td>"
            f"<td>{_uncertainty_cell(str(name), comparison)}</td></tr>"
        )
    return (
        '<section class="card"><h3>Engines</h3>'
        '<div class="tbl"><table><thead><tr><th>Engine</th><th>Denominators</th>'
        "<th>Recall@5</th><th>nDCG@10</th><th>Coverage@10</th><th>Abstention acc</th>"
        "<th>Latency distribution</th><th>Resources</th>"
        "<th>Uncertainty vs baseline (Recall@5)</th>"
        "</tr></thead><tbody>"
        f"{''.join(rows) or '<tr><td colspan=9>no engines recorded</td></tr>'}"
        "</tbody></table></div></section>"
    )


def _latency_section_html(run: dict) -> str:
    parts = []
    for name, res in (run.get("baselines") or {}).items():
        if not isinstance(res, dict):
            continue
        stats = _latency_stats(res.get("case_results") or [])
        if stats is None:
            body = _na_not_measured()
        else:
            body = _histogram_html(stats["samples"])
        parts.append(
            f'<div class="lat"><h4>{_esc(name)}</h4>{body}</div>'
        )
    return (
        '<section class="card"><h3>Per-query latency samples</h3>'
        f"{''.join(parts) or '<p>no engines recorded</p>'}"
        "<p class='note'>Client-observed per-query durations recorded in the "
        "artifact; no sampling or modelling is performed by the viewer.</p></section>"
    )


def _organization_section_html(run: dict) -> str:
    blocks = []
    for name, res in (run.get("baselines") or {}).items():
        if not isinstance(res, dict):
            continue
        org = res.get("organization") or {}
        if not org:
            continue
        items = "".join(
            f"<li><code>{_esc(key)}</code>: {_esc(json.dumps(value, sort_keys=True))}</li>"
            for key, value in sorted(org.items(), key=lambda kv: str(kv[0]))
        )
        blocks.append(f"<div class='lat'><h4>{_esc(name)}</h4><ul>{items}</ul></div>")
    if not blocks:
        return ""
    return (
        '<section class="card"><h3>Organization (recorded snapshots only)</h3>'
        f"{''.join(blocks)}</section>"
    )


def _query_cell_retrieved(case: dict) -> str:
    ids = _case_retrieved(case)
    if not ids:
        return '<span class="st-na">none</span>'
    shown = " ".join(f"<code>{i + 1}:{_esc(doc)}</code>" for i, doc in enumerate(ids[:20]))
    extra = f" +{len(ids) - 20} more" if len(ids) > 20 else ""
    return shown + _esc(extra)


def _query_rows_html(
    cases: list[dict], baseline_cases: dict[str, dict] | None
) -> str:
    rows = []
    for case in cases:
        if not isinstance(case, dict):
            continue
        qid = _case_query_id(case)
        outcome = case.get("outcome") or "unknown"
        gold = _case_gold(case)
        gold_html = (
            " ".join(f"<code>{_esc(doc)}</code>" for doc in gold[:20])
            if gold
            else '<span class="st-na">not recorded in run artifact</span>'
        )
        query_text = case.get("query")
        query_html = _esc(query_text) if query_text else "<span>—</span>"
        metrics_html = (
            f"r@5 {_num(case.get('recall_at_5'))} "
            f"nDCG@10 {_num(case.get('ndcg_at_10'))} "
            f"cov@10 {_num(case.get('complete_gold_coverage_at_10'))} "
            f"MRR {_num(case.get('mrr'))}"
        )
        error_html = ""
        if outcome == "query_failed":
            error_html = _esc(case.get("error_code") or "failed")
            receipt = case.get("backend_receipt")
            if receipt:
                error_html += f" {_esc(json.dumps(receipt, sort_keys=True)[:300])}"
        excluded_ids = case.get("native_excluded_ids") or case.get("excluded_ids") or []
        excluded_html = (" ".join(f"<code>{_esc(doc)}</code>" for doc in excluded_ids[:20])
                         if excluded_ids else "—")
        if case.get("exclusion_reason"):
            excluded_html += f" <span class='qtext'>{_esc(case['exclusion_reason'])}</span>"
        cells = (
            f"<td><code>{_esc(qid)}</code><br><span class='qtext'>{query_html}</span></td>"
            f"<td>{gold_html}</td>"
            f"<td>{_query_cell_retrieved(case)}</td>"
            f"<td>{excluded_html}</td>"
            f'<td>{_outcome_badge(outcome)}</td>'
            f"<td>{metrics_html}</td>"
            f"<td>{error_html or '—'}</td>"
        )
        if baseline_cases is not None:
            other = baseline_cases.get(str(case.get("case_id")) or qid, {})
            cells += (
                f"<td>{_query_cell_retrieved(other)}</td>"
                f"<td>{_outcome_badge(other.get('outcome'))}</td>"
                f"<td>r@5 {_num(other.get('recall_at_5'))} "
                f"nDCG@10 {_num(other.get('ndcg_at_10'))}</td>"
            )
        rows.append(f'<tr class="qrow" data-outcome="{_esc(outcome)}">{cells}</tr>')
    return "".join(rows)


def _queries_section_html(run: dict, baseline: dict | None) -> str:
    baseline_engines = (baseline or {}).get("baselines") or {}
    sections = []
    for name, res in (run.get("baselines") or {}).items():
        if not isinstance(res, dict):
            continue
        cases = res.get("case_results") or []
        other = baseline_engines.get(name)
        baseline_cases = None
        extra_head = ""
        if isinstance(other, dict):
            baseline_cases = {
                str(item.get("case_id")): item
                for item in (other.get("case_results") or [])
                if isinstance(item, dict)
            }
            extra_head = (
                "<th>Baseline retrieved</th><th>Baseline outcome</th>"
                "<th>Baseline metrics</th>"
            )
        sections.append(
            f"<h4>{_esc(name)} ({len(cases)} queries)</h4>"
            '<div class="tbl"><table><thead><tr><th>Query</th><th>Gold native IDs</th>'
            "<th>Retrieved (rank:id)</th><th>Excluded IDs</th><th>Outcome</th>"
            "<th>Per-query metrics</th><th>Error</th>"
            f"{extra_head}</tr></thead><tbody>"
            f"{_query_rows_html(cases, baseline_cases)}"
            "</tbody></table></div>"
        )
    filters = (
        '<div class="filters" role="group" aria-label="Filter by outcome">'
        '<button class="filter-btn active" data-f="all">all</button>'
        '<button class="filter-btn" data-f="success">success</button>'
        '<button class="filter-btn" data-f="explicit_abstention">explicit abstention</button>'
        '<button class="filter-btn" data-f="empty_result">empty result</button>'
        '<button class="filter-btn" data-f="query_failed">query failed</button>'
        '<button class="filter-btn" data-f="excluded">excluded</button>'
        "</div>"
    )
    return (
        '<section class="card"><h3>Per-query results</h3>'
        f"{filters}"
        f"{''.join(sections) or '<p>no engines recorded</p>'}"
        "</section>"
    )


def _embedded_body(run: dict, baseline: dict | None, comparison: dict | None) -> str:
    return (
        _header_html(run)
        + _comparison_panel_html(run, baseline, comparison)
        + _engine_table_html(run, comparison)
        + _latency_section_html(run)
        + _organization_section_html(run)
        + _queries_section_html(run, baseline)
        + "<p class='note'>All values above were recorded in the artifact or "
        "computed at build time by trace-bench; page scripts only filter and "
        "display them.</p>"
    )


_WAITING_BODY = (
    '<section class="card"><h3>Standalone viewer</h3>'
    "<p>No run is embedded in this page. Use the local file loader below to "
    "open a capsule <code>run.json</code> (full report) or "
    "<code>capsule.json</code> (manifest inventory). Files are read on your "
    "machine only and never uploaded anywhere.</p></section>"
)


_PAGE_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Trace-Bench Offline Viewer</title>
<style>
:root {
  --bg: #0a0f1d; --card: #131b2e; --border: #1e293b;
  --text: #f8fafc; --muted: #94a3b8; --faint: #64748b;
  --green: #4ade80; --blue: #38bdf8; --rose: #f43f5e; --amber: #fbbf24;
}
* { box-sizing: border-box; }
body { background: var(--bg); color: var(--text);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  margin: 0; padding: 1.5rem 1rem; line-height: 1.5; }
.wrap { max-width: 1200px; margin: 0 auto; }
h1 { font-size: 1.4rem; margin: 0 0 0.25rem 0; }
h2 { font-size: 1.2rem; margin: 0 0 0.25rem 0; }
h3 { font-size: 1.05rem; margin: 0 0 0.75rem 0; }
h4 { font-size: 0.95rem; margin: 1.25rem 0 0.5rem 0; color: var(--blue); }
.sub { color: var(--muted); margin-top: 0; }
.card { background: var(--card); border: 1px solid var(--border);
  border-radius: 12px; padding: 1.25rem; margin: 1rem 0; }
.badges { display: flex; gap: 0.4rem; flex-wrap: wrap; margin-top: 0.5rem; }
.badge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 9999px;
  font-size: 0.75rem; font-weight: 600; background: rgba(255,255,255,0.06);
  color: var(--muted); border: 1px solid var(--border); }
.b-success { background: rgba(74,222,128,0.12); color: var(--green);
  border-color: rgba(74,222,128,0.25); }
.b-failed { background: rgba(244,63,94,0.12); color: var(--rose);
  border-color: rgba(244,63,94,0.25); }
.b-abstain { background: rgba(56,189,248,0.12); color: var(--blue);
  border-color: rgba(56,189,248,0.25); }
.b-empty { background: rgba(251,191,36,0.12); color: var(--amber);
  border-color: rgba(251,191,36,0.25); }
.b-excluded { background: rgba(148,163,184,0.12); color: var(--muted);
  border-color: rgba(148,163,184,0.25); }
.st-unknown { color: var(--faint); font-style: italic; }
.st-na { color: var(--amber); }
.st-unsupported { color: var(--rose); font-weight: 600; }
.tbl { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; font-size: 0.82rem; }
th { color: var(--muted); text-align: left; padding: 0.6rem 0.75rem;
  border-bottom: 1px solid var(--border); background: rgba(0,0,0,0.2);
  white-space: nowrap; }
td { padding: 0.6rem 0.75rem; border-bottom: 1px solid rgba(255,255,255,0.05);
  color: var(--muted); vertical-align: top; }
tr:hover td { background: rgba(255,255,255,0.02); color: var(--text); }
code { font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 0.78rem;
  background: rgba(255,255,255,0.05); padding: 0.1rem 0.3rem; border-radius: 4px;
  white-space: nowrap; }
.qtext { font-size: 0.78rem; color: var(--faint); }
.note { font-size: 0.78rem; color: var(--faint); }
.filters { display: flex; gap: 0.4rem; flex-wrap: wrap; margin-bottom: 0.75rem; }
.filter-btn { background: rgba(255,255,255,0.06); color: var(--muted);
  border: 1px solid var(--border); border-radius: 9999px; padding: 0.25rem 0.7rem;
  font-size: 0.75rem; cursor: pointer; }
.filter-btn.active { background: rgba(56,189,248,0.15); color: var(--blue);
  border-color: rgba(56,189,248,0.35); }
.hist { display: flex; align-items: flex-end; gap: 2px; height: 70px;
  background: rgba(0,0,0,0.2); border-radius: 6px; padding: 4px; }
.hbar { flex: 1; background: var(--blue); border-radius: 2px 2px 0 0; min-width: 3px; }
.hist-axis { display: flex; justify-content: space-between; font-size: 0.72rem;
  color: var(--faint); margin-top: 0.2rem; }
.lat { margin-bottom: 1rem; }
ul { margin: 0.25rem 0; padding-left: 1.25rem; font-size: 0.82rem; color: var(--muted); }
input[type=file] { color: var(--muted); font-size: 0.82rem; margin: 0.25rem 0; }
.loader-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
@media (max-width: 700px) { .loader-grid { grid-template-columns: 1fr; } }
footer { margin-top: 2rem; padding-top: 1rem; border-top: 1px solid var(--border);
  font-size: 0.75rem; color: var(--faint); }
.err { color: var(--rose); font-size: 0.82rem; }
</style>
</head>
<body>
<div class="wrap">
<h1>Trace-Bench Offline Viewer</h1>
<p class="sub">Self-contained report: no external references, no uploads, no live backends.</p>
<div id="embedded">%%BODY%%</div>
<section class="card" id="loader">
<h3>Local file loader (offline)</h3>
<p class="note">Read a <code>run.json</code> and an optional baseline file from this
machine. Files are parsed locally with FileReader; only shape and version are
checked, and recorded values are displayed without scoring.</p>
<div class="loader-grid">
<div><label>Run file: <input type="file" id="tb-file-a" accept=".json,application/json"></label></div>
<div><label>Baseline file (optional): <input type="file" id="tb-file-b" accept=".json,application/json"></label></div>
</div>
<div id="tb-imported"></div>
<div id="tb-compare"></div>
<div id="tb-stats"></div>
</section>
<footer>
<p>This viewer never scores, re-ranks, or re-judges queries; never contacts the
network; and never starts a Trace runtime. Scores shown are the recorded values
from the artifact. N/A means not measured; unknown means the field is absent.</p>
</footer>
</div>
<script>
"use strict";
var TB_RUN = %%RUN_JSON%%;
var TB_BASELINE = %%BASELINE_JSON%%;
var TB_COMPARISON = %%COMPARISON_JSON%%;
var TB_LOADED = { a: TB_RUN, b: TB_BASELINE };

function tbEl(tag, text, cls) {
  var node = document.createElement(tag);
  if (cls) { node.className = cls; }
  if (text !== undefined && text !== null) { node.textContent = String(text); }
  return node;
}
function tbBadge(outcome) {
  var labels = { success: "success", explicit_abstention: "explicit abstention",
    empty_result: "empty result", query_failed: "query failed", excluded: "excluded" };
  var classes = { success: "b-success", explicit_abstention: "b-abstain",
    empty_result: "b-empty", query_failed: "b-failed", excluded: "b-excluded" };
  var span = tbEl("span", labels[outcome] || ("unknown: " + outcome),
    "badge " + (classes[outcome] || "st-unknown"));
  return span;
}
function tbIsRunDoc(obj) {
  return !!obj && typeof obj === "object" && typeof obj.run_id === "string" &&
    !!obj.baselines && typeof obj.baselines === "object";
}
function tbIsCapsuleDoc(obj) {
  return !!obj && typeof obj === "object" && obj.version === "tb-capsule-v1" &&
    !!obj.sha256 && typeof obj.sha256 === "object";
}
function tbStableStringify(value) {
  if (value === null || typeof value !== "object") { return JSON.stringify(value); }
  if (Array.isArray(value)) {
    return "[" + value.map(tbStableStringify).join(",") + "]";
  }
  var keys = Object.keys(value).sort();
  return "{" + keys.map(function (k) {
    return JSON.stringify(k) + ":" + tbStableStringify(value[k]);
  }).join(",") + "}";
}
function tbFmt(value, digits) {
  if (value === null || value === undefined) { return "unknown"; }
  var n = Number(value);
  if (!isFinite(n)) { return "unknown"; }
  return n.toFixed(digits === undefined ? 3 : digits);
}
function tbEngineTable(container, run) {
  var avail = run.metric_availability || {};
  var table = tbEl("table");
  var head = tbEl("tr");
  ["Engine", "Denominators", "Recall@5", "nDCG@10", "Coverage@10",
   "Failed", "Empty"].forEach(function (h) { head.appendChild(tbEl("th", h)); });
  var thead = tbEl("thead"); thead.appendChild(head); table.appendChild(thead);
  var body = tbEl("tbody");
  Object.keys(run.baselines || {}).forEach(function (name) {
    var res = run.baselines[name] || {};
    var row = tbEl("tr");
    row.appendChild(tbEl("td", name + " [" + (res.status || "unknown") + "]"));
    row.appendChild(tbEl("td", "total " + (res.total_cases === undefined ? "unknown" : res.total_cases) +
      " / pos " + (res.positive_cases_count === undefined ? "unknown" : res.positive_cases_count) +
      " / failed " + (res.failed_cases_count === undefined ? "unknown" : res.failed_cases_count) +
      " / empty " + (res.empty_result_count === undefined ? "unknown" : res.empty_result_count)));
    row.appendChild(tbEl("td", avail.recall_at_5 === false ? "N/A (not measured)" : tbFmt(res.overall_recall_at_5)));
    row.appendChild(tbEl("td", avail.ndcg_at_10 === false ? "N/A (not measured)" : tbFmt(res.overall_ndcg_at_10)));
    row.appendChild(tbEl("td", avail.complete_gold_coverage_at_10 === false ? "N/A (not measured)" : tbFmt(res.overall_complete_coverage_at_10)));
    row.appendChild(tbEl("td", res.failed_cases_count === undefined ? "unknown" : res.failed_cases_count));
    row.appendChild(tbEl("td", res.empty_result_count === undefined ? "unknown" : res.empty_result_count));
    body.appendChild(row);
  });
  table.appendChild(body);
  var wrap = tbEl("div", null, "tbl"); wrap.appendChild(table);
  container.appendChild(wrap);
}
function tbQueryTables(container, run) {
  Object.keys(run.baselines || {}).forEach(function (name) {
    var res = run.baselines[name] || {};
    container.appendChild(tbEl("h4", name + " (" + ((res.case_results || []).length) + " queries)"));
    var table = tbEl("table");
    var head = tbEl("tr");
    ["Query", "Retrieved (rank:id)", "Outcome", "r@5", "nDCG@10", "Error"].forEach(
      function (h) { head.appendChild(tbEl("th", h)); });
    var thead = tbEl("thead"); thead.appendChild(head); table.appendChild(thead);
    var body = tbEl("tbody");
    (res.case_results || []).forEach(function (c) {
      var row = tbEl("tr"); row.className = "qrow";
      row.setAttribute("data-outcome", c.outcome || "unknown");
      var qid = c.native_query_id || c.case_id || "unknown";
      var qcell = tbEl("td"); qcell.appendChild(tbEl("code", qid));
      if (c.query) { qcell.appendChild(tbEl("div", c.query, "qtext")); }
      row.appendChild(qcell);
      var ids = c.native_retrieved_ids || c.retrieved_ids || [];
      var rcell = tbEl("td");
      if (!ids.length) { rcell.appendChild(tbEl("span", "none", "st-na")); }
      ids.slice(0, 20).forEach(function (doc, i) {
        rcell.appendChild(tbEl("code", (i + 1) + ":" + doc));
        rcell.appendChild(document.createTextNode(" "));
      });
      row.appendChild(rcell);
      var ocell = tbEl("td"); ocell.appendChild(tbBadge(c.outcome));
      row.appendChild(ocell);
      row.appendChild(tbEl("td", tbFmt(c.recall_at_5)));
      row.appendChild(tbEl("td", tbFmt(c.ndcg_at_10)));
      var ecell = tbEl("td");
      if (c.outcome === "query_failed") {
        ecell.appendChild(tbEl("span", c.error_code || "failed"));
        if (c.backend_receipt) {
          ecell.appendChild(tbEl("div", JSON.stringify(c.backend_receipt).slice(0, 300), "qtext"));
        }
      } else { ecell.appendChild(tbEl("span", "--")); }
      row.appendChild(ecell);
      body.appendChild(row);
    });
    table.appendChild(body);
    var wrap = tbEl("div", null, "tbl"); wrap.appendChild(table);
    container.appendChild(wrap);
  });
}
function tbRenderCapsule(container, doc) {
  container.appendChild(tbEl("h4", "Capsule manifest " + (doc.capsule_id || "")));
  container.appendChild(tbEl("p", "version " + doc.version +
    "; members " + Object.keys(doc.sha256).length +
    ". Manifest only: open the capsule run.json for the full report.", "note"));
  var table = tbEl("table");
  var head = tbEl("tr");
  head.appendChild(tbEl("th", "Member")); head.appendChild(tbEl("th", "SHA-256"));
  var thead = tbEl("thead"); thead.appendChild(head); table.appendChild(thead);
  var body = tbEl("tbody");
  Object.keys(doc.sha256).sort().forEach(function (m) {
    var row = tbEl("tr");
    row.appendChild(tbEl("td", m));
    var code = tbEl("code", doc.sha256[m]); var cell = tbEl("td");
    cell.appendChild(code); row.appendChild(cell); body.appendChild(row);
  });
  table.appendChild(body);
  var wrap = tbEl("div", null, "tbl"); wrap.appendChild(table);
  container.appendChild(wrap);
}
function tbRenderImported() {
  var box = document.getElementById("tb-imported");
  while (box.firstChild) { box.removeChild(box.firstChild); }
  ["a", "b"].forEach(function (slot) {
    var doc = TB_LOADED[slot];
    if (!doc) { return; }
    var title = slot === "a" ? "Loaded run file" : "Loaded baseline file";
    box.appendChild(tbEl("h4", title));
    if (tbIsCapsuleDoc(doc) && !tbIsRunDoc(doc)) { tbRenderCapsule(box, doc); return; }
    box.appendChild(tbEl("p", "run " + doc.run_id + " | dataset " +
      (doc.dataset_name || "unknown") + " | queries " + (doc.total_cases || "unknown"),
      "note"));
    tbEngineTable(box, doc);
    tbQueryTables(box, doc);
  });
}
function tbRenderComparison() {
  var box = document.getElementById("tb-compare");
  while (box.firstChild) { box.removeChild(box.firstChild); }
  var a = TB_LOADED.a, b = TB_LOADED.b;
  if (!tbIsRunDoc(a) || !tbIsRunDoc(b)) { return; }
  box.appendChild(tbEl("h4", "Fingerprint compatibility (recorded values only)"));
  var fields = ["dataset_name", "dataset_version", "corpus_sha256",
    "cases_sha256", "indexed_documents_sha256"];
  var table = tbEl("table");
  var head = tbEl("tr");
  ["Field", "Run", "Baseline", "Match"].forEach(function (h) {
    head.appendChild(tbEl("th", h)); });
  var thead = tbEl("thead"); thead.appendChild(head); table.appendChild(thead);
  var body = tbEl("tbody");
  var allMatch = true;
  fields.forEach(function (f) {
    var match = String(a[f] || "") === String(b[f] || "") && !!a[f];
    if (!match) { allMatch = false; }
    var row = tbEl("tr");
    row.appendChild(tbEl("td", f));
    row.appendChild(tbEl("td", String(a[f] === undefined ? "unknown" : a[f])));
    row.appendChild(tbEl("td", String(b[f] === undefined ? "unknown" : b[f])));
    row.appendChild(tbEl("td", match ? "yes" : "NO"));
    body.appendChild(row);
  });
  var protoMatch = tbStableStringify(a.protocol || {}) === tbStableStringify(b.protocol || {}) && !!a.protocol;
  if (!protoMatch) { allMatch = false; }
  var prow = tbEl("tr");
  prow.appendChild(tbEl("td", "protocol"));
  prow.appendChild(tbEl("td", tbStableStringify(a.protocol || {}).slice(0, 120)));
  prow.appendChild(tbEl("td", tbStableStringify(b.protocol || {}).slice(0, 120)));
  prow.appendChild(tbEl("td", protoMatch ? "yes" : "NO"));
  body.appendChild(prow);
  table.appendChild(body);
  var wrap = tbEl("div", null, "tbl"); wrap.appendChild(table);
  box.appendChild(wrap);
  var verdict = tbEl("p");
  verdict.appendChild(tbEl("span", allMatch ? "fingerprints match" : "comparison refused",
    "badge " + (allMatch ? "b-success" : "b-failed")));
  box.appendChild(verdict);
}
function tbRenderStats() {
  var box = document.getElementById("tb-stats");
  while (box.firstChild) { box.removeChild(box.firstChild); }
  if (TB_COMPARISON && TB_COMPARISON.compatible && TB_COMPARISON.engines) {
    box.appendChild(tbEl("h4", "Embedded paired stats (build time)"));
    var table = tbEl("table");
    var head = tbEl("tr");
    ["Engine", "Metric", "Delta", "95% CI", "p-value"].forEach(function (h) {
      head.appendChild(tbEl("th", h)); });
    var thead = tbEl("thead"); thead.appendChild(head); table.appendChild(thead);
    var body = tbEl("tbody");
    Object.keys(TB_COMPARISON.engines).sort().forEach(function (eng) {
      var per = TB_COMPARISON.engines[eng] || {};
      Object.keys(per).forEach(function (label) {
        var s = per[label] || {};
        var row = tbEl("tr");
        row.appendChild(tbEl("td", eng));
        row.appendChild(tbEl("td", label));
        if (s.error) {
          var cell = tbEl("td", s.error); cell.colSpan = 3; row.appendChild(cell);
        } else {
          row.appendChild(tbEl("td", (s.delta >= 0 ? "+" : "") + tbFmt(s.delta)));
          row.appendChild(tbEl("td", "[" + tbFmt(s.ci_lower) + ", " + tbFmt(s.ci_upper) + "]"));
          row.appendChild(tbEl("td", tbFmt(s.p_value, 4)));
        }
        body.appendChild(row);
      });
    });
    table.appendChild(body);
    var wrap = tbEl("div", null, "tbl"); wrap.appendChild(table);
    box.appendChild(wrap);
    return;
  }
  var run = TB_LOADED.a;
  if (run && run.comparison_stats && typeof run.comparison_stats === "object") {
    box.appendChild(tbEl("h4", "Precomputed paired stats (from artifact)"));
    box.appendChild(tbEl("p", JSON.stringify(run.comparison_stats).slice(0, 2000), "note"));
    return;
  }
  if (tbIsRunDoc(TB_LOADED.a) && tbIsRunDoc(TB_LOADED.b)) {
    box.appendChild(tbEl("p", "not computed \\u2014 regenerate with trace-bench", "note"));
  }
}
function tbHandleFile(input, slot) {
  var file = input.files && input.files[0];
  if (!file) { return; }
  var reader = new FileReader();
  reader.onload = function () {
    var box = document.getElementById("tb-imported");
    var doc;
    try {
      doc = JSON.parse(reader.result);
    } catch (err) {
      box.appendChild(tbEl("p", "Invalid JSON in " + file.name, "err"));
      return;
    }
    if (!tbIsRunDoc(doc) && !tbIsCapsuleDoc(doc)) {
      box.appendChild(tbEl("p", file.name + " is neither a run artifact (run_id + baselines) nor a capsule manifest (tb-capsule-v1).", "err"));
      return;
    }
    TB_LOADED[slot] = doc;
    tbRenderImported();
    tbRenderComparison();
    tbRenderStats();
  };
  reader.readAsText(file);
}
document.getElementById("tb-file-a").addEventListener("change", function (ev) {
  tbHandleFile(ev.target, "a");
});
document.getElementById("tb-file-b").addEventListener("change", function (ev) {
  tbHandleFile(ev.target, "b");
});
Array.prototype.forEach.call(document.querySelectorAll(".filter-btn"), function (btn) {
  btn.addEventListener("click", function () {
    Array.prototype.forEach.call(document.querySelectorAll(".filter-btn"), function (other) {
      other.classList.remove("active");
    });
    btn.classList.add("active");
    var wanted = btn.getAttribute("data-f");
    Array.prototype.forEach.call(document.querySelectorAll(".qrow"), function (row) {
      var show = wanted === "all" || row.getAttribute("data-outcome") === wanted;
      row.style.display = show ? "" : "none";
    });
  });
});
tbRenderStats();
</script>
</body>
</html>
"""


def _json_for_embed(payload) -> str:
    if payload is None:
        return "null"
    text = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return (
        text.replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
        .replace("/", "\\/")
    )


def _render_page(
    body: str, run: dict | None, baseline: dict | None, comparison: dict | None
) -> str:
    page = _PAGE_TEMPLATE
    page = page.replace("%%BODY%%", body)
    page = page.replace("%%RUN_JSON%%", _json_for_embed(run))
    page = page.replace("%%BASELINE_JSON%%", _json_for_embed(baseline))
    page = page.replace("%%COMPARISON_JSON%%", _json_for_embed(comparison))
    return page


STATIC_VIEWER_HTML: str = _render_page(_WAITING_BODY, None, None, None)


def build_viewer_html(
    run_dict_or_capsule_dir,
    output_path: str | Path,
    baseline=None,
) -> Path:
    """Build one self-contained offline HTML page for a run artifact."""
    run = _load_run_document(run_dict_or_capsule_dir)
    base = _load_run_document(baseline) if baseline is not None else None
    try:
        BenchmarkRunResult.from_dict(run)
        if base is not None:
            BenchmarkRunResult.from_dict(base)
    except (TypeError, KeyError, ValueError) as exc:
        raise ValueError(f"Run artifact failed schema validation: {exc}") from exc
    comparison = _comparison_at_build(run, base) if base is not None else None
    body = _embedded_body(run, base, comparison)
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(_render_page(body, run, base, comparison), encoding="utf-8")
    return output

