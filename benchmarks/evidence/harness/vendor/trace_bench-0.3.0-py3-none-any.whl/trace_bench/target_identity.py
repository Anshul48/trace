"""TB-owned per-engine target identity (M0b).

Resolves TL source/substrate content identity from a product checkout using
pure file reads plus AST parsing: no imports, no ``sys.path`` mutation, no
model loads, and no bytecode/cache writes into the (read-only) target tree.

Recorded identities never contain absolute paths, so they stay portable
inside run artifacts and capsules.
"""

from __future__ import annotations

import ast
import sys
from contextlib import contextmanager
from pathlib import Path

from trace_bench.datasets.loader import compute_sha256, file_sha256


def _hash_py_files(directory: Path, label: str) -> list[tuple[str, str]]:
    return [(f"{label}/{path.name}", file_sha256(path))
            for path in sorted(directory.glob("*.py"))]


def _parse_candidate_rev(init_path: Path) -> str | None:
    """Read CANDIDATE_REV without importing the target package."""
    try:
        tree = ast.parse(init_path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return None
    for node in tree.body:
        if (isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == "CANDIDATE_REV"
                and isinstance(node.value, ast.Constant)
                and isinstance(node.value.value, str)):
            return node.value.value
    return None


def resolve_tl_identity(architecture_dir: str | Path) -> dict:
    """Resolve TL content identity. Raises FileNotFoundError when unusable."""
    root = Path(architecture_dir)
    tlsys_dir = root / "tl-sys" / "tlsys"
    candidate_dir = root / "tl-candidate-batch" / "candidate"
    missing = [d for d in (tlsys_dir, candidate_dir) if not d.is_dir()]
    if missing:
        names = ", ".join(str(p.relative_to(root)) for p in missing)
        raise FileNotFoundError(
            f"architecture_dir lacks TL source: {names}. Set architecture_dir "
            "in backend config to the checkout containing tl-sys and tl-candidate-batch.")
    tlsys_files = _hash_py_files(tlsys_dir, "tlsys")
    candidate_files = _hash_py_files(candidate_dir, "candidate")
    return {
        "status": "resolved",
        "target_role": "TL",
        "tlsys_files": tlsys_files,
        "candidate_files": candidate_files,
        "tlsys_sha256": compute_sha256(repr(tlsys_files)),
        "substrate_sha256": compute_sha256(repr(candidate_files)),
        "combined_sha256": compute_sha256(repr(tlsys_files + candidate_files)),
        "candidate_revision": _parse_candidate_rev(tlsys_dir / "__init__.py"),
        "candidate_revision_source": "tlsys/__init__.py",
    }


def snapshot_target_identity(architecture_dir: str | Path) -> dict:
    """Resolve, or return an explicit unresolved marker (never raises)."""
    try:
        return resolve_tl_identity(architecture_dir)
    except (FileNotFoundError, OSError) as exc:
        return {"status": "unresolved", "target_role": "TL", "reason": str(exc)}


def verify_tl_identity(architecture_dir: str | Path, identity: dict) -> tuple[bool, str]:
    """Re-resolve and compare against a frozen identity."""
    try:
        current = resolve_tl_identity(architecture_dir)
    except (FileNotFoundError, OSError) as exc:
        return False, f"target checkout unavailable for verification: {exc}"
    if current["combined_sha256"] == identity.get("combined_sha256"):
        return True, "target identity verified"
    old = dict(identity.get("tlsys_files", []) + identity.get("candidate_files", []))
    drifted = sorted(n for n, h in current["tlsys_files"] + current["candidate_files"]
                     if old.get(n) != h)
    return False, f"target drift detected in: {', '.join(drifted) or 'file set'}"


def compare_target_identity(pre: dict | None, post: dict | None) -> tuple[bool | None, str]:
    """Compare pre/post-run target snapshots. None means a non-target backend."""
    if pre is None and post is None:
        return None, "no target identity (non-target backend)"
    if pre is None or post is None:
        return False, "target identity appeared/disappeared mid-run: drift"
    if pre.get("combined_sha256") == post.get("combined_sha256"):
        return True, "target identity verified"
    return False, "target drift detected between pre-run and post-run snapshots"


def target_identity_sha256(architecture_dir: str | Path, config: dict | None = None) -> str:
    """Canonical digest of the (possibly unresolved) target snapshot for resume identity."""
    _ = config  # Reserved for expected-pin enforcement once D00 delivers owner manifests.
    return compute_sha256(repr(sorted(snapshot_target_identity(architecture_dir).items())))


@contextmanager
def no_target_bytecode():
    """Prevent bytecode/cache writes while target modules are imported."""
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        yield
    finally:
        sys.dont_write_bytecode = previous
