"""Shipped recipe presets, available to wheel-only installs.

The JSON files in this package are the executable presets referenced by the
docs (``trace-bench recipe list``). The checkout ``recipes/`` directory keeps
editable copies for contributors; a test enforces byte-equality so the two
never drift.
"""

from __future__ import annotations

import importlib.resources as resources


def list_presets() -> list[str]:
    """Sorted preset names (without the ``.json`` suffix)."""
    return sorted(
        path.name[: -len(".json")]
        for path in resources.files(__name__).iterdir()
        if path.name.endswith(".json")
    )


def preset_text(name: str) -> str:
    """Raw JSON text of preset ``name`` (``.json`` suffix optional)."""
    stem = name[:-len(".json")] if name.endswith(".json") else name
    available = list_presets()
    if stem not in available:
        raise ValueError(f"Unknown recipe preset '{name}'. Available: {', '.join(available)}")
    return resources.files(__name__).joinpath(stem + ".json").read_text(encoding="utf-8")
