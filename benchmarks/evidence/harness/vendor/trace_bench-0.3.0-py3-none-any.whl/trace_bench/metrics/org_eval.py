"""Self-organization usefulness evaluator skeleton (Stage B, TB-only).

Externally observable usefulness protocol (COORDINATOR section 5, R8/R9):
matched before/after task runs over a frozen query set with source
population/frontier changes explicit, static/append-only/no-maintenance
controls, and deliberately faulty controls the evaluator must flag.

TB-side only: reuses the TB lifecycle reference backend and organization
helpers. No Trace/TL imports. A green run against the reference proves
harness mechanics, never product capability.

Fail-closed rules:
- Stage/task population or frontier mismatch -> raise (no scores emitted).
- Backend snapshot diverging from the stage live set -> preservation check
  fails; verdict ``incomparable`` or ``invalid``, never silent success.
- Unsupported ops (e.g. maintain on a no-drain control) are recorded as
  ``unsupported`` receipts, never emulated and never scored as zero utility.
"""

from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

from trace_bench.lifecycle.contract import LifecycleBackend, LifecycleNotSupported
from trace_bench.lifecycle.reference import ReferenceLifecycleBackend
from trace_bench.metrics.organization import (
    duplicate_membership_count,
    orphan_count,
    source_atom_coverage,
)
from trace_bench.metrics.retrieval import recall_at_k

FORMAT_VERSION = "tb-org-eval-v1"

CHECK_NAMES: tuple[str, ...] = (
    "stage_match",
    "query_frozen",
    "preservation",
    "membership",
    "no_stale_leakage",
)


class OrgEvalError(ValueError):
    """Raised when the evaluation cannot proceed honestly (fail closed)."""


class StageMismatchError(OrgEvalError):
    """Stage descriptor disagrees with the task's declared population/frontier."""


# -- task -----------------------------------------------------------------


@dataclass(frozen=True)
class OrgQuery:
    """One frozen query with source-grounded gold over the task population."""

    query_id: str
    text: str
    gold: tuple[str, ...]
    top_k: int = 5


@dataclass(frozen=True)
class OrgTask:
    """Frozen query set + gold over a declared population/frontier."""

    name: str
    population_id: str
    frontier: dict
    documents: tuple[dict, ...]
    queries: tuple[OrgQuery, ...]

    @property
    def doc_ids(self) -> frozenset[str]:
        """_ids of the declared source population."""
        return frozenset(d["doc_id"] for d in self.documents)

    def query_digest(self) -> str:
        """Stable digest of the frozen (query_id, text, gold, top_k) set."""
        canonical = json.dumps(
            [[q.query_id, q.text, list(q.gold), q.top_k] for q in self.queries],
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def load_task(path: str | Path) -> OrgTask:
    """Load and validate a ``tb-org-eval-v1`` task fixture (fail closed)."""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("format") != FORMAT_VERSION:
        raise OrgEvalError(
            f"unsupported org-eval format: {payload.get('format')!r} "
            f"(expected {FORMAT_VERSION!r})"
        )
    try:
        name = payload["name"]
        population_id = payload["population"]["id"]
        frontier = dict(payload["population"].get("frontier", {}))
        documents = tuple(
            {"doc_id": d["doc_id"], "text": d["text"],
             "title": d.get("title", "")}
            for d in payload["documents"]
        )
        queries = tuple(
            OrgQuery(query_id=q["query_id"], text=q["text"],
                     gold=tuple(q.get("gold", ())), top_k=q.get("top_k", 5))
            for q in payload["queries"]
        )
    except (KeyError, TypeError) as exc:
        raise OrgEvalError(f"malformed org-eval task: {exc}") from exc
    if not documents:
        raise OrgEvalError("task declares an empty document population")
    if not queries:
        raise OrgEvalError("task declares an empty query set")
    if len({d["doc_id"] for d in documents}) != len(documents):
        raise OrgEvalError("task population has duplicate doc_ids")
    if len({q.query_id for q in queries}) != len(queries):
        raise OrgEvalError("task query set has duplicate query_ids")
    doc_ids = {d["doc_id"] for d in documents}
    for query in queries:
        unknown = set(query.gold) - doc_ids
        if unknown:
            raise OrgEvalError(
                f"query {query.query_id} gold references docs outside the "
                f"declared population: {sorted(unknown)}"
            )
        if query.top_k <= 0:
            raise OrgEvalError(f"query {query.query_id} has non-positive top_k")
    return OrgTask(name=name, population_id=population_id, frontier=frontier,
                   documents=documents, queries=queries)


# -- stages ---------------------------------------------------------------


@dataclass(frozen=True)
class StageDescriptor:
    """Explicit declaration of what a stage covers and costs.

    ``population_id`` + ``frontier`` must match the task exactly, or the
    run fails closed. ``expected_live_ids`` is the live set the backend
    snapshot must report; ``budget`` records declared limits (informational
    in the skeleton: overruns are reported, never silently re-scoped).
    """

    role: str  # "before" | "after"
    population_id: str
    frontier: dict
    expected_live_ids: tuple[str, ...]
    budget: dict = field(default_factory=dict)


@dataclass(frozen=True)
class Stage:
    """A descriptor plus the ordered ops that produce that stage's state."""

    descriptor: StageDescriptor
    operations: tuple[dict, ...] = ()


def _check_descriptor(descriptor: StageDescriptor, task: OrgTask) -> None:
    if descriptor.population_id != task.population_id:
        raise StageMismatchError(
            f"stage {descriptor.role!r} population {descriptor.population_id!r} "
            f"!= task population {task.population_id!r}"
        )
    if dict(descriptor.frontier) != dict(task.frontier):
        raise StageMismatchError(
            f"stage {descriptor.role!r} frontier {descriptor.frontier!r} "
            f"!= task frontier {dict(task.frontier)!r}"
        )
    unknown = set(descriptor.expected_live_ids) - set(task.doc_ids)
    if unknown:
        raise StageMismatchError(
            f"stage {descriptor.role!r} expects live ids outside the task "
            f"population: {sorted(unknown)}"
        )


# -- backends: controls and faulty variants -------------------------------


class AppendOnlyControlBackend(ReferenceLifecycleBackend):
    """Append-only control: insert/query/snapshot/maintain only.

    ``update``/``retire`` raise :class:`LifecycleNotSupported`; the
    evaluator records them as unsupported, never emulates them.
    """

    def name(self) -> str:
        return "AppendOnlyControlBackend"

    def capabilities(self) -> dict[str, bool]:
        caps = super().capabilities()
        caps["update"] = False
        caps["retire"] = False
        return caps

    def update(self, doc_id: str, text: str, title: str = "",
               metadata: dict | None = None) -> dict:
        raise LifecycleNotSupported("update")

    def retire(self, doc_id: str) -> dict:
        raise LifecycleNotSupported("retire")


class NoDrainControlBackend(ReferenceLifecycleBackend):
    """No-maintenance control: full lifecycle except ``maintain``."""

    def name(self) -> str:
        return "NoDrainControlBackend"

    def capabilities(self) -> dict[str, bool]:
        caps = super().capabilities()
        caps["maintain"] = False
        return caps

    def maintain(self) -> dict:
        raise LifecycleNotSupported("maintain")


class OrganizingTreatmentBackend(ReferenceLifecycleBackend):
    """Reference treatment whose ``maintain`` observably reorganizes.

    Before the first ``maintain`` the query path is degraded (strict
    >=2-token overlap, modelling an unorganized index); after ``maintain``
    it uses the full reference overlap ranking. Deterministic; the
    before/after delta is therefore attributable to the maintain pass on
    an unchanged population, which is what lets controls separate.
    """

    def __init__(self) -> None:
        super().__init__()
        self._organized = False
        self.maintain_passes = 0

    def name(self) -> str:
        return "OrganizingTreatmentBackend"

    def maintain(self) -> dict:
        receipt = super().maintain()
        self._organized = True
        self.maintain_passes += 1
        receipt["organized"] = True
        return receipt

    def query(self, text: str, top_k: int = 10,
              generation: int | None = None) -> list[dict]:
        if self._organized:
            return super().query(text, top_k, generation)
        from trace_bench.lifecycle.reference import tokenize

        query_tokens = tokenize(text)
        scored = []
        for doc_id in self._store:
            record = self._store[doc_id]
            if not record["alive"]:
                continue
            if generation is not None and record["generation_updated"] > generation:
                continue
            overlap = len(query_tokens & tokenize(record["text"]))
            if query_tokens and overlap >= 2:
                scored.append((doc_id, overlap))
        scored.sort(key=lambda item: (-item[1], item[0]))
        return [{"doc_id": d, "score": float(s),
                 "text": self._store[d]["text"]}
                for d, s in scored[: max(top_k, 0)]]


class OrgMembershipLiarBackend(ReferenceLifecycleBackend):
    """Deliberately faulty: snapshot duplicates one doc across partitions."""

    def name(self) -> str:
        return "OrgMembershipLiarBackend"

    def snapshot(self) -> dict:
        snap = super().snapshot()
        live = snap["doc_ids"]
        if live:
            snap["membership"] = [list(live), [live[0]]]
        return snap


class OrgStaleLeakBackend(ReferenceLifecycleBackend):
    """Deliberately faulty: queries also search retired docs."""

    def name(self) -> str:
        return "OrgStaleLeakBackend"

    def query(self, text: str, top_k: int = 10,
              generation: int | None = None) -> list[dict]:
        from trace_bench.lifecycle.reference import tokenize

        query_tokens = tokenize(text)
        scored = []
        for doc_id in self._store:
            record = self._store[doc_id]
            if generation is not None and record["generation_updated"] > generation:
                continue
            overlap = len(query_tokens & tokenize(record["text"]))
            if query_tokens and overlap > 0:
                scored.append((doc_id, overlap))
        scored.sort(key=lambda item: (-item[1], item[0]))
        return [{"doc_id": d, "score": float(s),
                 "text": self._store[d]["text"]}
                for d, s in scored[: max(top_k, 0)]]


CONTROL_BACKENDS: dict[str, type[ReferenceLifecycleBackend]] = {
    "append_only": AppendOnlyControlBackend,
    "no_drain": NoDrainControlBackend,
    "organizing_treatment": OrganizingTreatmentBackend,
}

FAULTY_ORG_BACKENDS: dict[str, type[ReferenceLifecycleBackend]] = {
    "org_membership_liar": OrgMembershipLiarBackend,
    "org_stale_leak": OrgStaleLeakBackend,
}


# -- results --------------------------------------------------------------


@dataclass
class OrgCheck:
    """One named integrity verdict with evidence."""

    name: str
    passed: bool
    expected: object = None
    observed: object = None
    evidence: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "passed": self.passed,
            "expected": self.expected,
            "observed": self.observed,
            "evidence": self.evidence,
        }


@dataclass
class StageReport:
    """Per-stage measurements: preservation, coverage, cost, integrity."""

    role: str
    descriptor: dict
    preservation: float
    coverage_recall_mean: float
    per_query_recall: dict
    cost: dict
    snapshot_ids: list[str]
    membership_duplicates: int
    orphan_atoms: int
    stale_violations: list[dict]
    receipts: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "role": self.role,
            "descriptor": self.descriptor,
            "preservation": self.preservation,
            "coverage_recall_mean": self.coverage_recall_mean,
            "per_query_recall": self.per_query_recall,
            "cost": self.cost,
            "snapshot_ids": self.snapshot_ids,
            "membership_duplicates": self.membership_duplicates,
            "orphan_atoms": self.orphan_atoms,
            "stale_violations": self.stale_violations,
            "receipts": self.receipts,
        }


@dataclass
class OrgEvalResult:
    """Outcome of one matched before/after run."""

    task_name: str
    backend_name: str
    stages: list[StageReport] = field(default_factory=list)
    checks: list[OrgCheck] = field(default_factory=list)
    coverage_delta: float | None = None
    preservation_delta: float | None = None
    cost_total: dict = field(default_factory=dict)
    attribution: dict = field(default_factory=dict)
    verdict: str = "invalid"
    query_digest: str = ""

    def check(self, name: str) -> OrgCheck:
        """Return the named check (KeyError when unknown)."""
        for item in self.checks:
            if item.name == name:
                return item
        raise KeyError(f"unknown org-eval check: {name}")

    @property
    def all_passed(self) -> bool:
        return all(item.passed for item in self.checks)

    def to_dict(self) -> dict:
        return {
            "format": FORMAT_VERSION,
            "task_name": self.task_name,
            "backend_name": self.backend_name,
            "verdict": self.verdict,
            "query_digest": self.query_digest,
            "coverage_delta": self.coverage_delta,
            "preservation_delta": self.preservation_delta,
            "cost_total": self.cost_total,
            "attribution": self.attribution,
            "stages": [s.to_dict() for s in self.stages],
            "checks": [c.to_dict() for c in self.checks],
        }

    def save_json(self, path: str | Path) -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True),
                          encoding="utf-8")
        return target


# -- runner ---------------------------------------------------------------


def _apply_operations(backend: LifecycleBackend,
                      operations: tuple[dict, ...]) -> tuple[list[dict], dict]:
    """Apply stage ops; return (receipts, cost counters).

    Unsupported ops become ``unsupported`` receipts (never emulated).
    Backend exceptions become ``error`` receipts (never silent).
    """
    receipts: list[dict] = []
    cost = {"insert": 0, "update": 0, "retire": 0, "maintain": 0,
            "unsupported": 0, "errors": 0}
    capabilities = dict(backend.capabilities() or {})
    for index, operation in enumerate(operations):
        op = operation.get("op")
        params = dict(operation.get("params") or {})
        entry: dict = {"seq": index, "op": op, "params": params}
        if not capabilities.get(op, False):
            entry.update({"status": "unsupported",
                          "message": f"backend does not support {op}"})
            receipts.append(entry)
            cost["unsupported"] += 1
            continue
        try:
            if op == "insert":
                receipt = backend.insert(params["doc_id"], params["text"],
                                         params.get("title", ""),
                                         params.get("metadata"))
            elif op == "update":
                receipt = backend.update(params["doc_id"], params["text"],
                                         params.get("title", ""),
                                         params.get("metadata"))
            elif op == "retire":
                receipt = backend.retire(params["doc_id"])
            elif op == "maintain":
                receipt = backend.maintain()
            else:
                raise OrgEvalError(f"unknown stage op: {op!r}")
        except LifecycleNotSupported as exc:
            entry.update({"status": "unsupported", "message": str(exc)})
            receipts.append(entry)
            cost["unsupported"] += 1
            continue
        except Exception as exc:  # noqa: BLE001 - recorded, never silent
            entry.update({"status": "error",
                          "message": f"{type(exc).__name__}: {exc}"})
            receipts.append(entry)
            cost["errors"] += 1
            continue
        entry.update({"status": "ok", "receipt": receipt})
        receipts.append(entry)
        if op in cost:
            cost[op] += 1
    return receipts, cost


def _run_stage(backend: LifecycleBackend, task: OrgTask,
               stage: Stage) -> StageReport:
    _check_descriptor(stage.descriptor, task)
    receipts, cost = _apply_operations(backend, stage.operations)
    expected_live = set(stage.descriptor.expected_live_ids)
    snapshot = backend.snapshot()
    reported = set(snapshot.get("doc_ids", []))
    membership = snapshot.get("membership") or []
    duplicates = duplicate_membership_count(
        [list(part) for part in membership])
    indexed: set[str] = set()
    for part in membership:
        indexed.update(part)
    orphans = orphan_count(reported, indexed)
    preservation = (source_atom_coverage(reported, expected_live)
                    if expected_live else 1.0)

    per_query_recall: dict[str, float] = {}
    stale_violations: list[dict] = []
    live_texts = {d["doc_id"]: d["text"] for d in task.documents
                  if d["doc_id"] in expected_live}
    for query in task.queries:
        raw = backend.query(query.text, top_k=query.top_k)
        hits = raw if isinstance(raw, list) else []
        hit_ids = [h["doc_id"] if isinstance(h, dict) else h[0]
                   for h in hits]
        per_query_recall[query.query_id] = recall_at_k(
            hit_ids, list(query.gold), query.top_k)
        for hit in hits:
            doc_id = hit["doc_id"] if isinstance(hit, dict) else hit[0]
            if doc_id not in expected_live:
                stale_violations.append(
                    {"stage": stage.descriptor.role,
                     "query_id": query.query_id, "kind": "retired_hit",
                     "doc_id": doc_id})
            elif isinstance(hit, dict) and hit.get("text") is not None:
                current = live_texts.get(doc_id)
                if current is not None and hit["text"] != current:
                    stale_violations.append(
                        {"stage": stage.descriptor.role,
                         "query_id": query.query_id, "kind": "stale_text",
                         "doc_id": doc_id})
    coverage = (sum(per_query_recall.values()) / len(per_query_recall)
                if per_query_recall else 0.0)
    return StageReport(
        role=stage.descriptor.role,
        descriptor={
            "role": stage.descriptor.role,
            "population_id": stage.descriptor.population_id,
            "frontier": dict(stage.descriptor.frontier),
            "expected_live_ids": sorted(expected_live),
            "budget": dict(stage.descriptor.budget),
        },
        preservation=preservation,
        coverage_recall_mean=coverage,
        per_query_recall=per_query_recall,
        cost=cost,
        snapshot_ids=sorted(reported),
        membership_duplicates=duplicates,
        orphan_atoms=orphans,
        stale_violations=stale_violations,
        receipts=receipts,
    )


def run_before_after(backend: LifecycleBackend, task: OrgTask,
                     stages: list[Stage]) -> OrgEvalResult:
    """Run the frozen task at each stage; return deltas + integrity checks.

    The SAME task object (frozen queries + gold) is executed at every
    stage; only backend state evolves via stage operations. Raises
    :class:`StageMismatchError` before scoring anything when a stage
    descriptor disagrees with the task.
    """
    if len(stages) < 2:
        raise OrgEvalError(
            f"need at least a before and an after stage, got {len(stages)}")
    roles = [s.descriptor.role for s in stages]
    if roles[0] != "before" or any(r != "after" for r in roles[1:]):
        raise OrgEvalError(
            f"stage roles must be ['before', 'after', ...], got {roles}")
    digest_before = task.query_digest()
    result = OrgEvalResult(task_name=task.name, backend_name=backend.name(),
                           query_digest=digest_before)
    for stage in stages:
        result.stages.append(_run_stage(backend, task, stage))
    digest_after = task.query_digest()
    if digest_after != digest_before:
        raise OrgEvalError("task query set mutated during the run")

    before, after = result.stages[0], result.stages[-1]
    result.coverage_delta = after.coverage_recall_mean - before.coverage_recall_mean
    result.preservation_delta = after.preservation - before.preservation
    total: dict[str, int] = {}
    for stage_report in result.stages:
        for key, value in stage_report.cost.items():
            total[key] = total.get(key, 0) + value
    result.cost_total = total

    before_live = set(before.descriptor["expected_live_ids"])
    after_live = set(after.descriptor["expected_live_ids"])
    population_changed = before_live != after_live
    result.attribution = {
        "query_set_identical": True,
        "query_digest": digest_before,
        "population_changed": population_changed,
        "population_added": sorted(after_live - before_live),
        "population_removed": sorted(before_live - after_live),
        "maintain_ops": total.get("maintain", 0),
        "unsupported_ops": total.get("unsupported", 0),
        "error_ops": total.get("errors", 0),
        "verdict_basis": (
            "confounded: population changed between stages"
            if population_changed
            else "matched: identical queries and population; delta "
                 "attributable to backend state evolution (maintenance)"),
    }
    result.checks = [
        OrgCheck(name="stage_match", passed=True,
                 expected="descriptors match task population/frontier",
                 observed={"stages": len(stages)},
                 evidence={"reason": "ok"}),
        OrgCheck(name="query_frozen", passed=True,
                 expected=digest_before, observed=digest_after,
                 evidence={"reason": "same frozen query set at every stage"}),
        _check_preservation(result.stages),
        _check_membership(result.stages),
        _check_no_stale_leakage(result.stages),
    ]
    result.verdict = _verdict(result, population_changed)
    return result


def _check_preservation(stages: list[StageReport]) -> OrgCheck:
    diverged: dict[str, dict] = {}
    for stage in stages:
        expected = set(stage.descriptor["expected_live_ids"])
        reported = set(stage.snapshot_ids)
        if reported != expected:
            diverged[stage.role] = {"missing": sorted(expected - reported),
                                    "extra": sorted(reported - expected)}
    passed = not diverged
    return OrgCheck(
        name="preservation", passed=passed,
        expected={"coverage": 1.0, "exact_live_set": True},
        observed={s.role: s.preservation for s in stages},
        evidence={"diverged_stages": diverged,
                  "reason": "ok" if passed else
                  f"snapshot diverged from declared live set at: "
                  f"{sorted(diverged)}"},
    )


def _check_membership(stages: list[StageReport]) -> OrgCheck:
    dup_roles = {s.role: s.membership_duplicates for s in stages
                 if s.membership_duplicates > 0}
    passed = not dup_roles
    return OrgCheck(
        name="membership", passed=passed,
        expected={"duplicates": 0},
        observed={s.role: s.membership_duplicates for s in stages},
        evidence={"duplicate_stages": dup_roles,
                  "reason": "ok" if passed else
                  "snapshot membership is not an exact partition"},
    )


def _check_no_stale_leakage(stages: list[StageReport]) -> OrgCheck:
    violations = [v for s in stages for v in s.stale_violations]
    passed = not violations
    return OrgCheck(
        name="no_stale_leakage", passed=passed,
        expected="queries return only live docs with current text",
        observed={"violations": len(violations)},
        evidence={"violations": violations,
                  "reason": "ok" if passed else "stale content returned"},
    )


def _verdict(result: OrgEvalResult, population_changed: bool) -> str:
    integrity_ok = all(result.check(name).passed
                       for name in ("preservation", "membership",
                                    "no_stale_leakage"))
    if not integrity_ok:
        return "invalid"
    if population_changed:
        return "incomparable"
    if result.coverage_delta is None:
        return "invalid"
    if result.coverage_delta > 0:
        return "improvement"
    if result.coverage_delta < 0:
        return "regression"
    return "no_change"


def stages_from_task_payload(payload: dict) -> list[Stage]:
    """Build :class:`Stage` objects from a task-file ``stages`` section."""
    stages: list[Stage] = []
    for entry in payload.get("stages", []):
        raw = entry["descriptor"]
        descriptor = StageDescriptor(
            role=raw["role"], population_id=raw["population_id"],
            frontier=dict(raw.get("frontier", {})),
            expected_live_ids=tuple(raw.get("expected_live_ids", ())),
            budget=dict(raw.get("budget", {})))
        stages.append(Stage(descriptor=descriptor,
                            operations=tuple(entry.get("operations", ()))))
    return stages


def load_task_and_stages(path: str | Path) -> tuple[OrgTask, list[Stage]]:
    """Load a task plus its default stages; stages resolve doc texts by id."""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    task = load_task(path)
    by_id = {d["doc_id"]: d for d in task.documents}
    stages = copy.deepcopy(stages_from_task_payload(payload))
    resolved: list[Stage] = []
    for stage in stages:
        operations = []
        for operation in stage.operations:
            operation = dict(operation)
            params = dict(operation.get("params") or {})
            if operation.get("op") == "insert" and "text" not in params:
                doc = by_id.get(params.get("doc_id", ""))
                if doc is None:
                    raise OrgEvalError(
                        f"stage op references unknown doc: "
                        f"{params.get('doc_id')!r}")
                params["text"] = doc["text"]
                params.setdefault("title", doc.get("title", ""))
                operation["params"] = params
            operations.append(operation)
        resolved.append(Stage(descriptor=stage.descriptor,
                              operations=tuple(operations)))
    if len(resolved) < 2:
        raise OrgEvalError("task file must declare before + after stages")
    return task, resolved

