"""Self-organization metrics: Source coverage, orphan counts, duplicates, routing purity, and navigation recall."""

from dataclasses import dataclass, field
from collections import Counter


@dataclass
class OrganizationMetrics:
    """Evaluates the structural integrity and self-organization quality of the index."""
    total_source_atoms: int = 0
    preserved_source_atoms: int = 0
    source_atom_coverage: float | None = None
    orphan_atom_count: int | None = None
    duplicate_atom_count: int | None = None
    routing_purity: float | None = None
    tree_navigation_recall_vs_flat: float | None = None
    coverage_unit: str = "document"
    evidence: dict = field(default_factory=dict)
    is_computed: bool = False


def measure_organization(retriever, documents) -> OrganizationMetrics:
    expected = {d.doc_id for d in documents}
    preserved = retriever.preserved_document_ids()
    metrics = OrganizationMetrics(total_source_atoms=len(expected))
    if preserved is not None:
        metrics.preserved_source_atoms = len(preserved & expected)
        metrics.source_atom_coverage = source_atom_coverage(preserved, expected)
        metrics.is_computed = True
        metrics.evidence["preservation"] = "backend preserved_document_ids"
    snapshot = retriever.organization_snapshot()
    if snapshot is not None:
        metrics.evidence["snapshot"] = snapshot.get("evidence", {})
        if "source_atom_ids" in snapshot and "indexed_atom_ids" in snapshot:
            metrics.orphan_atom_count = orphan_count(
                set(snapshot["source_atom_ids"]), set(snapshot["indexed_atom_ids"]))
        if "memberships" in snapshot:
            metrics.duplicate_atom_count = duplicate_membership_count(snapshot["memberships"])
        if snapshot.get("assignments") and snapshot.get("ground_truth_labels"):
            metrics.routing_purity = routing_purity(snapshot["assignments"], snapshot["ground_truth_labels"])
    return metrics


def source_atom_coverage(preserved_atom_ids: set[str], expected_atom_ids: set[str]) -> float:
    """
    Fraction of source input atoms preserved in the immutable spine.
    Fails closed (returns 0.0) if expected_atom_ids is empty or unpopulated.
    """
    if not expected_atom_ids:
        return 0.0
    if not preserved_atom_ids:
        return 0.0
    return len(preserved_atom_ids & expected_atom_ids) / len(expected_atom_ids)


def orphan_count(spine_atom_ids: set[str], indexed_atom_ids: set[str]) -> int:
    """Number of spine atoms not indexed in any tree or vector partition."""
    return len(spine_atom_ids - indexed_atom_ids)


def duplicate_membership_count(node_atom_lists: list[list[str]]) -> int:
    """Number of duplicate atom memberships across nodes when strict partitioning is expected."""
    seen = set()
    duplicates = 0
    for atom_list in node_atom_lists:
        for atom_id in atom_list:
            if atom_id in seen:
                duplicates += 1
            seen.add(atom_id)
    return duplicates


def routing_purity(assignments: list[str], ground_truth_labels: list[str]) -> float:
    """
    Compute cluster/topic routing purity:
    sum_k max_j |c_k intersect t_j| / N
    """
    if not assignments or not ground_truth_labels or len(assignments) != len(ground_truth_labels):
        return 0.0

    cluster_to_labels: dict[str, list[str]] = {}
    for cluster, label in zip(assignments, ground_truth_labels):
        cluster_to_labels.setdefault(cluster, []).append(label)

    purity_sum = 0
    for labels in cluster_to_labels.values():
        most_common_count = Counter(labels).most_common(1)[0][1]
        purity_sum += most_common_count

    return purity_sum / len(assignments)


def navigation_recall(tree_retrieved_ids: list[str], flat_retrieved_ids: list[str]) -> float:
    """Fraction of flat top-K retrieved atoms discovered through tree navigation."""
    if not flat_retrieved_ids or not tree_retrieved_ids:
        return 0.0
    flat_set = set(flat_retrieved_ids)
    tree_set = set(tree_retrieved_ids)
    return len(flat_set & tree_set) / len(flat_set)
