"""Benchmark result aggregation, category slicing, statistical significance, and comparison reporting."""

import csv
import json
import math
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from trace_bench.metrics.retrieval import CaseRetrievalMetrics
from trace_bench.metrics.organization import OrganizationMetrics
from trace_bench.metrics.operations import OpsProfile
from trace_bench.datasets.schema import (
    ExecutionMode,
    ErrorReceipt,
    TraceLiteArtifactIdentity,
    DatasetAdmission,
    UnstableQueryPairingError,
)


@dataclass
class BaselineEvaluationResult:
    """Metrics for a single baseline engine across all evaluated cases."""
    baseline_name: str
    status: str = "success"  # success | failed | unsupported
    status_detail: str = ""
    overall_recall_at_5: float = 0.0
    overall_recall_at_20: float = 0.0
    overall_ndcg_at_10: float = 0.0
    overall_ndcg_at_30: float = 0.0
    overall_complete_coverage_at_10: float = 0.0
    overall_complete_coverage_at_20: float = 0.0
    overall_citation_precision_at_5: float = 0.0
    overall_mrr: float = 0.0
    overall_map_at_10: float = 0.0
    overall_precision_at_5: float = 0.0
    overall_multihop_coverage: float = 0.0
    overall_abstention_accuracy: float = 0.0
    total_cases: int = 0
    positive_cases_count: int = 0
    abstention_cases_count: int = 0
    failed_cases_count: int = 0
    empty_result_count: int = 0
    abstention_evaluated: bool = False
    false_accept_rate: float | None = None
    false_reject_rate: float | None = None
    configuration: dict = field(default_factory=dict)
    implementation_identity: dict = field(default_factory=dict)
    category_breakdown: dict[str, dict[str, float]] = field(default_factory=dict)
    case_results: list[dict] = field(default_factory=list)
    ops: dict = field(default_factory=dict)
    organization: dict = field(default_factory=dict)
    error_receipts: list[dict] = field(default_factory=list)


@dataclass
class BenchmarkRunResult:
    """Complete benchmark execution report across all evaluated baselines."""
    run_id: str
    dataset_name: str
    dataset_version: str
    timestamp: str
    corpus_sha256: str
    total_cases: int
    cases_sha256: str = ""
    indexed_documents_sha256: str = ""
    protocol: dict = field(default_factory=dict)
    metric_availability: dict = field(default_factory=dict)
    dataset_provenance: dict = field(default_factory=dict)
    mode: ExecutionMode = "regression"
    release_authority: bool = False
    is_certification_eligible: bool = False
    hardware_info: dict = field(default_factory=dict)
    artifact_identity: dict = field(default_factory=dict)
    admission: dict = field(default_factory=dict)
    baselines: dict[str, BaselineEvaluationResult] = field(default_factory=dict)
    error_receipts: list[dict] = field(default_factory=list)
    recipe: dict = field(default_factory=dict)  # recipe_name/sha/unit/repeat/seed when run from a recipe
    run_schema_version: str = "tb-run-v1"
    comparison_context: dict = field(default_factory=dict)  # declared comparison mode/stage/mapping

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "BenchmarkRunResult":
        version = data.get("run_schema_version", "tb-run-v1")
        if version != "tb-run-v1":
            raise ValueError(f"Unsupported run_schema_version: {version!r} (this TB reads tb-run-v1)")
        baselines_raw = data.get("baselines", {})
        parsed_baselines: dict[str, BaselineEvaluationResult] = {}
        for k, v in baselines_raw.items():
            if isinstance(v, BaselineEvaluationResult):
                parsed_baselines[k] = v
            elif isinstance(v, dict):
                parsed_baselines[k] = BaselineEvaluationResult(**v)
        data_copy = dict(data)
        data_copy["baselines"] = parsed_baselines
        return cls(**data_copy)

    def save_json(self, file_path: Path | str) -> None:
        p = Path(file_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    def save_csv(self, file_path: Path | str) -> None:
        p = Path(file_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        rows = []
        for b_name, res in self.baselines.items():
            rows.append({
                "run_id": self.run_id,
                "mode": self.mode,
                "dataset": self.dataset_name,
                "baseline": b_name,
                "recall_at_5": f"{res.overall_recall_at_5:.4f}",
                "recall_at_20": f"{res.overall_recall_at_20:.4f}",
                "ndcg_at_10": f"{res.overall_ndcg_at_10:.4f}",
                "complete_coverage_at_10": f"{res.overall_complete_coverage_at_10:.4f}",
                "citation_precision_at_5": f"{res.overall_citation_precision_at_5:.4f}",
                "mrr": f"{res.overall_mrr:.4f}",
                "map_at_10": f"{res.overall_map_at_10:.4f}",
                "precision_at_5": f"{res.overall_precision_at_5:.4f}",
                "abstention_accuracy": f"{res.overall_abstention_accuracy:.4f}" if res.abstention_evaluated else "",
                "latency_p95_ms": f"{res.ops['latency_p95_ms']:.2f}" if "latency_p95_ms" in res.ops else "",
                "qps": f"{res.ops['concurrent_qps']:.2f}" if "concurrent_qps" in res.ops else "",
                "failed_cases": res.failed_cases_count,
                "false_accept_rate": res.false_accept_rate,
                "false_reject_rate": res.false_reject_rate,
            })
            for field in ("recall_at_5", "recall_at_20", "ndcg_at_10", "mrr", "precision_at_5", "citation_precision_at_5"):
                if not self.metric_availability.get(field, True):
                    rows[-1][field] = ""
            for field, metric in (("map_at_10", "average_precision_at_10"), ("complete_coverage_at_10", "complete_gold_coverage_at_10")):
                if not self.metric_availability.get(metric, True):
                    rows[-1][field] = ""
        if rows:
            with open(p, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
                writer.writeheader()
                writer.writerows(rows)

    def save_trec(self, directory: Path | str) -> list[Path]:
        """Export native IDs with rank scores preserving backend emission order."""
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        paths = []
        for index, (name, result) in enumerate(self.baselines.items()):
            import re
            tag = re.sub(r"[^a-zA-Z0-9_-]", "_", name)
            path = directory / f"{self.run_id}.{index}_{tag}.trec"
            with path.open("w", encoding="utf-8", newline="\n") as output:
                for case in result.case_results:
                    qid = case.get("native_query_id") or case["case_id"]
                    ids = case.get("native_retrieved_ids") or case.get("retrieved_ids", [])
                    for rank, doc_id in enumerate(ids, 1):
                        if any(c.isspace() for c in qid + doc_id):
                            raise ValueError("TREC IDs cannot contain whitespace")
                        output.write(f"{qid} Q0 {doc_id} {rank} {len(ids)-rank+1} {tag}\n")
            paths.append(path)
        return paths


class BenchmarkAggregator:
    """Aggregates individual case metrics into overall and per-category statistics."""

    @staticmethod
    def aggregate_baseline(
        baseline_name: str,
        case_metrics: list[CaseRetrievalMetrics],
        ops_profile: OpsProfile | None = None,
        org_metrics: OrganizationMetrics | None = None,
        error_receipts: list[ErrorReceipt] | None = None,
    ) -> BaselineEvaluationResult:
        if not case_metrics:
            return BaselineEvaluationResult(baseline_name=baseline_name)

        pos_cases = [m for m in case_metrics if m.is_positive_query and m.outcome != "excluded"]
        abstain_cases = [m for m in case_metrics if not m.is_positive_query and m.outcome != "excluded"]
        failed_cases = [m for m in case_metrics if m.outcome == "query_failed"]
        empty_cases = [m for m in case_metrics if m.outcome == "empty_result"]

        n_pos = len(pos_cases)
        if n_pos > 0:
            r5 = sum(m.recall_at_5 for m in pos_cases) / n_pos
            r20 = sum(m.recall_at_20 for m in pos_cases) / n_pos
            ndcg10 = sum(m.ndcg_at_10 for m in pos_cases) / n_pos
            ndcg30 = sum(m.ndcg_at_30 for m in pos_cases) / n_pos
            cov10 = sum(m.complete_gold_coverage_at_10 for m in pos_cases) / n_pos
            cov20 = sum(m.complete_gold_coverage_at_20 for m in pos_cases) / n_pos
            prec5 = sum(m.citation_precision_at_5 for m in pos_cases) / n_pos
            mrr = sum(m.mrr for m in pos_cases) / n_pos
            mhop = sum(m.multihop_coverage for m in pos_cases) / n_pos
        else:
            r5 = r20 = ndcg10 = ndcg30 = cov10 = cov20 = prec5 = mrr = mhop = 0.0

        n_total = len(case_metrics)
        abstain = sum(m.abstention_accuracy for m in case_metrics) / n_total if n_total > 0 else 0.0

        # Category breakdown
        categories: dict[str, list[CaseRetrievalMetrics]] = {}
        for m in case_metrics:
            categories.setdefault(m.category, []).append(m)

        breakdown: dict[str, dict[str, float]] = {}
        for cat, items in categories.items():
            k_total = len(items)
            cat_pos = [x for x in items if x.is_positive_query and x.outcome != "excluded"]
            k_pos = len(cat_pos)
            breakdown[cat] = {
                "count": k_total,
                "positive_count": k_pos,
                "recall_at_5": sum(x.recall_at_5 for x in cat_pos) / k_pos if k_pos > 0 else 0.0,
                "ndcg_at_10": sum(x.ndcg_at_10 for x in cat_pos) / k_pos if k_pos > 0 else 0.0,
                "complete_coverage_at_10": sum(x.complete_gold_coverage_at_10 for x in cat_pos) / k_pos if k_pos > 0 else 0.0,
                "citation_precision_at_5": sum(x.citation_precision_at_5 for x in cat_pos) / k_pos if k_pos > 0 else 0.0,
                "abstention_accuracy": sum(x.abstention_accuracy for x in items) / k_total if k_total > 0 else 0.0,
            }

        all_receipts = [r.model_dump() for r in (error_receipts or [])]

        return BaselineEvaluationResult(
            baseline_name=baseline_name,
            overall_recall_at_5=r5,
            overall_recall_at_20=r20,
            overall_ndcg_at_10=ndcg10,
            overall_ndcg_at_30=ndcg30,
            overall_complete_coverage_at_10=cov10,
            overall_complete_coverage_at_20=cov20,
            overall_citation_precision_at_5=prec5,
            overall_mrr=mrr,
            overall_map_at_10=sum(m.average_precision_at_10 for m in pos_cases) / n_pos if n_pos else 0.0,
            overall_precision_at_5=sum(m.precision_at_5 for m in pos_cases) / n_pos if n_pos else 0.0,
            overall_multihop_coverage=mhop,
            overall_abstention_accuracy=abstain,
            total_cases=n_total,
            positive_cases_count=n_pos,
            abstention_cases_count=len(abstain_cases),
            failed_cases_count=len(failed_cases),
            empty_result_count=len(empty_cases),
            abstention_evaluated=bool(abstain_cases),
            false_accept_rate=sum(not m.predicted_abstention for m in abstain_cases) / len(abstain_cases) if abstain_cases else None,
            false_reject_rate=sum(m.predicted_abstention for m in pos_cases) / n_pos if n_pos else None,
            category_breakdown=breakdown,
            case_results=[asdict(m) for m in case_metrics],
            ops=asdict(ops_profile) if ops_profile else {},
            organization=asdict(org_metrics) if org_metrics else {},
            error_receipts=all_receipts,
        )


def _get_val(obj, attr: str, default: float = 0.0) -> float:
    if isinstance(obj, dict):
        return float(obj.get(attr, default))
    return float(getattr(obj, attr, default))


def compute_paired_statistics(
    current_case_scores: dict[str, float] | list[float],
    baseline_case_scores: dict[str, float] | list[float],
    seed: int = 42,
    bootstrap_samples: int = 2000,
) -> dict:
    """
    Compute paired delta, standard error, t-statistic, p-value (Student-t approx), and 95% CI.
    Enforces stable query pairing by case ID when dictionary maps are provided.
    """
    if bootstrap_samples < 1:
        raise ValueError("bootstrap_samples must be positive")
    if isinstance(current_case_scores, dict) != isinstance(baseline_case_scores, dict):
        raise UnstableQueryPairingError("Both score collections must use the same pairing representation")
    if isinstance(current_case_scores, dict) and isinstance(baseline_case_scores, dict):
        c_keys = set(current_case_scores.keys())
        b_keys = set(baseline_case_scores.keys())
        if c_keys != b_keys:
            missing_in_current = b_keys - c_keys
            missing_in_baseline = c_keys - b_keys
            raise UnstableQueryPairingError(
                f"Query sets do not match for paired comparison: "
                f"missing in current={missing_in_current}, missing in baseline={missing_in_baseline}",
                details={"missing_in_current": list(missing_in_current), "missing_in_baseline": list(missing_in_baseline)},
            )
        ordered_keys = sorted(c_keys)
        c_vals = [current_case_scores[k] for k in ordered_keys]
        b_vals = [baseline_case_scores[k] for k in ordered_keys]
    else:
        c_vals = list(current_case_scores)
        b_vals = list(baseline_case_scores)
        if len(c_vals) != len(b_vals):
            raise UnstableQueryPairingError(
                f"Cannot pair unaligned score lists of differing lengths: {len(c_vals)} vs {len(b_vals)}"
            )

    if not c_vals or not b_vals:
        return {"delta": 0.0, "p_value": 1.0, "ci_lower": 0.0, "ci_upper": 0.0, "stat_significant": False}

    if any(not math.isfinite(value) for value in c_vals+b_vals):
        raise ValueError("Paired scores must be finite")
    diffs = [c - b for c, b in zip(c_vals, b_vals)]
    n = len(diffs)
    mean_diff = sum(diffs) / n

    if n < 2:
        return {"delta": mean_diff, "p_value": 1.0, "ci_lower": mean_diff, "ci_upper": mean_diff, "stat_significant": False}

    var = sum((d - mean_diff) ** 2 for d in diffs) / (n - 1)
    std_err = math.sqrt(var / n) if var > 0 else 0.0

    import numpy as np
    from scipy.stats import t as student_t
    rng = np.random.default_rng(seed)
    values = np.asarray(diffs, dtype=float)
    draws = []
    # Bound intermediate memory for large suites.
    for start in range(0, bootstrap_samples, 32):
        indices = rng.integers(0, n, size=(min(32, bootstrap_samples-start), n))
        draws.extend(values[indices].mean(axis=1).tolist())
    ci_lower, ci_upper = (float(v) for v in np.percentile(draws, [2.5, 97.5]))

    if std_err > 0:
        t_stat = mean_diff / std_err
        p_val = 2.0 * student_t.sf(abs(t_stat), df=n-1)
    else:
        p_val = 1.0 if mean_diff == 0 else 0.0

    return {
        "delta": mean_diff,
        "std_err": std_err,
        "p_value": float(max(0.0, min(1.0, p_val))),
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "stat_significant": bool(p_val < 0.05),
        "ci_method": "paired_percentile_bootstrap",
        "p_value_method": "paired_student_t",
        "seed": seed,
        "bootstrap_samples": bootstrap_samples,
        "paired_cases": n,
    }


def check_release_gates(
    result: BaselineEvaluationResult,
    release_authority: bool = True,
    mode: ExecutionMode = "certification",
) -> tuple[bool, list[str]]:
    """
    Legacy opt-in thresholds, not an accepted release or independent certification policy:
    - Mode must be 'certification'
    - Release authority flag is True
    - Complete Gold Coverage >= 80% (0.80)
    - Citation Precision >= 90% (0.90)
    - Source Atom Coverage == 100% (1.00) (unambiguously computed)
    - Abstention Accuracy >= 95% (0.95)
    - Zero failed cases
    """
    failures = []

    if mode != "certification":
        failures.append(f"Execution mode '{mode}' is not eligible for production release gates (must be 'certification').")

    if not release_authority:
        failures.append("Corpus is marked release_authority: false (development fixture).")

    if result.failed_cases_count > 0:
        failures.append(f"Benchmark encountered {result.failed_cases_count} failed queries with unhandled exceptions.")

    if result.overall_complete_coverage_at_10 < 0.80:
        failures.append(f"Complete Gold Coverage@10 ({result.overall_complete_coverage_at_10:.1%}) is below gate threshold of 80.0%.")

    if result.overall_citation_precision_at_5 < 0.90:
        failures.append(f"Citation Precision@5 ({result.overall_citation_precision_at_5:.1%}) is below gate threshold of 90.0%.")

    org = result.organization or {}
    source_cov = org.get("source_atom_coverage")
    if source_cov is None:
        failures.append("Source coverage was not measured by the backend.")
        source_cov = 0.0
    if source_cov < 1.0:
        failures.append(f"Source Atom Coverage ({source_cov:.1%}) indicates dropped or unpreserved source atoms (must be 100.0%).")

    if result.overall_abstention_accuracy < 0.95:
        failures.append(f"Abstention Accuracy ({result.overall_abstention_accuracy:.1%}) is below gate threshold of 95.0%.")

    passed = (len(failures) == 0)
    return passed, failures


COMPARISON_MODES = ("static", "replay", "event_contrast")


def _check_run_integrity(current: BenchmarkRunResult, baseline: BenchmarkRunResult) -> None:
    for run in (current, baseline):
        for name, result in run.baselines.items():
            ids = [case["case_id"] for case in result.case_results]
            if len(ids) != run.total_cases or len(set(ids)) != len(ids):
                raise UnstableQueryPairingError(f"Incomplete or duplicate query results: {name}")
            if any(case.get("outcome") == "excluded" for case in result.case_results):
                raise UnstableQueryPairingError("Result artifacts cannot silently exclude frozen queries")


def _validate_static_inputs(current: BenchmarkRunResult, baseline: BenchmarkRunResult) -> None:
    if (current.dataset_name, current.dataset_version, current.corpus_sha256, current.total_cases) != (
        baseline.dataset_name, baseline.dataset_version, baseline.corpus_sha256, baseline.total_cases
    ):
        raise UnstableQueryPairingError("Dataset, version, corpus or case count differs; comparison refused.")
    if current.cases_sha256 != baseline.cases_sha256:
        raise UnstableQueryPairingError("Queries or judgments changed; comparison refused.")
    if current.indexed_documents_sha256 != baseline.indexed_documents_sha256:
        raise UnstableQueryPairingError("Actual indexed document identities/content differ; comparison refused.")
    if not current.cases_sha256 or not current.protocol or not baseline.protocol:
        raise UnstableQueryPairingError("Legacy runs lack query/judgment or protocol fingerprints; rerun before comparison.")
    if current.protocol != baseline.protocol:
        raise UnstableQueryPairingError("Evaluation protocols differ; comparison refused.")


def _validate_replay(current: BenchmarkRunResult, baseline: BenchmarkRunResult) -> None:
    for label, run in (("current", current), ("baseline", baseline)):
        context = run.comparison_context or {}
        if not context.get("logical_stage") or "provenance_mapping" not in context:
            raise UnstableQueryPairingError(
                f"Replay comparison requires declared logical_stage and provenance_mapping ({label} run lacks them).")
    if current.comparison_context["logical_stage"] != baseline.comparison_context["logical_stage"]:
        raise UnstableQueryPairingError("Replay comparison requires equal logical_stage on both runs.")
    if current.comparison_context["provenance_mapping"] != baseline.comparison_context["provenance_mapping"]:
        raise UnstableQueryPairingError("Replay comparison requires equal provenance_mapping on both runs.")
    # Native birth UUIDs are per-run integrity evidence and are never compared.


def _validate_event_contrast(current: BenchmarkRunResult, baseline: BenchmarkRunResult) -> None:
    if (current.dataset_name, current.dataset_version) != (baseline.dataset_name, baseline.dataset_version):
        raise UnstableQueryPairingError("Dataset or version differs; event contrast refused.")
    if not current.protocol or not baseline.protocol or current.protocol != baseline.protocol:
        raise UnstableQueryPairingError("Evaluation protocols differ; event contrast refused.")
    contexts = [run.comparison_context or {} for run in (current, baseline)]
    specs = [context.get("contrast") for context in contexts]
    if any(not isinstance(spec, dict) for spec in specs):
        raise UnstableQueryPairingError("Event contrast requires a declared contrast spec on both runs.")
    if specs[0].get("contrast_id") != specs[1].get("contrast_id"):
        raise UnstableQueryPairingError("Event contrast specs disagree on contrast_id.")
    stages = [context.get("stage") for context in contexts]
    if not all(stages) or stages[0] == stages[1]:
        raise UnstableQueryPairingError("Event contrast requires two distinct stages.")
    shared = specs[0].get("shared_queries")
    if not shared or specs[1].get("shared_queries") != shared:
        raise UnstableQueryPairingError("Event contrast requires matching non-empty shared_queries.")
    for run, label in ((current, "current"), (baseline, "baseline")):
        case_ids = {case["case_id"] for result in run.baselines.values() for case in result.case_results}
        missing = sorted(set(shared) - case_ids)
        if missing:
            raise UnstableQueryPairingError(f"Event contrast shared_queries missing from {label} run: {missing[:5]}")


def _refusal_dict(run: BenchmarkRunResult) -> dict:
    return {
        "dataset_provenance": run.dataset_provenance or {},
        "baselines": {
            name: {"implementation_identity": base.implementation_identity or {}}
            for name, base in (run.baselines or {}).items()
        },
    }


def validate_comparison(current: BenchmarkRunResult, baseline: BenchmarkRunResult, mode: str = "static") -> None:
    """Gate a comparison under one declared mode (static, replay, event_contrast)."""
    if mode not in COMPARISON_MODES:
        raise ValueError(f"Unknown comparison mode: {mode!r} (expected one of {', '.join(COMPARISON_MODES)})")
    _check_run_integrity(current, baseline)
    # HV custom-diagnostic pins refuse incompatible mixes everywhere this
    # gate runs (compare CLI, viewer, capsule report). Lazy import: the
    # workloads package imports this module at call time.
    from trace_bench.workloads.hv import refuse_pin_mismatch

    refuse_pin_mismatch(_refusal_dict(current), _refusal_dict(baseline))
    if mode == "event_contrast":
        _validate_event_contrast(current, baseline)
    else:
        _validate_static_inputs(current, baseline)
        if mode == "replay":
            _validate_replay(current, baseline)


def generate_comparison_markdown(current: BenchmarkRunResult, baseline: BenchmarkRunResult,
                                 current_engine: str | None = None,
                                 baseline_engine: str | None = None,
                                 mode: str = "static") -> str:
    """Generate markdown report comparing two benchmark runs with paired statistical p-values."""
    validate_comparison(current, baseline, mode)
    lines = [
        f"# Benchmark Comparison: {current.run_id} vs {baseline.run_id}",
        "",
        f"- **Dataset**: {current.dataset_name} (v{current.dataset_version})",
        f"- **Comparison mode**: {mode}",
        f"- **Execution Mode**: Current=`{current.mode}`, Baseline=`{baseline.mode}`",
        f"- **Cases**: {current.total_cases}",
        f"- **Current Date**: {current.timestamp}",
        f"- **Baseline Date**: {baseline.timestamp}",
        "",
        "## Overall Metrics Comparison & Statistical Significance (Stable Query Pairing)",
        "",
        "| Baseline | Metric | Baseline Run | Current Run | Delta | 95% CI | p-value | Significant (p<0.05)? |",
        "|---|---|:---:|:---:|:---:|:---:|:---:|:---:|",
    ]

    if mode == "event_contrast":
        at = lines.index("## Overall Metrics Comparison & Statistical Significance (Stable Query Pairing)")
        lines[at:at] = ["Event contrast over declared before/after stages; not same-input official retrieval.", ""]
    if bool(current_engine) != bool(baseline_engine):
        raise ValueError("Specify both --current-engine and --baseline-engine.")
    pairs = [(current_engine, baseline_engine)] if current_engine else [
        (k, k) for k in sorted(set(current.baselines) & set(baseline.baselines))]
    if not pairs:
        raise ValueError("No matching engines; specify --current-engine and --baseline-engine.")
    for c_key, b_key in pairs:
        c_base = current.baselines[c_key]
        b_base = baseline.baselines[b_key]

        c_cases = c_base.case_results if isinstance(c_base, BaselineEvaluationResult) else c_base.get("case_results", [])
        b_cases = b_base.case_results if isinstance(b_base, BaselineEvaluationResult) else b_base.get("case_results", [])

        metric_pairs = [
            ("MAP@10", "average_precision_at_10", _get_val(b_base, "overall_map_at_10"), _get_val(c_base, "overall_map_at_10")),
            ("P@5", "precision_at_5", _get_val(b_base, "overall_precision_at_5"), _get_val(c_base, "overall_precision_at_5")),
            ("Recall@5", "recall_at_5", _get_val(b_base, "overall_recall_at_5"), _get_val(c_base, "overall_recall_at_5")),
            ("Recall@20", "recall_at_20", _get_val(b_base, "overall_recall_at_20"), _get_val(c_base, "overall_recall_at_20")),
            ("nDCG@10", "ndcg_at_10", _get_val(b_base, "overall_ndcg_at_10"), _get_val(c_base, "overall_ndcg_at_10")),
            ("Complete Coverage@10", "complete_gold_coverage_at_10", _get_val(b_base, "overall_complete_coverage_at_10"), _get_val(c_base, "overall_complete_coverage_at_10")),
            ("Returned relevance@5", "citation_precision_at_5", _get_val(b_base, "overall_citation_precision_at_5"), _get_val(c_base, "overall_citation_precision_at_5")),
            ("MRR", "mrr", _get_val(b_base, "overall_mrr"), _get_val(c_base, "overall_mrr")),
            ("Abstention Accuracy", "abstention_accuracy", _get_val(b_base, "overall_abstention_accuracy"), _get_val(c_base, "overall_abstention_accuracy")),
        ]

        for m_label, m_field, b_val, c_val in metric_pairs:
            if not current.metric_availability.get(m_field, True):
                continue
            if m_field == "abstention_accuracy" and not (c_base.abstention_evaluated and b_base.abstention_evaluated):
                continue
            select = lambda items: [x for x in items if x.get("outcome") != "excluded" and (
                m_field == "abstention_accuracy" or x.get("is_positive_query", True))]
            c_selected, b_selected = select(c_cases), select(b_cases)
            c_score_map = {item["case_id"]: float(item.get(m_field, 0.0)) for item in c_selected}
            b_score_map = {item["case_id"]: float(item.get(m_field, 0.0)) for item in b_selected}
            if len(c_score_map) != len(c_selected) or len(b_score_map) != len(b_selected):
                raise UnstableQueryPairingError("Duplicate query IDs in result artifact.")

            try:
                stats = compute_paired_statistics(c_score_map, b_score_map)
                delta = stats["delta"]
                delta_str = f"+{delta:.3f}" if delta > 0 else f"{delta:.3f}"
                ci_str = f"[{stats['ci_lower']:.3f}, {stats['ci_upper']:.3f}]"
                p_val_str = f"{stats['p_value']:.4f}"
                sig_str = "**YES**" if stats["stat_significant"] else "No"
            except UnstableQueryPairingError as e:
                raise UnstableQueryPairingError(f"Cannot compare {c_key} and {b_key}: {e.message}") from e

            lines.append(f"| `{c_key}` vs `{b_key}` | {m_label} | {b_val:.3f} | {c_val:.3f} | {delta_str} | {ci_str} | {p_val_str} | {sig_str} |")

    lines.extend(["", "95% CIs: paired percentile bootstrap (2,000 samples, seed 42).",
                  "p-values: two-sided paired Student-t test; no multiple-comparison correction.",
                  "Retrieval rows use positive queries, including failures at zero. Abstention uses all queries."])
    return "\n".join(lines)
