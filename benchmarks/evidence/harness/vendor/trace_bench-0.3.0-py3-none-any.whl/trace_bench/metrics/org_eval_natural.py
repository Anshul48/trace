"""Natural-corpus org-eval pilots W1-W4 (TB-only, HV100M cond 7).

Extension of the :mod:`trace_bench.metrics.org_eval` skeleton (imported,
never modified): streaming population adapters over real tbdoc rows,
arrival-order / distribution-shift experiment helpers with separate
reporting, lifecycle stale-leak oracles, and wall/RSS resource recording.

Reference-backend numbers produced through this module prove harness
mechanics only and must never be presented as target (Trace/TL) claims.
There is no real target seam: native journeys stay undemonstrated until
an owner-delivered control interface lands (see ORG_EVAL_NATURAL.md).
"""

from __future__ import annotations

import hashlib
import json
import resource
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

from trace_bench.lifecycle.contract import LifecycleBackend
from trace_bench.lifecycle.reference import ReferenceLifecycleBackend
from trace_bench.metrics.org_eval import (
    OrgEvalResult,
    OrgTask,
    Stage,
    StageDescriptor,
    run_before_after,
)

SHARD_GLOB = "shard-*.jsonl"

HV_CORE_STRATA = frozenset({
    "brightnew", "musique", "fiqa", "multihop", "nfcorpus", "scifact",
    "edgar1", "edgar2", "curated",
})  # lkml excluded per D-HV100M-03 (FINDING_LKML_31 quarantine)
HV_BRIGHT_SUBSETS = frozenset({"aops", "pony", "theoremqa_theorems"})


# -- pilot treatment (real-text calibrated modeling device) -----------------


class PilotConjunctionBackend(ReferenceLifecycleBackend):
    """Pilot treatment: conjunctive lookup before, overlap ranking after.

    Modeling device in the same spirit as the skeleton's
    ``OrganizingTreatmentBackend`` (whose >=2/>=1-token threshold cannot
    separate on real long-query text, where gold overlap is >=3 tokens):
    before the first ``maintain`` the query path serves conjunctive
    lookup only (a doc must contain EVERY query token, modelling an
    unorganized index without overlap ranking); after ``maintain`` it
    uses the full reference overlap ranking. Deterministic; the
    before/after delta on an unchanged population is attributable to the
    maintain pass, which is what lets controls separate on real text.
    """

    def __init__(self) -> None:
        super().__init__()
        self._organized = False
        self.maintain_passes = 0

    def name(self) -> str:
        return "PilotConjunctionBackend"

    def maintain(self) -> dict:
        receipt = super().maintain()
        self._organized = True
        self.maintain_passes += 1
        receipt["organized"] = True
        return receipt

    def query(self, text: str, top_k: int = 10,
              generation: int | None = None) -> list[dict]:
        if self._organized:
            return super().query(text, top_k, generation)
        from trace_bench.lifecycle.reference import tokenize
        query_tokens = tokenize(text)
        scored = []
        for doc_id in self._store:
            record = self._store[doc_id]
            if not record["alive"]:
                continue
            if generation is not None and \
                    record["generation_updated"] > generation:
                continue
            if query_tokens and query_tokens <= tokenize(record["text"]):
                scored.append((doc_id, len(query_tokens)))
        scored.sort(key=lambda item: (-item[1], item[0]))
        return [{"doc_id": d, "score": float(s),
                 "text": self._store[d]["text"]}
                for d, s in scored[: max(top_k, 0)]]


PILOT_BACKENDS: dict[str, str] = {
    "pilot_conjunction": "treatment (conjunctive-before, overlap-after)",
    "no_drain": "honest control (no maintain)",
    "append_only": "honest control (no update/retire)",
    "org_membership_liar": "deliberately faulty (flagged)",
    "org_stale_leak": "deliberately faulty (flagged)",
}


def default_shard_dir() -> Path:
    # tb-500m-v1 is QUARANTINED (FINDING_LKML_31); v1.1 is the default.
    # See docs/scale-program/V11_SUPERSESSION.md.
    return Path("/tmp/tb-scale-data/packages/tb-500m-v1.1/shards")


# -- streaming population adapters ------------------------------------------


class TbdocStream:
    """Lazy tbdoc row iterator (never materializes the corpus).

    ``strata`` filters by row stratum; ``take`` caps the yield. The
    stream counts lines read so tests can prove bounded ingestion.
    """

    def __init__(self, shard_dir: str | Path | None = None,
                 strata: set[str] | frozenset | None = None) -> None:
        self.shard_dir = Path(shard_dir) if shard_dir else default_shard_dir()
        self.strata = strata
        self.lines_read = 0
        self.rows_yielded = 0

    def __iter__(self) -> Iterator[dict]:
        for shard in sorted(self.shard_dir.glob(SHARD_GLOB)):
            with open(shard, encoding="utf-8") as fh:
                for line in fh:
                    self.lines_read += 1
                    row = json.loads(line)
                    if self.strata is not None and \
                            row.get("stratum") not in self.strata:
                        continue
                    self.rows_yielded += 1
                    yield row

    def take(self, n: int) -> Iterator[dict]:
        count = 0
        for row in self:
            if count >= n:
                break
            count += 1
            yield row

    def fetch_ids(self, ids: set[str]) -> dict[str, dict]:
        """Single streaming pass collecting exactly ``ids`` (early exit)."""
        found: dict[str, dict] = {}
        if not ids:
            return found
        for row in self:
            if row["tbdoc_id"] in ids:
                found[row["tbdoc_id"]] = row
                if len(found) == len(ids):
                    break
        return found


def order_variants(doc_ids: list[str]) -> dict[str, list[str]]:
    """Three deterministic arrival orders over the SAME population."""
    alpha = sorted(doc_ids)
    return {
        "alpha": alpha,
        "reverse": list(reversed(alpha)),
        "hash_shuffle": sorted(
            doc_ids, key=lambda d: hashlib.sha256(d.encode()).hexdigest()),
    }


def insert_stages(task: OrgTask, doc_ids: list[str],
                  maintain_after: bool = True) -> list[Stage]:
    """Before/after stages inserting ``doc_ids`` (texts embedded).

    Unlike fixture-declared stages (whose texts ``load_task_and_stages``
    resolves by id), programmatic stages must carry text/title inline:
    ``run_before_after`` applies op params verbatim.
    """
    by_id = {d["doc_id"]: d for d in task.documents}
    live = tuple(sorted(doc_ids))
    before = Stage(
        descriptor=StageDescriptor(
            role="before", population_id=task.population_id,
            frontier=dict(task.frontier), expected_live_ids=live),
        operations=tuple(
            {"op": "insert",
             "params": {"doc_id": d, "text": by_id[d]["text"],
                        "title": by_id[d].get("title", "")}}
            for d in doc_ids),
    )
    after = Stage(
        descriptor=StageDescriptor(
            role="after", population_id=task.population_id,
            frontier=dict(task.frontier), expected_live_ids=live),
        operations=(("maintain",) and ({"op": "maintain", "params": {}},)
                    if maintain_after else ()),
    )
    return [before, after]


# -- resource recording ------------------------------------------------------


@dataclass
class ResourceUsage:
    wall_s: float
    maxrss_kb: int
    rss_mb: float

    def to_dict(self) -> dict:
        return {"wall_s": self.wall_s, "maxrss_kb": self.maxrss_kb,
                "rss_mb": self.rss_mb}


def run_with_resources(fn, *args, **kwargs):
    """Run ``fn``; return (result, ResourceUsage wall + peak RSS)."""
    start = time.perf_counter()
    result = fn(*args, **kwargs)
    wall = time.perf_counter() - start
    maxrss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return result, ResourceUsage(wall_s=wall, maxrss_kb=int(maxrss),
                                 rss_mb=round(maxrss / 1024.0, 3))


# -- order / shift experiments ------------------------------------------------


@dataclass
class OrderRun:
    order: str
    result: OrgEvalResult
    resources: ResourceUsage

    def to_dict(self) -> dict:
        return {"order": self.order, "verdict": self.result.verdict,
                "coverage_delta": self.result.coverage_delta,
                "preservation": [s.preservation for s in self.result.stages],
                "resources": self.resources.to_dict()}


@dataclass
class OrderShiftReport:
    """Order effects and shift effects, reported SEPARATELY.

    ``order_runs``: same population, different arrival orders (order
    attribution only). ``shift``: population changed between stages
    (confounded delta, verdict ``incomparable`` when integrity holds).
    Never merged: a reader cannot mistake an order delta for a shift
    delta or vice versa.
    """

    population_id: str
    order_runs: list[OrderRun] = field(default_factory=list)
    shift: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "population_id": self.population_id,
            "order_effects": [r.to_dict() for r in self.order_runs],
            "shift_effects": self.shift,
        }


def run_order_experiment(task: OrgTask, backend_factory,
                         orders: dict[str, list[str]] | None = None,
                         ) -> list[OrderRun]:
    """Run before/after over each arrival order (same population)."""
    if orders is None:
        orders = order_variants(sorted(task.doc_ids))
    runs = []
    for name, doc_ids in orders.items():
        backend = backend_factory()
        try:
            stages = insert_stages(task, doc_ids)
            result, res = run_with_resources(run_before_after, backend,
                                             task, stages)
        finally:
            backend.close()
        runs.append(OrderRun(order=name, result=result, resources=res))
    return runs


def make_shift_task(task: OrgTask, extra_docs: list[dict],
                    new_population_id: str) -> OrgTask:
    """Extend a task population with new-topic docs (shift arm)."""
    from trace_bench.metrics.org_eval import OrgQuery  # noqa: PLC0415
    docs = tuple(task.documents) + tuple(extra_docs)
    queries = tuple(OrgQuery(query_id=q.query_id, text=q.text,
                             gold=tuple(q.gold), top_k=q.top_k)
                    for q in task.queries)
    return OrgTask(name=task.name + "+shift",
                   population_id=new_population_id,
                   frontier=dict(task.frontier), documents=docs,
                   queries=queries)


def summarize_order_vs_shift(order_runs: list[OrderRun],
                             shift_result: OrgEvalResult,
                             shift_resources: ResourceUsage,
                             population_id: str) -> OrderShiftReport:
    """Assemble the split order/shift report (never merged)."""
    shift = {
        "verdict": shift_result.verdict,
        "coverage_delta": shift_result.coverage_delta,
        "population_changed":
            shift_result.attribution.get("population_changed"),
        "population_added":
            shift_result.attribution.get("population_added", []),
        "population_removed":
            shift_result.attribution.get("population_removed", []),
        "verdict_basis": shift_result.attribution.get("verdict_basis"),
        "resources": shift_resources.to_dict(),
    }
    return OrderShiftReport(population_id=population_id,
                            order_runs=order_runs, shift=shift)


# -- lifecycle oracle (W4) -----------------------------------------------------


@dataclass
class LifecycleOracle:
    """Expected live/retired sets per stage + stale-leak verdict."""

    expected_live: dict[str, list[str]]
    retired: dict[str, list[str]]
    violations: list[dict] = field(default_factory=list)
    passed: bool = False

    def to_dict(self) -> dict:
        return {"expected_live": self.expected_live, "retired": self.retired,
                "violations": self.violations, "passed": self.passed}


def check_lifecycle_oracle(result: OrgEvalResult,
                           expected_live: dict[str, list[str]],
                           retired: dict[str, list[str]]) -> LifecycleOracle:
    """Compare evaluator stale findings against the script oracle."""
    violations = []
    for stage in result.stages:
        want_live = set(expected_live.get(stage.role, []))
        if set(stage.snapshot_ids) != want_live:
            violations.append(
                {"stage": stage.role, "kind": "live_set_divergence",
                 "missing": sorted(want_live - set(stage.snapshot_ids)),
                 "extra": sorted(set(stage.snapshot_ids) - want_live)})
        for v in stage.stale_violations:
            violations.append({"stage": v.get("stage", stage.role),
                               "kind": v.get("kind"),
                               "query_id": v.get("query_id"),
                               "doc_id": v.get("doc_id")})
        for doc_id in retired.get(stage.role, []):
            if doc_id in stage.snapshot_ids:
                violations.append({"stage": stage.role,
                                   "kind": "retired_still_live",
                                   "doc_id": doc_id})
    honest = result.check("no_stale_leakage").passed and \
        result.check("preservation").passed
    oracle = LifecycleOracle(expected_live=expected_live, retired=retired,
                             violations=violations,
                             passed=(not violations) and honest)
    return oracle
