"""Score external TREC files with the same frozen inputs and missing-query denominator."""

import math
from datetime import datetime, timezone
from pathlib import Path

from trace_bench.datasets.loader import case_fingerprint, document_fingerprint, file_sha256
from trace_bench.metrics.aggregator import BenchmarkAggregator, BenchmarkRunResult
from trace_bench.metrics.retrieval import attach_case_evidence, evaluate_case_retrieval


def score_trec(manifest, documents, path: Path, engine_name="external", top_k=100):
    query_ids = {c.native_query_id or c.id: c for c in manifest.cases}
    doc_ids = {str(d.metadata.get("native_doc_id", d.doc_id)): d.doc_id for d in documents}
    if len(query_ids) != len(manifest.cases) or len(doc_ids) != len(documents):
        raise ValueError("Native IDs must be unique for TREC interchange")
    rankings, ranks, tags = {}, {}, set()
    with path.open(encoding="utf-8") as source:
        for number, line in enumerate(source, 1):
            if not line.strip():
                continue
            parts = line.split()
            if len(parts) != 6:
                raise ValueError(f"Invalid TREC row at line {number}: expected six columns")
            qid, _unused, native_doc, rank_text, score_text, tag = parts
            rank, score = int(rank_text), float(score_text)
            if qid not in query_ids or native_doc not in doc_ids:
                raise ValueError(f"Unknown query/document ID at line {number}")
            if not math.isfinite(score) or rank < 1:
                raise ValueError(f"Invalid rank/score at line {number}")
            seen_ranks = ranks.setdefault(qid, set())
            ranking = rankings.setdefault(qid, {})
            if native_doc in ranking or rank in seen_ranks:
                raise ValueError(f"Duplicate document/rank at line {number}")
            ranking[native_doc] = score
            seen_ranks.add(rank)
            tags.add(tag)
    if len(tags) > 1:
        raise ValueError("TREC file mixes run tags; score each system separately")
    metrics = []
    reverse = {internal: native for native, internal in doc_ids.items()}
    for case in manifest.cases:
        qid = case.native_query_id or case.id
        # NIST trec_eval resolves score ties by descending document ID.
        ranking = sorted(rankings.get(qid, {}).items(), key=lambda pair: (pair[1], pair[0]), reverse=True)
        excluded = set(case.excluded_doc_ids)
        if manifest.metadata.get("ignore_identical_query_document_ids"):
            excluded.add(doc_ids.get(qid, qid))
        selected = [(doc_ids[doc], score) for doc, score in ranking if doc_ids[doc] not in excluded][:top_k]
        metric = evaluate_case_retrieval(case.id, case.category, [i for i, _ in selected],
            case.gold_atom_ids, False, case.expected_abstention, relevance_scores=case.relevance_scores)
        metric.native_query_id = qid
        metric.retrieved_ids = [i for i, _ in selected]
        metric.native_retrieved_ids = [reverse[i] for i in metric.retrieved_ids]
        metric.retrieved_scores = [score for _, score in selected]
        attach_case_evidence(metric, case)
        metrics.append(metric)
    result = BenchmarkAggregator.aggregate_baseline(engine_name, metrics)
    # TREC does not encode an explicit abstention decision or timings.
    result.abstention_evaluated = False
    result.false_accept_rate = result.false_reject_rate = None
    result.implementation_identity = {"trec_file_sha256": file_sha256(path), "native_pins": None}
    now = datetime.now(timezone.utc)
    from trace_bench.runner import evaluation_protocol, metric_availability
    return BenchmarkRunResult(run_id=f"score_{now.strftime('%Y%m%d_%H%M%S_%f')}",
        dataset_name=manifest.name, dataset_version=manifest.version, timestamp=now.isoformat(),
        corpus_sha256=manifest.corpus_sha256, cases_sha256=case_fingerprint(manifest),
        indexed_documents_sha256=document_fingerprint(documents),
        total_cases=len(metrics), baselines={engine_name: result}, dataset_provenance=manifest.metadata,
        protocol=evaluation_protocol(manifest, top_k, 1, 0), metric_availability=metric_availability(top_k),
        run_schema_version="tb-run-v1", comparison_context={})
