"""Retrieval quality metrics: Recall@K, nDCG@K, Complete Gold Coverage, Precision, MRR, Abstention."""

import math
from dataclasses import dataclass, field
from trace_bench.datasets.schema import QueryOutcome


@dataclass
class CaseRetrievalMetrics:
    """Computed retrieval metrics for an individual query evaluation case."""
    case_id: str
    category: str
    outcome: QueryOutcome = "success"
    is_positive_query: bool = True
    predicted_abstention: bool = False
    retrieved_ids: list[str] = field(default_factory=list)
    retrieved_scores: list[float] = field(default_factory=list)
    native_query_id: str | None = None
    native_retrieved_ids: list[str] = field(default_factory=list)
    backend_receipt: dict = field(default_factory=dict)
    latency_ms: float | None = None
    query: str = ""
    gold_ids: list[str] = field(default_factory=list)
    native_gold_ids: list[str] = field(default_factory=list)
    excluded_ids: list[str] = field(default_factory=list)
    native_excluded_ids: list[str] = field(default_factory=list)
    average_precision_at_10: float = 0.0
    precision_at_5: float = 0.0
    recall_at_5: float = 0.0
    recall_at_20: float = 0.0
    recall_at_100: float = 0.0
    ndcg_at_10: float = 0.0
    ndcg_at_30: float = 0.0
    complete_gold_coverage_at_10: float = 0.0
    complete_gold_coverage_at_20: float = 0.0
    citation_precision_at_5: float = 0.0
    citation_precision_at_10: float = 0.0
    mrr: float = 0.0
    multihop_coverage: float = 0.0
    abstention_accuracy: float = 0.0
    error_code: str | None = None
    exclusion_reason: str | None = None


def recall_at_k(retrieved_ids: list[str], gold_ids: list[str], k: int) -> float:
    """Compute Recall@K on positive queries."""
    if not gold_ids or not retrieved_ids[:k]:
        return 0.0
    gold_set = set(gold_ids)
    retrieved_k = set(retrieved_ids[:k])
    return len(retrieved_k & gold_set) / len(gold_set)


def complete_gold_coverage(retrieved_ids: list[str], gold_ids: list[str], k: int) -> float:
    """Return 1.0 if ALL gold atom IDs are within top-K, else 0.0."""
    if not gold_ids or not retrieved_ids[:k]:
        return 0.0
    gold_set = set(gold_ids)
    retrieved_k = set(retrieved_ids[:k])
    return 1.0 if gold_set.issubset(retrieved_k) else 0.0


def citation_precision(retrieved_ids: list[str], gold_ids: list[str], k: int) -> float:
    """Legacy relevance among returned documents, not fixed-denominator P@K or citation support."""
    retrieved_k = retrieved_ids[:k]
    if not retrieved_k or not gold_ids:
        return 0.0
    gold_set = set(gold_ids)
    hits = sum(1 for item_id in retrieved_k if item_id in gold_set)
    return hits / len(retrieved_k)


def ndcg_at_k(retrieved_ids: list[str], gold_ids: list[str], k: int,
              relevance_scores: dict[str, float] | None = None) -> float:
    """Compute Normalized Discounted Cumulative Gain at K (nDCG@K)."""
    if not gold_ids or not retrieved_ids[:k]:
        return 0.0
    # trec_eval / BEIR use linear graded gain (not exponential gain).
    grades = relevance_scores or {doc_id: 1.0 for doc_id in gold_ids}
    dcg = sum(grades.get(item_id, 0.0) / math.log2(i + 2)
              for i, item_id in enumerate(retrieved_ids[:k]))
    ideal = sorted((v for v in grades.values() if v > 0), reverse=True)[:k]
    idcg = sum(v / math.log2(i + 2) for i, v in enumerate(ideal))
    return dcg / idcg if idcg > 0.0 else 0.0


def average_precision_at_k(retrieved_ids: list[str], gold_ids: list[str], k: int) -> float:
    """trec_eval map_cut: normalize by all relevant documents, even beyond K."""
    gold = set(gold_ids)
    if not gold:
        return 0.0
    hits, total = 0, 0.0
    for rank, doc_id in enumerate(retrieved_ids[:k], 1):
        if doc_id in gold:
            hits += 1
            total += hits / rank
    return total / len(gold)


def mrr_at_k(retrieved_ids: list[str], gold_ids: list[str], k: int = 100) -> float:
    """Compute Mean Reciprocal Rank (MRR)."""
    if not gold_ids or not retrieved_ids[:k]:
        return 0.0
    gold_set = set(gold_ids)
    for i, item_id in enumerate(retrieved_ids[:k]):
        if item_id in gold_set:
            return 1.0 / (i + 1)
    return 0.0


def multihop_coverage(retrieved_ids: list[str], gold_ids: list[str], k: int = 20) -> float:
    """Percentage of multi-hop evidence hops recovered in top-K."""
    return recall_at_k(retrieved_ids, gold_ids, k)


def abstention_accuracy(predicted_abstention: bool, expected_abstention: bool) -> float:
    """Return 1.0 if predicted abstention matches expected, else 0.0."""
    return 1.0 if predicted_abstention == expected_abstention else 0.0


def attach_case_evidence(metric: "CaseRetrievalMetrics", case) -> "CaseRetrievalMetrics":
    """Record the frozen per-query evidence (text, gold, exclusions) on a metric.

    Runs without these fields (older artifacts) keep empty defaults; the viewer
    renders those as not recorded rather than inventing them.
    """
    metric.query = case.query
    metric.gold_ids = list(case.gold_atom_ids)
    metric.native_gold_ids = list(case.native_gold_doc_ids or case.gold_atom_ids)
    metric.excluded_ids = list(case.excluded_doc_ids)
    metric.native_excluded_ids = list(case.excluded_doc_ids)
    return metric


def evaluate_case_retrieval(
    case_id: str,
    category: str,
    retrieved_ids: list[str],
    gold_ids: list[str],
    is_abstaining: bool,
    expected_abstention: bool,
    is_error: bool = False,
    error_code: str | None = None,
    exclusion_reason: str | None = None,
    relevance_scores: dict[str, float] | None = None,
) -> CaseRetrievalMetrics:
    """
    Compute all standard retrieval metrics for one case with strict outcome separation.
    
    Invariants:
    1. Expected abstentions isolate to abstention metrics only (retrieval metrics remain 0.0).
    2. Empty result on a positive query has 0.0 retrieval metrics and is NOT an abstention.
    3. Query failures or exclusions record structured outcomes without fabricated metrics.
    """
    # Stable deduplication prevents repeated chunks of one document inflating scores.
    retrieved_ids = list(dict.fromkeys(retrieved_ids))
    if is_error:
        return CaseRetrievalMetrics(
            case_id=case_id,
            category=category,
            outcome="query_failed",
            is_positive_query=not expected_abstention,
            abstention_accuracy=0.0,
            error_code=error_code or "ERR_QUERY_FAILED",
        )

    if exclusion_reason:
        return CaseRetrievalMetrics(
            case_id=case_id,
            category=category,
            outcome="excluded",
            is_positive_query=not expected_abstention,
            abstention_accuracy=0.0,
            exclusion_reason=exclusion_reason,
        )

    if expected_abstention:
        # Expected abstention query (out-of-scope / unanswerable)
        # Affects ONLY abstention metrics. Retrieval metrics must NOT be 1.0.
        abstain_acc = abstention_accuracy(predicted_abstention=is_abstaining, expected_abstention=True)
        outcome: QueryOutcome = "explicit_abstention" if is_abstaining else ("empty_result" if not retrieved_ids else "success")
        return CaseRetrievalMetrics(
            case_id=case_id,
            category=category,
            outcome=outcome,
            is_positive_query=False,
            predicted_abstention=is_abstaining,
            recall_at_5=0.0,
            recall_at_20=0.0,
            recall_at_100=0.0,
            ndcg_at_10=0.0,
            ndcg_at_30=0.0,
            complete_gold_coverage_at_10=0.0,
            complete_gold_coverage_at_20=0.0,
            citation_precision_at_5=0.0,
            citation_precision_at_10=0.0,
            mrr=0.0,
            multihop_coverage=0.0,
            abstention_accuracy=abstain_acc,
        )

    # Positive evidence query (gold documents expected)
    if is_abstaining:
        # System explicitly refused/abstained on a positive query
        return CaseRetrievalMetrics(
            case_id=case_id,
            category=category,
            outcome="explicit_abstention",
            is_positive_query=True,
            predicted_abstention=True,
            abstention_accuracy=0.0,
        )

    if not retrieved_ids:
        # Empty result on positive query has zero retrieval score and is NOT an abstention
        return CaseRetrievalMetrics(
            case_id=case_id,
            category=category,
            outcome="empty_result",
            is_positive_query=True,
            abstention_accuracy=0.0,
        )

    # Normal positive retrieval
    return CaseRetrievalMetrics(
        case_id=case_id,
        category=category,
        outcome="success",
        is_positive_query=True,
        recall_at_5=recall_at_k(retrieved_ids, gold_ids, 5),
        recall_at_20=recall_at_k(retrieved_ids, gold_ids, 20),
        recall_at_100=recall_at_k(retrieved_ids, gold_ids, 100),
        average_precision_at_10=average_precision_at_k(retrieved_ids, gold_ids, 10),
        precision_at_5=sum(i in set(gold_ids) for i in retrieved_ids[:5]) / 5,
        ndcg_at_10=ndcg_at_k(retrieved_ids, gold_ids, 10, relevance_scores),
        ndcg_at_30=ndcg_at_k(retrieved_ids, gold_ids, 30, relevance_scores),
        complete_gold_coverage_at_10=complete_gold_coverage(retrieved_ids, gold_ids, 10),
        complete_gold_coverage_at_20=complete_gold_coverage(retrieved_ids, gold_ids, 20),
        citation_precision_at_5=citation_precision(retrieved_ids, gold_ids, 5),
        citation_precision_at_10=citation_precision(retrieved_ids, gold_ids, 10),
        mrr=mrr_at_k(retrieved_ids, gold_ids),
        multihop_coverage=multihop_coverage(retrieved_ids, gold_ids, 20),
        abstention_accuracy=abstention_accuracy(predicted_abstention=False, expected_abstention=False),
    )
