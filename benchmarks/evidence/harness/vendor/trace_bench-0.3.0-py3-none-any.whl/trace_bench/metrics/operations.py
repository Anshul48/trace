"""Operational metrics: Latency percentiles, memory RSS, ingestion throughput, and storage footprint."""

import os
import time
import threading
import numpy as np
from pathlib import Path
from dataclasses import dataclass, field


@dataclass
class OpsProfile:
    """Operational profile containing latency, throughput, memory, and storage metrics.

    Units and boundaries: latencies are client-observed milliseconds per query
    (encoding + retrieval); ingestion is wall seconds over the indexed documents;
    memory is sampled process RSS unless an isolated job record says otherwise.
    Fields that were not measured are None, never a plausible-looking zero.
    """
    total_queries: int = 0
    latency_p50_ms: float = 0.0
    latency_p95_ms: float = 0.0
    latency_p99_ms: float = 0.0
    latency_mean_ms: float = 0.0
    latency_min_ms: float = 0.0
    latency_max_ms: float = 0.0
    ingestion_duration_sec: float = 0.0
    ingestion_documents_per_sec: float = 0.0
    ingestion_atoms_per_sec: float = 0.0  # Deprecated alias; counts documents.
    organization_duration_sec: float | None = None  # None = not measured.
    peak_memory_rss_mb: float | None = None
    memory_measurement: str = "sampled_process_rss_20ms; shared process, not isolated backend RSS"
    storage_total_bytes: int | None = None
    storage_bytes_per_atom: float | None = None
    llm_tokens_used: int | None = None


class MemorySampler:
    """Sample this process throughout indexing and queries, including final RSS."""
    def __init__(self):
        self.peak = None
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _sample(self):
        value = MemoryTracker.get_current_rss_mb()
        if value > 0:
            self.peak = max(self.peak or 0, value)

    def _run(self):
        while not self._stop.wait(0.02):
            self._sample()

    def start(self):
        self._sample()
        self._thread.start()

    def stop(self):
        self._stop.set()
        self._thread.join()
        self._sample()
        return self.peak


class LatencyTracker:
    """Records query latency samples and computes summary percentiles."""

    def __init__(self):
        self.samples_ms: list[float] = []

    def record(self, duration_sec: float) -> None:
        self.samples_ms.append(duration_sec * 1000.0)

    def summary(self) -> dict[str, float]:
        if not self.samples_ms:
            return {
                "count": 0,
                "p50": 0.0,
                "p95": 0.0,
                "p99": 0.0,
                "mean": 0.0,
                "min": 0.0,
                "max": 0.0,
            }
        arr = np.array(self.samples_ms)
        return {
            "count": len(arr),
            "p50": float(np.percentile(arr, 50)),
            "p95": float(np.percentile(arr, 95)),
            "p99": float(np.percentile(arr, 99)),
            "mean": float(np.mean(arr)),
            "min": float(np.min(arr)),
            "max": float(np.max(arr)),
        }


class MemoryTracker:
    """Measures process RSS memory."""

    @staticmethod
    def get_current_rss_mb() -> float:
        try:
            import psutil
            process = psutil.Process(os.getpid())
            return process.memory_info().rss / (1024 * 1024)
        except Exception:
            return 0.0


class StorageTracker:
    """Calculates disk directory size."""

    @staticmethod
    def calculate_directory_bytes(directory_path: Path | str) -> int:
        p = Path(directory_path)
        if not p.exists():
            return 0
        if p.is_file():
            return p.stat().st_size
        total = 0
        for entry in p.rglob("*"):
            if entry.is_file():
                try:
                    total += entry.stat().st_size
                except OSError:
                    pass
        return total
