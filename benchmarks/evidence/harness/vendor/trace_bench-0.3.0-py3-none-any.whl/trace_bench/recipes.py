"""Versioned run recipes: frozen workloads + backends + protocol + limits.

A recipe is a small JSON document (``tb-recipe-v1``) that fully describes a
reproducible comparison. Recipes expand to job units of
(dataset, backend, repeat). Use dry-run/preflight before indexing or downloads.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator

RECIPE_VERSION = "tb-recipe-v1"


class RecipeProtocol(BaseModel):
    top_k: int = 100
    concurrency: int = 1
    warmup: int = 0
    repeats: int = 1
    seed: int = 42
    cold_between_repeats: bool = True
    per_query_timeout_s: float | None = None
    job_deadline_s: float | None = None

    @field_validator("top_k", "concurrency", "repeats")
    @classmethod
    def _positive(cls, value: int) -> int:
        if value < 1:
            raise ValueError("top_k, concurrency and repeats must be >= 1")
        return value

    @field_validator("warmup", "seed")
    @classmethod
    def _non_negative(cls, value: int) -> int:
        if value < 0:
            raise ValueError("warmup and seed must be >= 0")
        return value


class RecipeDataset(BaseModel):
    name: str
    split: str = "test"
    limit: int | None = None
    data_dir: str | None = None


class RecipeBackend(BaseModel):
    name: str
    config: dict[str, Any] = Field(default_factory=dict)


class Recipe(BaseModel):
    version: str = RECIPE_VERSION
    name: str = "tb-recipe"
    datasets: list[RecipeDataset] = Field(default_factory=list)
    backends: list[RecipeBackend] = Field(default_factory=list)
    protocol: RecipeProtocol = Field(default_factory=RecipeProtocol)
    output_dir: str = "benchmarks/results"

    @field_validator("version")
    @classmethod
    def _version(cls, value: str) -> str:
        if value != RECIPE_VERSION:
            raise ValueError(f"Unsupported recipe version '{value}' (expected '{RECIPE_VERSION}')")
        return value

    @field_validator("datasets", "backends")
    @classmethod
    def _non_empty(cls, value: list) -> list:
        if not value:
            raise ValueError("Recipe needs at least one dataset and one backend.")
        return value


def load_recipe(path: str | Path) -> Recipe:
    """Load a recipe from a file path or a shipped preset name.

    An existing file (or anything path-shaped) loads from disk, preserving
    file errors; otherwise ``path`` resolves as a preset in
    ``trace_bench.presets`` (``.json`` suffix optional).
    """
    candidate = Path(path)
    if candidate.is_file() or candidate.exists() or _is_path_shaped(str(path)):
        raw = json.loads(candidate.read_text(encoding="utf-8"))
        return Recipe.model_validate(raw)
    from trace_bench.presets import preset_text

    return Recipe.model_validate(json.loads(preset_text(str(path))))


def _is_path_shaped(text: str) -> bool:
    import os

    return os.sep in text or (os.altsep is not None and os.altsep in text)


def recipe_sha256(recipe: Recipe) -> str:
    from trace_bench.datasets.loader import compute_sha256

    return compute_sha256(recipe.model_dump_json())


def expand_recipe(recipe: Recipe) -> list[dict[str, Any]]:
    """Expand a recipe to ordered job units (dataset x backend x repeat)."""
    units: list[dict[str, Any]] = []
    for dataset in recipe.datasets:
        for backend in recipe.backends:
            for repeat in range(recipe.protocol.repeats):
                units.append({
                    "unit_id": f"{dataset.name}__{dataset.split}__{backend.name}__r{repeat}",
                    "dataset": dataset.model_dump(),
                    "backend": backend.model_dump(),
                    "repeat": repeat,
                    "seed": recipe.protocol.seed + repeat,
                })
    return units


def dry_run_text(recipe: Recipe) -> str:
    """Human-readable expansion of a recipe (no downloads, no indexing)."""
    lines = [
        f"Recipe '{recipe.name}' ({recipe.version})",
        f"Protocol: top_k={recipe.protocol.top_k} concurrency={recipe.protocol.concurrency} "
        f"warmup={recipe.protocol.warmup} repeats={recipe.protocol.repeats} seed={recipe.protocol.seed} "
        f"cold_between_repeats={recipe.protocol.cold_between_repeats}",
    ]
    if recipe.protocol.per_query_timeout_s:
        lines.append(f"Limits: per_query_timeout_s={recipe.protocol.per_query_timeout_s} "
                     f"job_deadline_s={recipe.protocol.job_deadline_s}")
    lines.append(f"Units ({len(expand_recipe(recipe))}):")
    for unit in expand_recipe(recipe):
        lines.append(f"  - {unit['unit_id']} (seed {unit['seed']})")
    return "\n".join(lines)


def preflight(recipe: Recipe) -> list[str]:
    """Actionable preflight findings. No indexing, no downloads, no model loads.

    Lines starting with 'error:' block execution; 'warning:' lines need review.
    """
    from trace_bench.backends import availability, capability_for, check_concurrency
    from trace_bench.datasets.portable import data_root, resolve_dataset

    findings: list[str] = []
    for dataset in recipe.datasets:
        try:
            path = resolve_dataset(dataset.name, dataset.data_dir, dataset.split)
            findings.append(f"ok: dataset '{dataset.name}' (split {dataset.split}) resolves to {path}")
        except FileNotFoundError:
            findings.append(
                f"error: dataset '{dataset.name}' is not prepared. "
                f"Run: trace-bench setup --dataset {dataset.name} --split {dataset.split}"
            )
        if dataset.limit is not None:
            findings.append(
                f"warning: dataset '{dataset.name}': --limit {dataset.limit} keeps the full corpus "
                f"but produces a diagnostic query subset (protocol_status diagnostic_subset)."
            )
    if not recipe.protocol.cold_between_repeats:
        findings.append(
            "warning: cold_between_repeats=false is recorded, but every repeat currently "
            "re-indexes from scratch: no backend declares trustworthy checkpoint support, "
            "so warm repeats are unavailable. Results are unaffected (cold is the "
            "reproducible default)."
        )
    for backend in recipe.backends:
        cap = capability_for(backend.name)
        ok, reasons = availability(cap)
        if not ok:
            findings.append(f"error: backend '{backend.name}' is unavailable: {'; '.join(reasons)}")
        elif cap.cost_class == "expensive":
            findings.append(f"warning: backend '{backend.name}' is expensive ({cap.description})")
        else:
            findings.append(f"ok: backend '{backend.name}' static requirements satisfied")
        findings.extend(check_concurrency(backend.name, recipe.protocol.concurrency, backend.config))
        if backend.name.startswith("python:"):
            parts = backend.name.removeprefix("python:").split(":")
            if len(parts) != 2 or not all(parts):
                findings.append(f"error: backend '{backend.name}': expected python:module:Class")
    try:
        roots = {str(data_root(d.data_dir)) for d in recipe.datasets}
        for root in sorted(roots):
            usage = shutil.disk_usage(root if Path(root).exists() else Path(root).parent)
            findings.append(f"ok: disk at {root}: {usage.free / 1e9:.1f} GB free")
    except OSError as exc:
        findings.append(f"warning: disk headroom check failed: {exc}")
    return findings
